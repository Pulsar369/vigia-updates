<?php
/**
 * Auto-actualización desde un canal PÚBLICO en GitHub — para no tener que
 * subir el ZIP a mano en cada cambio (mientras el plugin no esté en
 * wordpress.org, que trae su propio auto-update).
 *
 * Cómo funciona: un repo público (BCR_UPDATE_MANIFEST) sirve un manifest.json
 * pequeño con la última versión y la URL del ZIP. WordPress pregunta por
 * actualizaciones dos veces al día; enganchamos ahí, comparamos versiones y,
 * si hay una más nueva, le decimos a WP de dónde bajarla. WP la instala como
 * cualquier update del repositorio oficial.
 *
 * Sin secretos: Vigía es GPL y el canal es público (raw.githubusercontent.com,
 * servido por CDN, sin límite de peticiones que nos afecte). La respuesta se
 * cachea 6 h para no preguntar en cada carga del admin.
 */

defined('ABSPATH') || exit;

class BCR_Updater {

    const CACHE_KEY = 'bcr_update_manifest';
    const CACHE_TTL = 6 * HOUR_IN_SECONDS;

    public static function init() {
        if (!defined('BCR_UPDATE_MANIFEST') || !BCR_UPDATE_MANIFEST) {
            return; // canal no configurado: nos comportamos como un plugin normal
        }
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'inject'));
        add_filter('plugins_api', array(__CLASS__, 'details'), 20, 3);
        // Tras instalar el update, olvidar la caché para que no reofrezca la vieja.
        add_action('upgrader_process_complete', array(__CLASS__, 'flush_cache'), 10, 0);
        // Botón "Buscar actualizaciones" en la fila del plugin (no esperar 6 h).
        add_filter('plugin_action_links_' . plugin_basename(BCR_FILE), array(__CLASS__, 'action_link'));
        add_action('admin_init', array(__CLASS__, 'handle_manual_check'));
        add_action('admin_notices', array(__CLASS__, 'manual_check_notice'));
    }

    /** Añade el enlace "Buscar actualizaciones" a la fila del plugin. */
    public static function action_link($links) {
        if (current_user_can('update_plugins')) {
            $url = wp_nonce_url(add_query_arg('bcr_check', '1', admin_url('plugins.php')), 'bcr_check');
            $links[] = '<a href="' . esc_url($url) . '">' . esc_html__('Check for updates', 'vigia-de-bots') . '</a>';
        }
        return $links;
    }

    /** Fuerza la comprobación ya: limpia caché nuestra + la de WP y re-pregunta. */
    public static function handle_manual_check() {
        if (empty($_GET['bcr_check']) || !current_user_can('update_plugins')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_check')) {
            return;
        }
        self::flush_cache();
        delete_site_transient('update_plugins');   // obliga a WP a re-evaluar
        $manifest = self::fetch_manifest(true);     // salta la caché de 6 h
        wp_update_plugins();                        // dispara nuestro inject() con datos frescos
        $hay = $manifest && empty($manifest['_error']) && version_compare($manifest['version'], BCR_VERSION, '>');
        wp_safe_redirect(add_query_arg('bcr_checked', $hay ? '1' : '0', admin_url('plugins.php')));
        exit;
    }

    /** Aviso tras la comprobación manual. */
    public static function manual_check_notice() {
        if (!isset($_GET['bcr_checked'])) {
            return;
        }
        if ($_GET['bcr_checked'] === '1') {
            echo '<div class="notice notice-warning is-dismissible"><p>'
                . esc_html__('Vigía de Bots: a new version is available — see the update notice on its row below.', 'vigia-de-bots')
                . '</p></div>';
        } else {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html__('Vigía de Bots: you are already on the latest version.', 'vigia-de-bots')
                . '</p></div>';
        }
    }

    /** Baja el manifest (cacheado). Devuelve array u null si no se pudo. */
    public static function fetch_manifest($force = false) {
        if (!$force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $cached;
            }
        }
        $resp = wp_remote_get(BCR_UPDATE_MANIFEST, array(
            'timeout' => 8,
            'headers' => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
            // Cachear el fallo poco rato: no martillear si el canal está caído.
            set_site_transient(self::CACHE_KEY, array('_error' => true), 30 * MINUTE_IN_SECONDS);
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($data) || empty($data['version']) || empty($data['download_url'])) {
            set_site_transient(self::CACHE_KEY, array('_error' => true), 30 * MINUTE_IN_SECONDS);
            return null;
        }
        set_site_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    /** Si el manifest trae una versión mayor, mete la oferta de update. */
    public static function inject($transient) {
        if (!is_object($transient)) {
            return $transient;
        }
        $m = self::fetch_manifest();
        if (!$m || !empty($m['_error'])) {
            return $transient;
        }
        if (version_compare($m['version'], BCR_VERSION, '<=')) {
            return $transient; // ya estamos al día
        }
        $basename = plugin_basename(BCR_FILE);
        $obj = array(
            'slug'        => dirname($basename),
            'plugin'      => $basename,
            'new_version' => $m['version'],
            'package'     => $m['download_url'],
            'url'         => isset($m['homepage']) ? $m['homepage'] : '',
            'tested'      => isset($m['tested']) ? $m['tested'] : '',
            'requires'    => isset($m['requires']) ? $m['requires'] : '',
            'requires_php' => isset($m['requires_php']) ? $m['requires_php'] : '',
        );
        if (!isset($transient->response)) {
            $transient->response = array();
        }
        $transient->response[$basename] = (object) $obj;
        return $transient;
    }

    /** Popup "Ver detalles" del plugin. */
    public static function details($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== dirname(plugin_basename(BCR_FILE))) {
            return $result;
        }
        $m = self::fetch_manifest();
        if (!$m || !empty($m['_error'])) {
            return $result;
        }
        return (object) array(
            'name'          => isset($m['name']) ? $m['name'] : 'Vigía de Bots',
            'slug'          => dirname(plugin_basename(BCR_FILE)),
            'version'       => $m['version'],
            'author'        => 'WPO Toolkit',
            'homepage'      => isset($m['homepage']) ? $m['homepage'] : '',
            'download_link' => $m['download_url'],
            'requires'      => isset($m['requires']) ? $m['requires'] : '',
            'requires_php'  => isset($m['requires_php']) ? $m['requires_php'] : '',
            'tested'        => isset($m['tested']) ? $m['tested'] : '',
            'sections'      => array(
                'changelog' => isset($m['changelog']) ? wp_kses_post($m['changelog']) : '',
            ),
        );
    }

    public static function flush_cache() {
        delete_site_transient(self::CACHE_KEY);
    }
}
