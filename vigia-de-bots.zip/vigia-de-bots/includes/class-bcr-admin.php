<?php
/**
 * Panel de admin — 1 pantalla: tarjetas (con el RPM DENTRO de la tarjeta del
 * dinero, al lado de donde se ve su efecto), veredicto sin IA, desglose,
 * gráfico 30 días, tabla paginada de últimas visitas y CTA al toolkit.
 *
 * Tema noche/día por variables CSS. Strings en inglés (base); es_* en /languages.
 */

defined('ABSPATH') || exit;

class BCR_Admin {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
    }

    public static function menu() {
        add_menu_page(
            __('Vigía de Bots', 'vigia-de-bots'),
            __('Vigía', 'vigia-de-bots'),
            'manage_options',
            'vigia-de-bots',
            array(__CLASS__, 'render'),
            'dashicons-shield-alt',
            58
        );
    }

    public static function settings() {
        // Grupos SEPARADOS: el mini-form del RPM (en la tarjeta del dinero) no
        // puede compartir grupo con el email — options.php machaca a null todo
        // campo del grupo que no viaje en el POST.
        register_setting('bcr_money', 'bcr_rpm', array(
            'type' => 'number', 'sanitize_callback' => array(__CLASS__, 'san_rpm'), 'default' => 0,
        ));
        register_setting('bcr_report', 'bcr_report_enabled', array(
            'type' => 'string', 'sanitize_callback' => array(__CLASS__, 'san_bool'), 'default' => '1',
        ));
        register_setting('bcr_report', 'bcr_report_email', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_email', 'default' => '',
        ));
    }

    public static function san_rpm($v) {
        $v = (float) str_replace(',', '.', (string) $v);
        return ($v >= 0 && $v < 1000) ? $v : 0;
    }

    public static function san_bool($v) {
        return $v === '1' ? '1' : '0';
    }

    /** Tamaño de página de la tabla: lo elige el usuario y se le recuerda. */
    private static function per_page() {
        $allowed = array(10, 25, 50, 100);
        $uid = get_current_user_id();
        if (isset($_GET['bcr_pp'])) {
            $pp = (int) $_GET['bcr_pp'];
            if (in_array($pp, $allowed, true)) {
                update_user_meta($uid, 'bcr_per_page', $pp);
                return $pp;
            }
        }
        $saved = (int) get_user_meta($uid, 'bcr_per_page', true);
        return in_array($saved, $allowed, true) ? $saved : 25;
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $t7  = BCR_Store::totals(7);
        $bad7 = $t7['impostor'] + $t7['datacenter'] + $t7['declarado'];
        $pct7 = $t7['total'] > 0 ? round($bad7 / $t7['total'] * 100) : 0;
        $cost = BCR_Store::monthly_cost();
        $rpm  = (float) get_option('bcr_rpm', 0);
        ?>
        <div class="wrap">
        <div class="bcr-root" id="bcr-root">
            <div class="bcr-head">
                <h1><?php esc_html_e('Vigía de Bots', 'vigia-de-bots'); ?>
                    <span class="bcr-sub"><?php esc_html_e('who visits you and what it costs', 'vigia-de-bots'); ?></span></h1>
                <button type="button" class="bcr-theme-toggle" id="bcr-theme-toggle"
                        title="<?php esc_attr_e('Light / dark mode', 'vigia-de-bots'); ?>">🌙</button>
            </div>

            <div class="bcr-cards">
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html(number_format_i18n($t7['total'])); ?></div>
                    <div><?php esc_html_e('visits in the last 7 days', 'vigia-de-bots'); ?></div>
                </div>
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html($pct7); ?>%</div>
                    <div><?php esc_html_e('were bots', 'vigia-de-bots'); ?></div>
                </div>
                <div class="bcr-card bcr-card-money">
                    <?php if ($cost !== null) : ?>
                        <div class="bcr-big">~$<?php echo esc_html(number_format_i18n($cost, 2)); ?></div>
                        <div><?php esc_html_e('per month of junk traffic polluting your ads (estimate from your RPM)', 'vigia-de-bots'); ?></div>
                    <?php else : ?>
                        <div class="bcr-big">$?</div>
                        <div><?php esc_html_e('enter your RPM here to see what bots cost you', 'vigia-de-bots'); ?></div>
                    <?php endif; ?>
                    <?php /* El ajuste vive AL LADO de su efecto — pedido del usuario: al llegar
                             abajo del listado ya no se acordaba de para qué era el campo. */ ?>
                    <form method="post" action="options.php" class="bcr-rpm-form">
                        <?php settings_fields('bcr_money'); ?>
                        <label for="bcr_rpm"><?php esc_html_e('Your AdSense RPM ($)', 'vigia-de-bots'); ?></label>
                        <input name="bcr_rpm" id="bcr_rpm" type="number" step="0.01" min="0"
                               value="<?php echo esc_attr($rpm ?: ''); ?>" />
                        <button class="button button-small"><?php esc_html_e('Save', 'vigia-de-bots'); ?></button>
                        <span class="bcr-muted"><?php esc_html_e('What you earn per 1,000 pageviews (your AdSense panel shows it). With this, the radar estimates how much money bots are polluting.', 'vigia-de-bots'); ?></span>
                    </form>
                </div>
                <div class="bcr-card bcr-card-cta">
                    <a class="button button-primary button-hero" href="<?php echo esc_url(BCR_CTA_URL); ?>" target="_blank" rel="noopener">
                        <?php esc_html_e('Stop them with WPO Toolkit →', 'vigia-de-bots'); ?>
                    </a>
                    <div class="bcr-muted"><?php esc_html_e('This radar only watches. Blocking them is the toolkit\'s job.', 'vigia-de-bots'); ?></div>
                </div>
            </div>

            <?php self::verdict_card(); ?>

            <h2><?php esc_html_e('Breakdown, last 7 days', 'vigia-de-bots'); ?></h2>
            <div class="bcr-buckets">
                <?php
                $defs = array(
                    'humano'     => array('🟢', __('Humans', 'vigia-de-bots')),
                    'bueno'      => array('🔵', __('Verified good bots (real Google/Bing)', 'vigia-de-bots')),
                    'impostor'   => array('🔴', __('IMPOSTORS (claim to be Google/Bing and are not)', 'vigia-de-bots')),
                    'datacenter' => array('🟠', __('Data centers disguised as people', 'vigia-de-bots')),
                    'declarado'  => array('⚪', __('Declared bots (AI, SEO, tools)', 'vigia-de-bots')),
                );
                foreach ($defs as $key => $def) : ?>
                    <div class="bcr-bucket">
                        <span><?php echo esc_html($def[0]); ?></span>
                        <strong><?php echo esc_html(number_format_i18n($t7[$key])); ?></strong>
                        <span><?php echo esc_html($def[1]); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <h2><?php esc_html_e('Last 30 days — humans vs bots', 'vigia-de-bots'); ?></h2>
            <?php self::chart(); ?>

            <h2><?php esc_html_e('Latest visits', 'vigia-de-bots'); ?></h2>
            <?php self::visits_table(); ?>

            <h2><?php esc_html_e('Weekly email report', 'vigia-de-bots'); ?></h2>
            <form method="post" action="options.php" class="bcr-settings">
                <?php settings_fields('bcr_report'); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Weekly email report', 'vigia-de-bots'); ?></th>
                        <td><label><input name="bcr_report_enabled" type="checkbox" value="1" <?php checked(get_option('bcr_report_enabled', '1'), '1'); ?> />
                            <?php esc_html_e('Email me every Monday what the bots cost', 'vigia-de-bots'); ?></label><br><br>
                            <input name="bcr_report_email" type="email" value="<?php echo esc_attr(get_option('bcr_report_email', get_option('admin_email'))); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button(__('Save', 'vigia-de-bots')); ?>
            </form>
        </div>
        </div>
        <style><?php echo self::css(); ?></style>
        <script><?php echo self::theme_js(); ?></script>
        <?php
    }

    /** Veredicto sin IA: umbrales fijos y auditables sobre lo medido. */
    private static function verdict_card() {
        $v = BCR_Store::verdict();
        if ($v['state'] === 'gathering') {
            ?>
            <div class="bcr-verdict bcr-v0">
                <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-bots'); ?></h2>
                <p><?php printf(
                    esc_html__('Still gathering data: %1$d of %2$d days with traffic (%3$s visits). The verdict unlocks with enough history.', 'vigia-de-bots'),
                    (int) $v['days'], (int) BCR_Store::VERDICT_MIN_DAYS, esc_html(number_format_i18n($v['total']))
                ); ?></p>
            </div>
            <?php
            return;
        }
        $titles = array(
            1 => __('WPO Toolkit alone is enough', 'vigia-de-bots'),
            2 => __('WPO Toolkit + free Cloudflare', 'vigia-de-bots'),
            3 => __('WPO Toolkit + Cloudflare Pro', 'vigia-de-bots'),
        );
        $explains = array(
            1 => __('Bot pressure is low: %1$s%% bad bots and ~%2$s hostile visits/day. Blocking inside WordPress is enough — no need to pay for more layers.', 'vigia-de-bots'),
            2 => __('Moderate pressure: %1$s%% bad bots and ~%2$s hostile visits/day. Worth stopping them at the edge (free Cloudflare) so they never reach your hosting, with the toolkit driving the rules.', 'vigia-de-bots'),
            3 => __('Heavy pressure: %1$s%% bad bots and ~%2$s hostile visits/day — swarm level. You need edge blocking with Cloudflare Pro muscle on top of the toolkit.', 'vigia-de-bots'),
        );
        $lvl = (int) $v['level'];
        ?>
        <div class="bcr-verdict bcr-v<?php echo esc_attr($lvl); ?>">
            <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-bots'); ?>
                <span class="bcr-verdict-title"><?php echo esc_html($titles[$lvl]); ?></span></h2>
            <p><?php printf(esc_html($explains[$lvl]),
                esc_html(number_format_i18n($v['bad_pct'], 1)), esc_html(number_format_i18n($v['hostile_day'], 1))); ?></p>
            <p class="bcr-muted"><?php printf(
                esc_html__('Based on the last %d days measured by this radar. No AI involved: fixed thresholds you can audit.', 'vigia-de-bots'),
                30
            ); ?></p>
        </div>
        <?php
    }

    /** Tabla de últimas visitas, paginada y con tamaño a elegir (se recuerda). */
    private static function visits_table() {
        $pp = self::per_page();
        $total = BCR_Store::count_visits();
        $pages = max(1, (int) ceil($total / $pp));
        $pg = isset($_GET['bcr_pg']) ? max(1, min($pages, (int) $_GET['bcr_pg'])) : 1;
        $base = remove_query_arg(array('bcr_pg', 'bcr_pp'));
        ?>
        <div class="bcr-tablebar">
            <span><?php printf(esc_html__('%s recorded visits (buffer keeps the last 500)', 'vigia-de-bots'), esc_html(number_format_i18n($total))); ?></span>
            <span class="bcr-pp">
                <?php esc_html_e('Show per page:', 'vigia-de-bots'); ?>
                <?php foreach (array(10, 25, 50, 100) as $opt) : ?>
                    <?php if ($opt === $pp) : ?><strong><?php echo (int) $opt; ?></strong>
                    <?php else : ?><a href="<?php echo esc_url(add_query_arg(array('bcr_pp' => $opt, 'bcr_pg' => 1), $base)); ?>"><?php echo (int) $opt; ?></a><?php endif; ?>
                <?php endforeach; ?>
            </span>
        </div>
        <table class="widefat bcr-table">
            <thead><tr>
                <th><?php esc_html_e('When', 'vigia-de-bots'); ?></th>
                <th><?php esc_html_e('IP', 'vigia-de-bots'); ?></th>
                <th><?php esc_html_e('What it is', 'vigia-de-bots'); ?></th>
                <th><?php esc_html_e('Who', 'vigia-de-bots'); ?></th>
                <th><?php esc_html_e('Page', 'vigia-de-bots'); ?></th>
            </tr></thead>
            <tbody>
            <?php foreach (BCR_Store::last_visits($pp, ($pg - 1) * $pp) as $v) : ?>
                <tr>
                    <td><?php echo esc_html(mysql2date('d M H:i', $v->ts)); ?></td>
                    <td><code><?php echo esc_html($v->ip); ?></code></td>
                    <td class="bcr-b-<?php echo esc_attr($v->bucket); ?>"><?php echo esc_html(BCR_Report::bucket_label($v->bucket)); ?></td>
                    <td><?php echo esc_html($v->who !== '' ? $v->who : '—'); ?>
                        <?php if ($v->rdns && $v->rdns !== '-') : ?><br><small><?php echo esc_html($v->rdns); ?></small><?php endif; ?></td>
                    <td><code><?php echo esc_html($v->path); ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1) : ?>
        <div class="bcr-pag">
            <?php if ($pg > 1) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg - 1), $base)); ?>">‹ <?php esc_html_e('Previous', 'vigia-de-bots'); ?></a>
            <?php endif; ?>
            <span><?php printf(esc_html__('Page %1$d of %2$d', 'vigia-de-bots'), (int) $pg, (int) $pages); ?></span>
            <?php if ($pg < $pages) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg + 1), $base)); ?>"><?php esc_html_e('Next', 'vigia-de-bots'); ?> ›</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php
    }

    /** Gráfico de barras 30 días: verde humanos+buenos, rojo bots malos. SVG puro. */
    private static function chart() {
        $days = BCR_Store::daily(30);
        $max = 1;
        foreach ($days as $d) {
            $max = max($max, (int) $d['total']);
        }
        $w = 900; $h = 160; $bw = $w / max(1, count($days));
        echo '<svg class="bcr-chart" viewBox="0 0 ' . (int) $w . ' ' . (int) ($h + 18) . '" role="img" aria-label="' . esc_attr__('Visits chart: humans vs bots', 'vigia-de-bots') . '">';
        foreach ($days as $i => $d) {
            $good = (int) $d['humano'] + (int) $d['bueno'];
            $bad  = (int) $d['impostor'] + (int) $d['datacenter'] + (int) $d['declarado'];
            $x = $i * $bw + 2;
            $hg = round($good / $max * $h);
            $hb = round($bad / $max * $h);
            echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($h - $hg - $hb) . '" width="' . esc_attr($bw - 4) . '" height="' . esc_attr($hb) . '" fill="#d63638"><title>' . esc_attr($d['d'] . ' — bots: ' . $bad) . '</title></rect>';
            echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($h - $hg) . '" width="' . esc_attr($bw - 4) . '" height="' . esc_attr($hg) . '" fill="#00a32a"><title>' . esc_attr($d['d'] . ' — ' . esc_attr__('humans + good bots', 'vigia-de-bots') . ': ' . $good) . '</title></rect>';
            if ($i % 5 === 0) {
                echo '<text x="' . esc_attr($x) . '" y="' . esc_attr($h + 14) . '" font-size="10">' . esc_html(substr($d['d'], 5)) . '</text>';
            }
        }
        echo '</svg>';
        echo '<p class="description">🟩 ' . esc_html__('humans + good bots', 'vigia-de-bots') . ' · 🟥 ' . esc_html__('bad bots (impostors, data centers, scrapers)', 'vigia-de-bots') . '</p>';
    }

    /**
     * Tema por variables. Regla de oro: NINGÚN color fuera de las variables
     * (el fallo del modo noche v0.1: la cabecera de la tabla se quedaba con el
     * blanco de WP y las etiquetas eran ilegibles).
     */
    private static function css() {
        $vars_dark = '--bcr-bg:#1b1e23;--bcr-card:#23272e;--bcr-border:#3a3f47;--bcr-text:#dfe3e8;--bcr-muted:#9aa2ac;--bcr-code:#2c313a;';
        return '
        .bcr-root{--bcr-bg:#f0f0f1;--bcr-card:#fff;--bcr-border:#dcdcde;--bcr-text:#1d2327;--bcr-muted:#777;--bcr-code:#f0f0f1;
            background:var(--bcr-bg);color:var(--bcr-text);margin:12px 20px 0 0;padding:16px;border-radius:8px}
        @media (prefers-color-scheme: dark){ .bcr-root:not(.bcr-light){' . $vars_dark . '} }
        .bcr-root.bcr-dark{' . $vars_dark . '}
        .bcr-root h1,.bcr-root h2{color:var(--bcr-text)}
        .bcr-head{display:flex;justify-content:space-between;align-items:center}
        .bcr-sub{font-size:14px;color:var(--bcr-muted);font-weight:normal;margin-left:8px}
        .bcr-theme-toggle{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:50%;
            width:36px;height:36px;font-size:16px;cursor:pointer;line-height:1}
        .bcr-cards{display:flex;gap:16px;flex-wrap:wrap;margin:16px 0}
        .bcr-card{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:16px 20px;min-width:200px;flex:1;color:var(--bcr-text)}
        .bcr-card .bcr-big{font-size:28px;font-weight:700;line-height:1.2}
        .bcr-card-money{border-color:#d63638}
        .bcr-card-money .bcr-big{color:#e65054}
        .bcr-rpm-form{margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:6px}
        .bcr-rpm-form label{font-weight:600}
        .bcr-rpm-form input{width:80px;background:var(--bcr-card);color:var(--bcr-text);border:1px solid var(--bcr-border)}
        .bcr-rpm-form .bcr-muted{flex-basis:100%}
        .bcr-card-cta{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:8px}
        .bcr-muted{color:var(--bcr-muted);font-size:12px}
        .bcr-root .description{color:var(--bcr-muted)}
        .bcr-verdict{background:var(--bcr-card);border:1px solid var(--bcr-border);border-left:4px solid var(--bcr-muted);border-radius:6px;padding:12px 20px;margin:16px 0}
        .bcr-verdict h2{margin:4px 0}
        .bcr-verdict-title{margin-left:10px}
        .bcr-v1{border-left-color:#00a32a}.bcr-v1 .bcr-verdict-title{color:#2fb344}
        .bcr-v2{border-left-color:#e08b1a}.bcr-v2 .bcr-verdict-title{color:#e08b1a}
        .bcr-v3{border-left-color:#d63638}.bcr-v3 .bcr-verdict-title{color:#e65054}
        .bcr-buckets{display:flex;flex-direction:column;gap:4px;margin-bottom:16px}
        .bcr-bucket strong{min-width:56px;display:inline-block;text-align:right;margin:0 8px}
        .bcr-chart{width:100%;max-width:900px;height:auto;background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:6px}
        .bcr-chart text{fill:var(--bcr-muted)}
        .bcr-tablebar{display:flex;justify-content:space-between;max-width:1100px;margin:6px 0;color:var(--bcr-muted)}
        .bcr-tablebar a,.bcr-pag a{color:#4f94d4;text-decoration:none;margin:0 3px}
        .bcr-tablebar strong{margin:0 3px}
        .bcr-pag{max-width:1100px;margin:8px 0;display:flex;gap:16px;justify-content:center;color:var(--bcr-muted)}
        .bcr-root table.bcr-table{max-width:1100px;background:var(--bcr-card);border:1px solid var(--bcr-border);color:var(--bcr-text)}
        .bcr-root table.bcr-table thead{background:var(--bcr-card)}
        .bcr-root table.bcr-table thead th,.bcr-root table.bcr-table thead td{background:var(--bcr-card);color:var(--bcr-text);border-color:var(--bcr-border)}
        .bcr-root table.bcr-table th,.bcr-root table.bcr-table td{color:var(--bcr-text);border-color:var(--bcr-border)}
        .bcr-root table.bcr-table tbody tr{background:var(--bcr-card)}
        .bcr-root table.bcr-table tbody tr:nth-child(odd){background:var(--bcr-bg)}
        .bcr-root code{background:var(--bcr-code);color:var(--bcr-text)}
        .bcr-root .form-table th,.bcr-root .form-table td{color:var(--bcr-text)}
        .bcr-root input[type=number],.bcr-root input[type=email]{background:var(--bcr-card);color:var(--bcr-text);border-color:var(--bcr-border)}
        .bcr-b-impostor{color:#e65054;font-weight:700}
        .bcr-b-datacenter{color:#e08b1a;font-weight:600}
        .bcr-b-bueno{color:#4f94d4}
        .bcr-b-humano{color:#2fb344}
        ';
    }

    /** Botón 🌙/☀️: fuerza noche o día y lo recuerda; sin elección, manda el sistema. */
    private static function theme_js() {
        return "(function(){\n"
            . "var root=document.getElementById('bcr-root'),btn=document.getElementById('bcr-theme-toggle');\n"
            . "if(!root||!btn)return;\n"
            . "function sysDark(){return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;}\n"
            . "function effDark(){if(root.classList.contains('bcr-dark'))return true;if(root.classList.contains('bcr-light'))return false;return sysDark();}\n"
            . "function paint(){btn.textContent=effDark()?'\\u2600\\uFE0F':'\\uD83C\\uDF19';}\n"
            . "var saved=null;try{saved=localStorage.getItem('bcr-theme');}catch(e){}\n"
            . "if(saved==='dark')root.classList.add('bcr-dark');\n"
            . "if(saved==='light')root.classList.add('bcr-light');\n"
            . "paint();\n"
            . "btn.addEventListener('click',function(){\n"
            . "var toDark=!effDark();\n"
            . "root.classList.toggle('bcr-dark',toDark);\n"
            . "root.classList.toggle('bcr-light',!toDark);\n"
            . "try{localStorage.setItem('bcr-theme',toDark?'dark':'light');}catch(e){}\n"
            . "paint();\n"
            . "});\n"
            . "})();";
    }
}
