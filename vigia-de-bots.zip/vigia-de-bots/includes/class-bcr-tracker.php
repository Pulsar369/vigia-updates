<?php
/**
 * Captura de visitas — hook en template_redirect (solo front-end, ya con las
 * condicionales de WP resueltas). En el camino de la visita NO hay ninguna
 * llamada externa: clasificar es comparar contra listas en memoria.
 */

defined('ABSPATH') || exit;

class BCR_Tracker {

    public static function init() {
        add_action('template_redirect', array(__CLASS__, 'track'), 1);
    }

    public static function track() {
        // Ruido que no aporta: usuarios logueados (el dueño mirándose la web),
        // previews, robots.txt y favicon (no son páginas vistas).
        if (is_user_logged_in() || is_preview() || is_robots() || is_favicon()) {
            return;
        }
        if (defined('DOING_CRON') && DOING_CRON) {
            return;
        }

        $ip = self::client_ip();
        if ($ip === '') {
            return;
        }
        $ua   = isset($_SERVER['HTTP_USER_AGENT']) ? wp_unslash($_SERVER['HTTP_USER_AGENT']) : '';
        $path = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $path = strtok($path, '?'); // sin query string: menos ruido y ningún dato sensible

        $c = BCR_Classifier::classify($ip, $ua);
        BCR_Store::record($ip, $ua, $path, $c['bucket'], $c['who']);
    }

    /** IP real del visitante: tras Cloudflare llega en CF-Connecting-IP. */
    public static function client_ip() {
        $candidates = array();
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            $candidates[] = $_SERVER['REMOTE_ADDR'];
        }
        foreach ($candidates as $ip) {
            $ip = trim((string) $ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        return '';
    }
}
