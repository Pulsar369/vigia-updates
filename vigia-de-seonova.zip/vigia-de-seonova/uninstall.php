<?php
/**
 * Al desinstalar: fuera tablas y opciones. No dejamos nada.
 */

defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_visits");
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_daily");

delete_option('bcr_rpm');
delete_option('bcr_report_enabled');
delete_option('bcr_report_email');
