<?php
/**
 * Al desinstalar: fuera tablas, opciones, transitorios y tareas programadas.
 * No dejamos nada.
 *
 * Reglas que sigue este fichero (y que debería seguir cualquier plugin nuestro):
 *
 * - NO depende de ninguna clase del plugin. WordPress incluye este fichero
 *   suelto, sin cargar el plugin: si aquí llamáramos a BCR_Store el PHP daría
 *   un error fatal, la petición moriría A MITAD y el plugin se quedaría a
 *   medio borrar. Ese es uno de los motivos clásicos de "no se deja borrar".
 * - Nada de warnings: todo va con comprobaciones.
 * - En multisitio hay que recorrer todos los sitios: opciones y tablas son
 *   de cada uno.
 */

defined('WP_UNINSTALL_PLUGIN') || exit;

/** Limpieza de UN sitio (blog). */
function bcr_uninstall_sitio() {
    global $wpdb;

    // Tablas propias.
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_visits");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_daily");

    // Opciones propias, una por una (lista cerrada: nada de borrar por comodín
    // sin mirar, que un LIKE 'bcr_%' se llevaría por delante opciones de otro
    // plugin que empiece igual).
    $opciones = array(
        'bcr_rpm',
        'bcr_report_enabled',
        'bcr_report_email',
        'bcr_telemetry',
        'bcr_installed_at',
        'bcr_cleanup_aviso',
        'bcr_cleanup_fallos',
        'bcr_autoupdate_default',
    );
    foreach ($opciones as $o) {
        delete_option($o);
    }

    // Transitorios (los de opción y los de sitio).
    $transitorios = array('bcr_cron_ok', 'bcr_cleanup_sello');
    foreach ($transitorios as $t) {
        delete_transient($t);
    }
    delete_site_transient('bcr_update_manifest');

    // Tareas programadas: si se quedan, WordPress intenta lanzar un hook que
    // ya no existe cada 15 minutos.
    wp_clear_scheduled_hook('bcr_enrich_event');
    wp_clear_scheduled_hook('bcr_weekly_event');
}

if (is_multisite()) {
    $bcr_sitios = get_sites(array('fields' => 'ids', 'number' => 0));
    foreach ((array) $bcr_sitios as $bcr_blog_id) {
        switch_to_blog((int) $bcr_blog_id);
        bcr_uninstall_sitio();
        restore_current_blog();
    }
} else {
    bcr_uninstall_sitio();
}

// Salir de la lista de plugins que se actualizan solos (es opción de RED: va
// fuera del bucle de sitios). Si no, queda un nombre huérfano ahí para siempre.
$bcr_yo = defined('WP_UNINSTALL_PLUGIN') ? WP_UNINSTALL_PLUGIN : '';
if ($bcr_yo) {
    $bcr_auto = (array) get_site_option('auto_update_plugins', array());
    $bcr_resto = array_values(array_diff($bcr_auto, array($bcr_yo)));
    if (count($bcr_resto) !== count($bcr_auto)) {
        update_site_option('auto_update_plugins', $bcr_resto);
    }
}
