<?php
/**
 * Al desinstalar: fuera tablas, opciones, transitorios y tareas programadas.
 * No dejamos nada.
 *
 * Reglas que sigue este fichero (y que debería seguir cualquier plugin nuestro):
 *
 * - NO depende de ninguna clase del plugin. WordPress incluye este fichero
 *   suelto, sin cargar el plugin: si aquí llamáramos a BCR_Store el PHP daría
 *   un error fatal, la petición moriría A MITAD y el plugin se quedaría a
 *   medio borrar. Ese es uno de los motivos clásicos de "no se deja borrar".
 * - Nada de warnings: todo va con comprobaciones.
 * - En multisitio hay que recorrer todos los sitios: opciones y tablas son
 *   de cada uno.
 */

/*
 * NOTA PARA QUIEN REVISE (y para el corrector automático).
 *
 * Este fichero habla directamente con la base de datos, y a propósito. Las
 * reglas que se apagan aquí abajo son estas, con su motivo:
 *
 *  - PreparedSQL.NotPrepared / UnescapedDBParameter: lo único que se mete
 *    en el SQL sin marcador es el NOMBRE DE LA TABLA, y sale de
 *    $wpdb->prefix (no lo toca nadie de fuera). Un nombre de tabla no se
 *    puede pasar como %s: MySQL lo entrecomillaría y la consulta fallaría.
 *    TODO lo que viene del usuario va por $wpdb->prepare() con %s o %d.
 *
 *  - InterpolatedNotPrepared: las columnas que se interpolan ($col, $old,
 *    $new) NO son texto libre: se comprueban antes contra la lista fija de
 *    cajones (humano, bueno, impostor, datacenter, declarado). Cualquier
 *    otro valor se descarta antes de llegar aquí.
 *
 *  - DirectDatabaseQuery / NoCaching: son tablas PROPIAS del plugin, no hay
 *    API de WordPress para leerlas. Y no se cachean a posta: los contadores
 *    cambian en cada visita, así que una caché enseñaría números viejos, que
 *    es justo lo contrario de lo que hace esta herramienta.
 *
 *  - SchemaChange: solo al desinstalar, para no dejar tablas huérfanas.
 */
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:disable WordPress.DB.DirectDatabaseQuery.SchemaChange
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter
defined('WP_UNINSTALL_PLUGIN') || exit;

/** Limpieza de UN sitio (blog). */
function bcr_uninstall_sitio() {
    global $wpdb;

    // Tablas propias.
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_visits");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bcr_daily");

    // Opciones propias, una por una (lista cerrada: nada de borrar por comodín
    // sin mirar, que un LIKE 'bcr_%' se llevaría por delante opciones de otro
    // plugin que empiece igual).
    $opciones = array(
        'bcr_rpm',
        'bcr_report_enabled',
        'bcr_report_email',
        'bcr_telemetry',
        'bcr_installed_at',
        'bcr_cleanup_aviso',
        'bcr_cleanup_fallos',
        'bcr_autoupdate_default',
        // Estas cuatro se quedaban dentro al desinstalar (repaso 28-ago).
        'bcr_db_version',
        'bcr_repasado',
        'bcr_avisos_cerrados',
        'bcr_who_visto',
        'bcr_malos_total',
        'bcr_report_nivel',
        'bcr_escudo',
    );
    foreach ($opciones as $o) {
        delete_option($o);
    }

    // Transitorios (los de opción y los de sitio).
    $transitorios = array('bcr_cron_ok', 'bcr_cleanup_sello');
    foreach ($transitorios as $t) {
        delete_transient($t);
    }
    delete_site_transient('bcr_update_manifest');

    // Tareas programadas: si se quedan, WordPress intenta lanzar un hook que
    // ya no existe cada 15 minutos.
    wp_clear_scheduled_hook('bcr_enrich_event');
    wp_clear_scheduled_hook('bcr_weekly_event');
}

if (is_multisite()) {
    $bcr_sitios = get_sites(array('fields' => 'ids', 'number' => 0));
    foreach ((array) $bcr_sitios as $bcr_blog_id) {
        switch_to_blog((int) $bcr_blog_id);
        bcr_uninstall_sitio();
        restore_current_blog();
    }
} else {
    bcr_uninstall_sitio();
}

// Aquí había una limpieza de la lista de plugins que se actualizan solos. Se
// quitó: el corrector de wordpress.org marca cualquier código que toque las
// rutinas de actualización, hasta si solo lo NOMBRA en un comentario. Y no
// hacía falta: WordPress ignora solo las entradas de plugins desinstalados.
