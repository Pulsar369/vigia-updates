<?php
/**
 * Plugin Name:       VigIA de SeoNova
 * Plugin URI:        https://seonova.pro/es/vigia
 * Description:       Radar de bots: quién visita tu web, con qué intención y cuánto te cuesta en dinero. Detecta Googlebots falsos, enjambres de centros de datos y raspadores — y te dice cuánto ensucian tus métricas y tus anuncios.
 * Version:           0.7.9
 * Author:            SeoNova
 * Author URI:        https://seonova.pro
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.2
 * Requires PHP:      7.4
 * Text Domain:       vigia-de-seonova
 */

defined('ABSPATH') || exit;

// Guard maestro — si ya hay otra instancia activa, salir limpiamente.
if (defined('BCR_VERSION')) {
    return;
}

define('BCR_VERSION', '0.7.9');
define('BCR_FILE', __FILE__);
define('BCR_DIR', plugin_dir_path(__FILE__));
define('BCR_URL', plugin_dir_url(__FILE__));
define('BCR_OPTION_PREFIX', 'bcr_');
// A dónde manda el botón "Páralos": la página de WPO Toolkit en seonova.pro
// (hoy = lista de espera; cuando salga a la venta, la misma página venderá).
define('BCR_CTA_URL_ES', 'https://seonova.pro/es/optimizacion-wordpress/?utm_source=vigia-de-seonova&utm_medium=plugin&utm_campaign=paralos');
define('BCR_CTA_URL_EN', 'https://seonova.pro/en/wordpress-optimization/?utm_source=vigia-de-seonova&utm_medium=plugin&utm_campaign=paralos');
/** CTA en el idioma pedido ('es'/'en'). */
function bcr_cta_url($lang) {
    return $lang === 'en' ? BCR_CTA_URL_EN : BCR_CTA_URL_ES;
}
// Buzón del plugin en seonova.pro (dudas/opiniones + telemetría opt-in).
define('BCR_API_URL', 'https://seonova.pro/api/vigia');
// Slug en wordpress.org — VACÍO hasta que el plugin esté aprobado allí. Al
// rellenarlo se activa solo el aviso "déjanos una reseña" (a los 14 días).
define('BCR_WPORG_SLUG', '');
// Guía fácil de Cloudflare en el blog de SeoNova (publicada 2026-08-25, ES+EN).
define('BCR_LEARN_CF_URL_ES', 'https://seonova.pro/es/blog/que-hace-cloudflare-por-tu-web-2026/?utm_source=vigia-de-seonova&utm_medium=plugin&utm_campaign=verdict');
define('BCR_LEARN_CF_URL_EN', 'https://seonova.pro/en/blog/what-cloudflare-does-for-your-website-2026/?utm_source=vigia-de-seonova&utm_medium=plugin&utm_campaign=verdict');
// Página de novedades del plugin en seonova.pro (la que se enlaza en el correo
// que manda WordPress cuando el plugin se actualiza solo).
define('BCR_NEWS_URL_ES', 'https://seonova.pro/es/vigia/novedades');
define('BCR_NEWS_URL_EN', 'https://seonova.pro/en/vigia/changelog');
// Canal de auto-actualización (público, GitHub raw). Vacío = plugin normal sin
// auto-update. Mientras no esté en wordpress.org, el manifest vive aquí.
define('BCR_UPDATE_MANIFEST', 'https://raw.githubusercontent.com/Pulsar369/vigia-updates/main/manifest.json');

require_once BCR_DIR . 'includes/ranges.php';
require_once BCR_DIR . 'includes/fichas.php';
require_once BCR_DIR . 'includes/class-bcr-fichas.php';
require_once BCR_DIR . 'includes/class-bcr-cache.php';
require_once BCR_DIR . 'includes/class-bcr-classifier.php';
require_once BCR_DIR . 'includes/class-bcr-store.php';
require_once BCR_DIR . 'includes/class-bcr-tracker.php';
require_once BCR_DIR . 'includes/class-bcr-enricher.php';
require_once BCR_DIR . 'includes/class-bcr-report.php';
require_once BCR_DIR . 'includes/class-bcr-export.php';
// Los dos módulos que NO viajan a wordpress.org. Allí el canal de
// actualización es el suyo (un plugin alojado allí no puede actualizarse
// solo desde fuera) y un plugin que borra carpetas de otros plugins es
// rechazo directo. El empaquetador los saca del ZIP y define BCR_WPORG;
// los class_exists() de abajo hacen que no falte nada aunque no estén.
if (!defined('BCR_WPORG')) {
    require_once BCR_DIR . 'includes/class-bcr-updater.php';
    require_once BCR_DIR . 'includes/class-bcr-cleanup.php';
}
if (is_admin()) {
    require_once BCR_DIR . 'includes/class-bcr-admin.php';
    BCR_Admin::init();
    if (class_exists('BCR_Cleanup')) {
        BCR_Cleanup::init();
    }
    BCR_Export::init();
}

BCR_Tracker::init();
BCR_Enricher::init();
BCR_Report::init();
if (class_exists('BCR_Updater')) {
    BCR_Updater::init();
}

// Traducciones: base en inglés, español empaquetado en /languages.
//
// El idioma del panel se puede forzar a mano (botón ES/EN, guardado por usuario
// en user_meta bcr_lang). La forma FIABLE de aplicarlo es el filtro
// 'plugin_locale': decide el idioma JUSTO al cargar el textdomain (principio de
// la petición). Hacerlo a mitad con switch_to_locale + recargar NO intercambia
// las traducciones ya cargadas en WP moderno (bug 0.4.0 → arreglado en 0.4.1).
// Solo en admin: en el front y en los emails manda el idioma del sitio.
add_filter('plugin_locale', function ($locale, $domain) {
    if ($domain === 'vigia-de-seonova' && is_admin() && function_exists('get_current_user_id') && get_current_user_id()) {
        $p = get_user_meta(get_current_user_id(), 'bcr_lang', true);
        if ($p === 'es') {
            return 'es_ES';
        }
        if ($p === 'en') {
            return 'en_US';
        }
    }
    return $locale;
}, 10, 2);
add_action('init', function () {
    load_plugin_textdomain('vigia-de-seonova', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

// Intervalo de 15 min para el enriquecedor rDNS.
add_filter('cron_schedules', function ($schedules) {
    if (!isset($schedules['bcr_quarter'])) {
        $schedules['bcr_quarter'] = array(
            'interval' => 15 * MINUTE_IN_SECONDS,
            'display'  => __('Every 15 minutes (VigIA de SeoNova)', 'vigia-de-seonova'),
        );
    }
    return $schedules;
});

// Auto-cura del cron (comprobación 1 vez/hora): la activación programa los
// eventos, pero si algo los borra (limpiadores de cron, migración de slug,
// update sin reactivar) el radar se queda ciego sin avisar. Caso real
// 2026-08-25: el enriquecedor rDNS nunca corrió en un sitio y una IP de
// Google Cloud se quedó etiquetada "humano" una hora.
add_action('init', function () {
    if (get_transient('bcr_cron_ok')) {
        return;
    }
    set_transient('bcr_cron_ok', 1, HOUR_IN_SECONDS);
    if (!wp_next_scheduled('bcr_enrich_event')) {
        wp_schedule_event(time() + MINUTE_IN_SECONDS, 'bcr_quarter', 'bcr_enrich_event');
    }
    if (!wp_next_scheduled('bcr_weekly_event')) {
        $ts = strtotime('next monday 08:00', current_time('timestamp'));
        $ts = $ts - (int) (get_option('gmt_offset') * HOUR_IN_SECONDS);
        wp_schedule_event($ts, 'weekly', 'bcr_weekly_event');
    }
    // Los updates no pasan por la activación → asegurar también aquí.
    if (get_option('bcr_installed_at') === false) {
        add_option('bcr_installed_at', time());
    }
});

register_activation_hook(__FILE__, function () {
    BCR_Store::create_tables();
    // Al activar: barrer restos de instalaciones viejas (carpetas con otro
    // nombre, ficheros sueltos de un ZIP mal empaquetado). Que el usuario no
    // tenga que entrar por FTP a limpiar lo que ensuciamos nosotros.
    if (class_exists('BCR_Cleanup')) {
        BCR_Cleanup::barrer();
    }
    if (!wp_next_scheduled('bcr_enrich_event')) {
        wp_schedule_event(time() + 5 * MINUTE_IN_SECONDS, 'bcr_quarter', 'bcr_enrich_event');
    }
    if (!wp_next_scheduled('bcr_weekly_event')) {
        // Próximo lunes a las 08:00 hora del sitio.
        $ts = strtotime('next monday 08:00', current_time('timestamp'));
        // strtotime devuelve hora "del sitio" interpretada como UTC → corregir offset.
        $ts = $ts - (int) (get_option('gmt_offset') * HOUR_IN_SECONDS);
        wp_schedule_event($ts, 'weekly', 'bcr_weekly_event');
    }
    if (get_option('bcr_report_email') === false) {
        add_option('bcr_report_email', get_option('admin_email'));
    }
    if (get_option('bcr_report_enabled') === false) {
        add_option('bcr_report_enabled', '1');
    }
    // Fecha de instalación (para el aviso de reseña a los 14 días).
    if (get_option('bcr_installed_at') === false) {
        add_option('bcr_installed_at', time());
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('bcr_enrich_event');
    wp_clear_scheduled_hook('bcr_weekly_event');
});
