=== VigIA de SeoNova ===
Contributors: edison72
Tags: bots, security, adsense, analytics, crawler
Requires at least: 5.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.8.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bot radar: who visits your site, what they want, and what they cost you in money. / Radar de bots: quién te visita y cuánto te cuesta en dinero.

== Description ==

Do you know how many of your "visits" are bots? And how much money they cost you?

VigIA de SeoNova classifies every visit into 5 buckets:

* 🟢 **Humans**
* 🔵 **Verified good bots** — the real Googlebot and Bingbot, verified by IP
  against the official ranges Google and Bing publish (a User-Agent disguise
  can be faked; the official IP range cannot).
* 🔴 **IMPOSTORS** — they claim to be Googlebot and their IP is not Google's.
* 🟠 **Data centers** — IPs from AWS, Hetzner, Huawei Cloud… disguised as a
  person with a browser.
* ⚪ **Declared bots** — AI scrapers (GPTBot, ClaudeBot), SEO spies (Ahrefs,
  Semrush), tools (curl, python).

And the important part: **it tells you what they cost**. Enter your AdSense
RPM and the radar estimates how many dollars per month of junk traffic are
polluting your metrics and your ads.

Every Monday you get an email: "Bots cost you ~$X this week".

**This plugin only watches, it does not block.** Built for shared hosting:
circular buffer of 1,000 visits, zero external calls in the visit path, zero
database growth. Interface in English and Spanish.

= En español =

¿Sabes cuántas de tus "visitas" son bots? ¿Y cuánto dinero te cuestan?

VigIA de SeoNova clasifica cada visita en 5 cajones: humanos, bots buenos
VERIFICADOS por IP oficial (el disfraz se falsifica, el rango oficial no),
IMPOSTORES que dicen ser Googlebot sin serlo, centros de datos disfrazados
de persona, y bots declarados (IA, SEO, herramientas).

Y lo más importante: **te dice cuánto te cuestan**. Metes tu RPM de AdSense
y el radar estima cuántos dólares al mes de tráfico basura están ensuciando
tus métricas y tus anuncios. Cada lunes te llega un email con el resumen.

**Este plugin solo mira, no bloquea.** Pensado para hosting compartido:
búfer circular de 1.000 visitas, cero llamadas externas en el camino de la
visita, cero crecimiento de base de datos. Interfaz en español e inglés.

== Installation ==

1. Upload the `vigia-de-seonova` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to "Vigía" in the menu and enter your AdSense RPM.

== Frequently Asked Questions ==

= Does it send my data anywhere? =

Nothing about your visitors ever leaves your site: every visit is classified
and stored inside your own WordPress.

Three things do talk to the outside, and you decide on all three:

* **Updates.** The plugin reads a small version file to see whether there is a
  newer release. It sends nothing with the request.
* **Anonymous stats, off by default.** Only if you tick the box in the settings:
  once a week it sends aggregated counts (verdict level, bot percentages) to
  seonova.pro. Never your domain, never IP addresses, never visitors.
* **The feedback box.** Only when you write in it and press send.

Reverse DNS lookups do go out to the internet, against the visitor IP, the same
way any server log tool resolves names.

= What does it store about my visitors? =

The last 1,000 visits, with date, IP address, user agent, the page requested and
the reverse DNS name; plus one row per day with the counters, kept for 60 days.
Both tables are deleted when you uninstall the plugin. Nothing is shared with
anyone. If your site needs a cookie or privacy notice, this is the part to
mention: the plugin records the IP address of every visit.

= Does it slow down my site? =

No. Classifying a visit means comparing against in-memory lists
(microseconds). The only network lookup (reverse DNS) runs in the background
every 15 minutes, never during a visit.

= How does it know a Googlebot is fake? =

By IP. Google and Bing publish their official IP ranges. If the User-Agent
says "Googlebot" but the IP is not in those ranges, it is an impostor.

== Screenshots ==

1. The panel at a glance: how many visits you had, how many of them were bots, what that junk traffic costs you, and the verdict on what your site actually needs.
2. Who has visited, split in two: good bots on one side, bad ones on the other. Open any of them and it tells you what it is, whether it brings you visits, whether it respects robots.txt, and which pages it took.
3. Day by day for the last month, and the latest visits with the address, what it is and the page it asked for.

== Changelog ==

= 0.8.5 =
* Correct WordPress.org username in the readme.

= 0.8.4 =
* Screenshot captions for the WordPress.org listing.

= 0.8.3 =
* Translations are now loaded with load_textdomain() instead of the plugin
  helper WordPress.org discourages. The bundled Spanish and the ES/EN switch
  keep working exactly the same.

= 0.8.2 =
* The update-channel address now lives inside the updater file, so it is not
  even mentioned in the WordPress.org package.

= 0.8.1 =
* Second pass of the official Plugin Check: the last translator comments,
  escaping notes and header details.

= 0.8.0 =
* Passes the official Plugin Check with no errors: escaping, translator
  comments, input sanitising, no direct file writes, styles and scripts
  loaded the WordPress way.
* Requires WordPress 5.4 (it already used a function from that version).

= 0.7.9 =
* Chart bars have a maximum width. With only a few days of data they used to
  come out as huge blocks side by side, more wall than chart.

= 0.7.8 =
* The daily chart now spans the full width of the screen, and is wider than
  it is tall instead of turning into a giant square. Bars scale with the
  space they have.

= 0.7.7 =
* The daily chart now draws the days you actually have, not 30 always. With
  the plugin freshly installed it used to be four bars squashed against the
  right edge of an empty box.
* It also has a grid with the numbers on the side, so the bars can be read,
  and dates along the bottom.

= 0.7.6 =
* The "who has visited" lists now open with a coloured header row, blue for
  good bots and red for bad ones, with the total beside it. You can tell
  which list you are reading at a glance.
* The panel uses the full width instead of stopping halfway across the
  screen.
* The last-30-days block leads with three coloured labels (humans, good
  bots, bad bots) and a thin proportion bar underneath.
* Fixed: in dark mode the "I want WPO Toolkit to stop them" link was dark
  blue on a dark background and could not be read.

= 0.7.5 =
* Honest privacy answer in the FAQ. It used to say "no external services, no
  telemetry", which stopped being true when the update check, the opt-in
  anonymous stats and the feedback box were added. It now says exactly what
  goes out, when, and what is stored about your visitors.
* Tested up to WordPress 7.1 (the readme still claimed 6.8).

= 0.7.4 =
* Fixed: your own site visiting itself (WP Rocket preload, WordPress
  internal calls) was counted as human visits.
* Fixed: bots whose name ends in "Bot" glued to another word (YouBot,
  Amzn-SearchBot) and names with an underscore (peer39_crawler) were
  counted as people.
* Seven crawlers now show their real name instead of a cut URL or
  "Mozilla": YouBot, Amazon SearchBot, Sogou, Peer39, Proximic, HubSpot,
  SofyaBot.

= 0.7.3 =
* New button under the weekly report settings: "Send me a test report now".
  It sends the real Monday email with your real data, so you can see it
  without waiting for Monday. It does not use up the level-change notice.

= 0.7.2 =
* The Monday report now compares you with last week, shows what bots have
  cost you since you installed VigIA, announces the verdict only when the
  level changes, flags bots seen for the first time and rotates one WPO
  Toolkit advantage each week. Quiet week, three-line email.
* Fixed: "the last 7 days" counted 8, and the day boundary used UTC instead
  of your site time.

= 0.7.1 =
* The verdict no longer waits in silence: with 3 days and 200 visits it
  already tells you what your site needs, clearly marked as preliminary, and
  confirms it once there are 1,000 visits.
* If there is a shield in front of your site (Cloudflare, Sucuri,
  QUIC.cloud), the panel says so: whatever it blocks never reaches WordPress,
  so what you see here is what got through.

= 0.7.0 =
* Colours in the latest-visits list: green for a person, blue for a verified
  good bot, red for a bad one.
* Two buttons to download what you see as CSV: the visits in detail and the
  day-by-day summary.
* The detailed buffer now keeps 1,000 visits instead of 500.
* GoogleOther (the Google crawler that is NOT the Search one) now shows its
  name and its file instead of appearing as "Mozilla". Any bot disguised as a
  browser now shows its real name too.

= 0.6.4 =
* If your site has a page cache (WP Rocket, LiteSpeed, W3 Total Cache and
  others), the panel now says so: VigIA only counts what reaches WordPress, so
  with a cache in front the totals are a floor, not the full number.

= 0.6.3 =
* When the plugin updates itself, the email WordPress sends you now tells you
  what changed, in your language, with a link to the full news page.

= 0.6.2 =
* Fixed: right after updating, the plugins list could keep showing "there is a
  new version available" for a version you already had installed, and the
  notice stayed there for hours. The plugin now reads its version from the file
  on disk instead of trusting the copy PHP still has in memory, and a stale
  notice clears itself on the next admin page.

= 0.6.1 =
* The plugin is now signed by its real author: SeoNova.

= 0.6.0 =
* Click any visitor's name — good or bad — and it opens up: what it is, why it
  landed in that list, whether it brings you visits, whether it respects
  robots.txt, when it first and last showed up, which pages it took, which
  addresses it came from and how it introduces itself.
* Files on the best known bots (Google, Bing, AdSense, GPTBot, ClaudeBot,
  Bytespider, Ahrefs, Semrush, Yandex, Baidu…) in plain words.
* Updates itself when a new version comes out. Auto-updates are ON from the
  start; the switch is yours in the plugins list if you would rather approve
  each update by hand.
* Cleans up leftovers from older installs by itself (this plugin used to be
  called Bot Cost Radar and then Vigia de Bots). No more ghost entries in the
  plugins list that refuse to be deleted, and no more FTP. If a file cannot be
  removed because of permissions, the plugin now says exactly which path it is.

= 0.5.0 =
* "Stop them" button now goes to the real WPO Toolkit page on seonova.pro
  (waiting list today, store when it launches), in the panel's language.
* New collapsible "Want to leave us a question or your opinion?" form at the
  bottom of the panel — sent server-side to our inbox, optionally attaching
  your site's diagnosis so we can help better.
* Each bad bot now shows what WPO Toolkit would do about it.
* Optional anonymous weekly stats (opt-in, off by default; never your domain,
  IPs or visitors).
* Review reminder prepared (stays dormant until the plugin is on wordpress.org).

= 0.4.8 =
* Google Cloud and AWS supernets added to the built-in data-center list: a
  cloud VM browsing with a normal browser UA is now flagged as data center
  instantly (real case: a Google Cloud IP crawling a whole site as "human").
* Cron self-heal: if the rDNS enricher or weekly report events ever go
  missing, they are re-scheduled automatically (checked once per hour).
* rDNS pass now has a 10s time budget so slow DNS can never kill the run.
* Duplicate visits (same IP + same page within 60s) are recorded once.

= 0.4.7 =
* The Cloudflare guide link now points to the published article on
  seonova.pro, in the panel's language (ES/EN).

= 0.4.6 =
* Every verdict level now links to a plain-language guide on our blog about
  what Cloudflare can do for your site (free vs Pro).

= 0.4.5 =
* Verdict box now tinted green / amber / red according to the verdict level
  (also in preliminary mode, where the border stays dashed).
* Level 1 also mentions Cloudflare: not needed for bots at that level, but as
  an optional free bonus that speeds up the site.

= 0.4.4 =
* Verdict texts rewritten for people who do not know what Cloudflare or
  "layers" are: each level now explains WHAT it recommends and WHY (free
  shield in front of your site, Pro tier for swarms, price included).

= 0.4.3 =
* Verdict now recommends 3 days with traffic and 1,000 visits (more visits =
  finer read).
* Impatient? A "Show me the verdict now anyway" button reveals a preliminary
  verdict before the recommended data is in, clearly marked as preliminary.
* Removed the temporary language diagnostic line.

= 0.4.2 =
* Language switch: force-load the exact .mo right before rendering (belt and
  suspenders on top of the plugin_locale filter) + a temporary diagnostic line
  to pin down any remaining issue.

= 0.4.1 =
* Fix: the ES/EN language switch had no effect. Now the chosen language is
  applied via the plugin_locale filter when translations load, instead of
  switching mid-page (which WordPress ignored for already-loaded strings).

= 0.4.0 =
* Panel language switch (ES/EN) next to the theme toggle, remembered per user
  like the dark/light choice.
* Verdict card now shows a progress bar filling toward the data it needs
  (days with traffic + visits) instead of just a text line.

= 0.3.1 =
* "Check for updates" link moved to the description row (next to Version | By |
  Visit plugin site) instead of the Deactivate action row.

= 0.3.0 =
* Renamed to VigIA de SeoNova.
* Dark mode: fixed the leftover white box (tables no longer use WordPress's
  white 'widefat' style; the whole admin column follows the theme).

= 0.2.5 =
* Names each bot: AdSense, Googlebot, Bingbot, Bing Ads… and a 'Who has
  visited' section listing good vs bad bots with what each one is.

= 0.2.4 =
* Clearer chart: humans (green), good bots (blue), bad bots (red) shown
  separately — a big weekly bar with counts + a 30-day stacked chart.

= 0.2.3 =
* Static files (fonts, images, CSS, JS) no longer counted as visits — one
  pageview pulls dozens of them and they flooded the list.
* Dark mode now paints the whole WordPress content column, no light gap.

= 0.2.2 =
* "Check for updates" link on the plugin row — no need to wait for the 6h check.

= 0.2.1 =
* Self-update from a public channel: no more manual ZIP uploads.

= 0.2.0 =
* Verdict without AI: with enough history the radar tells you if WPO Toolkit
  alone is enough, or you need free Cloudflare, or Cloudflare Pro — fixed,
  auditable thresholds.
* RPM setting moved next to the money card (where you see its effect).
* Visits table: per-page selector (10/25/50/100, remembered) + pagination.
* Dark mode fixes (table header was unreadable).


= 0.1.0 =
* First version: 5-bucket radar, cost estimate from your RPM, dashboard with
  30-day chart and dark/light mode, weekly email report. English and Spanish.
