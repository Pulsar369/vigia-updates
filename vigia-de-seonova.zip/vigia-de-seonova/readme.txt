=== VigIA de SeoNova ===
Contributors: wpotoolkit
Tags: bots, security, adsense, analytics, crawler
Requires at least: 5.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bot radar: who visits your site, what they want, and what they cost you in money. / Radar de bots: quién te visita y cuánto te cuesta en dinero.

== Description ==

Do you know how many of your "visits" are bots? And how much money they cost you?

VigIA de SeoNova classifies every visit into 5 buckets:

* 🟢 **Humans**
* 🔵 **Verified good bots** — the real Googlebot and Bingbot, verified by IP
  against the official ranges Google and Bing publish (a User-Agent disguise
  can be faked; the official IP range cannot).
* 🔴 **IMPOSTORS** — they claim to be Googlebot and their IP is not Google's.
* 🟠 **Data centers** — IPs from AWS, Hetzner, Huawei Cloud… disguised as a
  person with a browser.
* ⚪ **Declared bots** — AI scrapers (GPTBot, ClaudeBot), SEO spies (Ahrefs,
  Semrush), tools (curl, python).

And the important part: **it tells you what they cost**. Enter your AdSense
RPM and the radar estimates how many dollars per month of junk traffic are
polluting your metrics and your ads.

Every Monday you get an email: "Bots cost you ~$X this week".

**This plugin only watches, it does not block.** Built for shared hosting:
circular buffer of 500 visits, zero external calls in the visit path, zero
database growth. Interface in English and Spanish.

= En español =

¿Sabes cuántas de tus "visitas" son bots? ¿Y cuánto dinero te cuestan?

VigIA de SeoNova clasifica cada visita en 5 cajones: humanos, bots buenos
VERIFICADOS por IP oficial (el disfraz se falsifica, el rango oficial no),
IMPOSTORES que dicen ser Googlebot sin serlo, centros de datos disfrazados
de persona, y bots declarados (IA, SEO, herramientas).

Y lo más importante: **te dice cuánto te cuestan**. Metes tu RPM de AdSense
y el radar estima cuántos dólares al mes de tráfico basura están ensuciando
tus métricas y tus anuncios. Cada lunes te llega un email con el resumen.

**Este plugin solo mira, no bloquea.** Pensado para hosting compartido:
búfer circular de 500 visitas, cero llamadas externas en el camino de la
visita, cero crecimiento de base de datos. Interfaz en español e inglés.

== Installation ==

1. Upload the `vigia-de-seonova` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to "Vigía" in the menu and enter your AdSense RPM.

== Frequently Asked Questions ==

= Does it send my data anywhere? =

No. Everything is computed and stored inside your own WordPress. No external
services, no telemetry.

= Does it slow down my site? =

No. Classifying a visit means comparing against in-memory lists
(microseconds). The only network lookup (reverse DNS) runs in the background
every 15 minutes, never during a visit.

= How does it know a Googlebot is fake? =

By IP. Google and Bing publish their official IP ranges. If the User-Agent
says "Googlebot" but the IP is not in those ranges, it is an impostor.

== Changelog ==

= 0.4.2 =
* Language switch: force-load the exact .mo right before rendering (belt and
  suspenders on top of the plugin_locale filter) + a temporary diagnostic line
  to pin down any remaining issue.

= 0.4.1 =
* Fix: the ES/EN language switch had no effect. Now the chosen language is
  applied via the plugin_locale filter when translations load, instead of
  switching mid-page (which WordPress ignored for already-loaded strings).

= 0.4.0 =
* Panel language switch (ES/EN) next to the theme toggle, remembered per user
  like the dark/light choice.
* Verdict card now shows a progress bar filling toward the data it needs
  (days with traffic + visits) instead of just a text line.

= 0.3.1 =
* "Check for updates" link moved to the description row (next to Version | By |
  Visit plugin site) instead of the Deactivate action row.

= 0.3.0 =
* Renamed to VigIA de SeoNova.
* Dark mode: fixed the leftover white box (tables no longer use WordPress's
  white 'widefat' style; the whole admin column follows the theme).

= 0.2.5 =
* Names each bot: AdSense, Googlebot, Bingbot, Bing Ads… and a 'Who has
  visited' section listing good vs bad bots with what each one is.

= 0.2.4 =
* Clearer chart: humans (green), good bots (blue), bad bots (red) shown
  separately — a big weekly bar with counts + a 30-day stacked chart.

= 0.2.3 =
* Static files (fonts, images, CSS, JS) no longer counted as visits — one
  pageview pulls dozens of them and they flooded the list.
* Dark mode now paints the whole WordPress content column, no light gap.

= 0.2.2 =
* "Check for updates" link on the plugin row — no need to wait for the 6h check.

= 0.2.1 =
* Self-update from a public channel: no more manual ZIP uploads.

= 0.2.0 =
* Verdict without AI: with enough history the radar tells you if WPO Toolkit
  alone is enough, or you need free Cloudflare, or Cloudflare Pro — fixed,
  auditable thresholds.
* RPM setting moved next to the money card (where you see its effect).
* Visits table: per-page selector (10/25/50/100, remembered) + pagination.
* Dark mode fixes (table header was unreadable).


= 0.1.0 =
* First version: 5-bucket radar, cost estimate from your RPM, dashboard with
  30-day chart and dark/light mode, weekly email report. English and Spanish.
