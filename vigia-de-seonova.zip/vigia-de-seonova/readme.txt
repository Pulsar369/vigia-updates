=== VigIA de SeoNova ===
Contributors: seonova
Tags: bots, security, adsense, analytics, crawler
Requires at least: 5.2
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.6.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bot radar: who visits your site, what they want, and what they cost you in money. / Radar de bots: quién te visita y cuánto te cuesta en dinero.

== Description ==

Do you know how many of your "visits" are bots? And how much money they cost you?

VigIA de SeoNova classifies every visit into 5 buckets:

* 🟢 **Humans**
* 🔵 **Verified good bots** — the real Googlebot and Bingbot, verified by IP
  against the official ranges Google and Bing publish (a User-Agent disguise
  can be faked; the official IP range cannot).
* 🔴 **IMPOSTORS** — they claim to be Googlebot and their IP is not Google's.
* 🟠 **Data centers** — IPs from AWS, Hetzner, Huawei Cloud… disguised as a
  person with a browser.
* ⚪ **Declared bots** — AI scrapers (GPTBot, ClaudeBot), SEO spies (Ahrefs,
  Semrush), tools (curl, python).

And the important part: **it tells you what they cost**. Enter your AdSense
RPM and the radar estimates how many dollars per month of junk traffic are
polluting your metrics and your ads.

Every Monday you get an email: "Bots cost you ~$X this week".

**This plugin only watches, it does not block.** Built for shared hosting:
circular buffer of 500 visits, zero external calls in the visit path, zero
database growth. Interface in English and Spanish.

= En español =

¿Sabes cuántas de tus "visitas" son bots? ¿Y cuánto dinero te cuestan?

VigIA de SeoNova clasifica cada visita en 5 cajones: humanos, bots buenos
VERIFICADOS por IP oficial (el disfraz se falsifica, el rango oficial no),
IMPOSTORES que dicen ser Googlebot sin serlo, centros de datos disfrazados
de persona, y bots declarados (IA, SEO, herramientas).

Y lo más importante: **te dice cuánto te cuestan**. Metes tu RPM de AdSense
y el radar estima cuántos dólares al mes de tráfico basura están ensuciando
tus métricas y tus anuncios. Cada lunes te llega un email con el resumen.

**Este plugin solo mira, no bloquea.** Pensado para hosting compartido:
búfer circular de 500 visitas, cero llamadas externas en el camino de la
visita, cero crecimiento de base de datos. Interfaz en español e inglés.

== Installation ==

1. Upload the `vigia-de-seonova` folder to `/wp-content/plugins/`.
2. Activate the plugin.
3. Go to "Vigía" in the menu and enter your AdSense RPM.

== Frequently Asked Questions ==

= Does it send my data anywhere? =

No. Everything is computed and stored inside your own WordPress. No external
services, no telemetry.

= Does it slow down my site? =

No. Classifying a visit means comparing against in-memory lists
(microseconds). The only network lookup (reverse DNS) runs in the background
every 15 minutes, never during a visit.

= How does it know a Googlebot is fake? =

By IP. Google and Bing publish their official IP ranges. If the User-Agent
says "Googlebot" but the IP is not in those ranges, it is an impostor.

== Changelog ==

= 0.6.1 =
* The plugin is now signed by its real author: SeoNova.

= 0.6.0 =
* Click any visitor's name — good or bad — and it opens up: what it is, why it
  landed in that list, whether it brings you visits, whether it respects
  robots.txt, when it first and last showed up, which pages it took, which
  addresses it came from and how it introduces itself.
* Files on the best known bots (Google, Bing, AdSense, GPTBot, ClaudeBot,
  Bytespider, Ahrefs, Semrush, Yandex, Baidu…) in plain words.
* Updates itself when a new version comes out. Auto-updates are ON from the
  start; the switch is yours in the plugins list if you would rather approve
  each update by hand.
* Cleans up leftovers from older installs by itself (this plugin used to be
  called Bot Cost Radar and then Vigia de Bots). No more ghost entries in the
  plugins list that refuse to be deleted, and no more FTP. If a file cannot be
  removed because of permissions, the plugin now says exactly which path it is.

= 0.5.0 =
* "Stop them" button now goes to the real WPO Toolkit page on seonova.pro
  (waiting list today, store when it launches), in the panel's language.
* New collapsible "Want to leave us a question or your opinion?" form at the
  bottom of the panel — sent server-side to our inbox, optionally attaching
  your site's diagnosis so we can help better.
* Each bad bot now shows what WPO Toolkit would do about it.
* Optional anonymous weekly stats (opt-in, off by default; never your domain,
  IPs or visitors).
* Review reminder prepared (stays dormant until the plugin is on wordpress.org).

= 0.4.8 =
* Google Cloud and AWS supernets added to the built-in data-center list: a
  cloud VM browsing with a normal browser UA is now flagged as data center
  instantly (real case: a Google Cloud IP crawling a whole site as "human").
* Cron self-heal: if the rDNS enricher or weekly report events ever go
  missing, they are re-scheduled automatically (checked once per hour).
* rDNS pass now has a 10s time budget so slow DNS can never kill the run.
* Duplicate visits (same IP + same page within 60s) are recorded once.

= 0.4.7 =
* The Cloudflare guide link now points to the published article on
  seonova.pro, in the panel's language (ES/EN).

= 0.4.6 =
* Every verdict level now links to a plain-language guide on our blog about
  what Cloudflare can do for your site (free vs Pro).

= 0.4.5 =
* Verdict box now tinted green / amber / red according to the verdict level
  (also in preliminary mode, where the border stays dashed).
* Level 1 also mentions Cloudflare: not needed for bots at that level, but as
  an optional free bonus that speeds up the site.

= 0.4.4 =
* Verdict texts rewritten for people who do not know what Cloudflare or
  "layers" are: each level now explains WHAT it recommends and WHY (free
  shield in front of your site, Pro tier for swarms, price included).

= 0.4.3 =
* Verdict now recommends 3 days with traffic and 1,000 visits (more visits =
  finer read).
* Impatient? A "Show me the verdict now anyway" button reveals a preliminary
  verdict before the recommended data is in, clearly marked as preliminary.
* Removed the temporary language diagnostic line.

= 0.4.2 =
* Language switch: force-load the exact .mo right before rendering (belt and
  suspenders on top of the plugin_locale filter) + a temporary diagnostic line
  to pin down any remaining issue.

= 0.4.1 =
* Fix: the ES/EN language switch had no effect. Now the chosen language is
  applied via the plugin_locale filter when translations load, instead of
  switching mid-page (which WordPress ignored for already-loaded strings).

= 0.4.0 =
* Panel language switch (ES/EN) next to the theme toggle, remembered per user
  like the dark/light choice.
* Verdict card now shows a progress bar filling toward the data it needs
  (days with traffic + visits) instead of just a text line.

= 0.3.1 =
* "Check for updates" link moved to the description row (next to Version | By |
  Visit plugin site) instead of the Deactivate action row.

= 0.3.0 =
* Renamed to VigIA de SeoNova.
* Dark mode: fixed the leftover white box (tables no longer use WordPress's
  white 'widefat' style; the whole admin column follows the theme).

= 0.2.5 =
* Names each bot: AdSense, Googlebot, Bingbot, Bing Ads… and a 'Who has
  visited' section listing good vs bad bots with what each one is.

= 0.2.4 =
* Clearer chart: humans (green), good bots (blue), bad bots (red) shown
  separately — a big weekly bar with counts + a 30-day stacked chart.

= 0.2.3 =
* Static files (fonts, images, CSS, JS) no longer counted as visits — one
  pageview pulls dozens of them and they flooded the list.
* Dark mode now paints the whole WordPress content column, no light gap.

= 0.2.2 =
* "Check for updates" link on the plugin row — no need to wait for the 6h check.

= 0.2.1 =
* Self-update from a public channel: no more manual ZIP uploads.

= 0.2.0 =
* Verdict without AI: with enough history the radar tells you if WPO Toolkit
  alone is enough, or you need free Cloudflare, or Cloudflare Pro — fixed,
  auditable thresholds.
* RPM setting moved next to the money card (where you see its effect).
* Visits table: per-page selector (10/25/50/100, remembered) + pagination.
* Dark mode fixes (table header was unreadable).


= 0.1.0 =
* First version: 5-bucket radar, cost estimate from your RPM, dashboard with
  30-day chart and dark/light mode, weekly email report. English and Spanish.
