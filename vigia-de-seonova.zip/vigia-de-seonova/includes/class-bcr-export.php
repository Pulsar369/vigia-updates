<?php
/**
 * Descargar lo que ves, en CSV.
 *
 * Dos ficheros, porque son dos cosas distintas:
 *  - "visitas": el detalle de las últimas visitas guardadas (las que caben en
 *    el búfer). Sirve para mirar con lupa: quién, desde dónde y a qué página.
 *  - "dias": el resumen por día de los últimos 60. Sirve para gráficos y para
 *    ver la tendencia, y NO se pierde aunque el detalle se vaya rotando.
 *
 * OJO: daily() devuelve ARRAYS (ARRAY_A), no objetos.
 *
 * Separador punto y coma y BOM al principio: así el Excel en español abre el
 * fichero con las columnas ya separadas en vez de meterlo todo en una.
 */

defined('ABSPATH') || exit;

class BCR_Export {

    const ACCION = 'bcr_export';

    public static function init() {
        add_action('admin_post_' . self::ACCION, array(__CLASS__, 'descargar'));
    }

    /** Enlace listo (con su nonce) para un tipo de exportación. */
    public static function url($tipo) {
        return wp_nonce_url(
            admin_url('admin-post.php?action=' . self::ACCION . '&tipo=' . rawurlencode($tipo)),
            self::ACCION
        );
    }

    public static function descargar() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to export this.', 'vigia-de-seonova'), '', array('response' => 403));
        }
        check_admin_referer(self::ACCION);

        $tipo = isset($_GET['tipo']) ? sanitize_key(wp_unslash($_GET['tipo'])) : 'visitas';
        $tipo = $tipo === 'dias' ? 'dias' : 'visitas';

        $nombre = sprintf('vigia-%s-%s.csv', $tipo, gmdate('Y-m-d'));
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nombre . '"');

        $salida = fopen('php://output', 'w');
        fwrite($salida, "\xEF\xBB\xBF");   // BOM: Excel necesita saber que es UTF-8

        if ($tipo === 'dias') {
            self::filas_dias($salida);
        } else {
            self::filas_visitas($salida);
        }

        fclose($salida);
        exit;
    }

    /** Detalle de visitas guardadas, de la más nueva a la más vieja. */
    private static function filas_visitas($salida) {
        fputcsv($salida, array(
            __('Date and time', 'vigia-de-seonova'),
            __('IP', 'vigia-de-seonova'),
            __('What it is', 'vigia-de-seonova'),
            __('Who', 'vigia-de-seonova'),
            __('Reverse DNS', 'vigia-de-seonova'),
            __('Page', 'vigia-de-seonova'),
            __('User-agent', 'vigia-de-seonova'),
        ), ';');

        foreach (BCR_Store::last_visits(BCR_Store::MAX_VISITS, 0) as $v) {
            fputcsv($salida, array(
                $v->ts,
                $v->ip,
                BCR_Report::bucket_label($v->bucket),
                $v->who,
                ($v->rdns && $v->rdns !== '-') ? $v->rdns : '',
                $v->path,
                $v->ua,
            ), ';');
        }
    }

    /** Resumen por día (60 días como mucho: es lo que se guarda). */
    private static function filas_dias($salida) {
        fputcsv($salida, array(
            __('Day', 'vigia-de-seonova'),
            __('Total', 'vigia-de-seonova'),
            __('Humans', 'vigia-de-seonova'),
            __('Verified good bots', 'vigia-de-seonova'),
            __('Impostors', 'vigia-de-seonova'),
            __('Data centers', 'vigia-de-seonova'),
            __('Declared bots', 'vigia-de-seonova'),
        ), ';');

        foreach (BCR_Store::daily(BCR_Store::DAILY_KEEP) as $d) {
            fputcsv($salida, array(
                $d['d'],
                (int) $d['total'],
                (int) $d['humano'],
                (int) $d['bueno'],
                (int) $d['impostor'],
                (int) $d['datacenter'],
                (int) $d['declarado'],
            ), ';');
        }
    }
}
