<?php
/**
 * Descargar lo que ves, en CSV.
 *
 * Dos ficheros, porque son dos cosas distintas:
 *  - "visitas": el detalle de las últimas visitas guardadas (las que caben en
 *    el búfer). Sirve para mirar con lupa: quién, desde dónde y a qué página.
 *  - "dias": el resumen por día de los últimos 60. Sirve para gráficos y para
 *    ver la tendencia, y NO se pierde aunque el detalle se vaya rotando.
 *
 * OJO: daily() devuelve ARRAYS (ARRAY_A), no objetos.
 *
 * Separador punto y coma y BOM al principio: así el Excel en español abre el
 * fichero con las columnas ya separadas en vez de meterlo todo en una.
 */

defined('ABSPATH') || exit;

class BCR_Export {

    const ACCION = 'bcr_export';

    public static function init() {
        add_action('admin_post_' . self::ACCION, array(__CLASS__, 'descargar'));
    }

    /** Enlace listo (con su nonce) para un tipo de exportación. */
    public static function url($tipo) {
        return wp_nonce_url(
            admin_url('admin-post.php?action=' . self::ACCION . '&tipo=' . rawurlencode($tipo)),
            self::ACCION
        );
    }

    public static function descargar() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to export this.', 'vigia-de-seonova'), '', array('response' => 403));
        }
        check_admin_referer(self::ACCION);

        $tipo = isset($_GET['tipo']) ? sanitize_key(wp_unslash($_GET['tipo'])) : 'visitas';
        $tipo = $tipo === 'dias' ? 'dias' : 'visitas';

        $nombre = sprintf('vigia-%s-%s.csv', $tipo, gmdate('Y-m-d'));
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nombre . '"');

        // BOM: sin él, Excel abre el fichero como si no fuera UTF-8 y parte
        // los acentos. Se arma todo en memoria: nada de escribir a fichero.
        $csv = "\xEF\xBB\xBF" . ($tipo === 'dias' ? self::filas_dias() : self::filas_visitas());

        // Esto es un CSV que se descarga, no HTML: escaparlo lo rompería. Cada
        // campo va entre comillas y las comillas de dentro van dobladas.
        echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    /**
     * Una línea de CSV. Punto y coma de separador (es lo que espera el Excel
     * español) y salto CRLF, que es lo que dice la norma del formato.
     */
    private static function linea($campos) {
        $fuera = array();
        foreach ($campos as $c) {
            $fuera[] = '"' . str_replace('"', '""', (string) $c) . '"';
        }
        return implode(';', $fuera) . "\r\n";
    }

    /** Detalle de visitas guardadas, de la más nueva a la más vieja. */
    private static function filas_visitas() {
        $csv = self::linea(array(
            __('Date and time', 'vigia-de-seonova'),
            __('IP', 'vigia-de-seonova'),
            __('What it is', 'vigia-de-seonova'),
            __('Who', 'vigia-de-seonova'),
            __('Reverse DNS', 'vigia-de-seonova'),
            __('Page', 'vigia-de-seonova'),
            __('User-agent', 'vigia-de-seonova'),
        ));

        foreach (BCR_Store::last_visits(BCR_Store::MAX_VISITS, 0) as $v) {
            $csv .= self::linea(array(
                $v->ts,
                $v->ip,
                BCR_Report::bucket_label($v->bucket),
                $v->who,
                ($v->rdns && $v->rdns !== '-') ? $v->rdns : '',
                $v->path,
                $v->ua,
            ));
        }

        return $csv;
    }

    /** Resumen por día (60 días como mucho: es lo que se guarda). */
    private static function filas_dias() {
        $csv = self::linea(array(
            __('Day', 'vigia-de-seonova'),
            __('Total', 'vigia-de-seonova'),
            __('Humans', 'vigia-de-seonova'),
            __('Verified good bots', 'vigia-de-seonova'),
            __('Impostors', 'vigia-de-seonova'),
            __('Data centers', 'vigia-de-seonova'),
            __('Declared bots', 'vigia-de-seonova'),
        ));

        foreach (BCR_Store::daily(BCR_Store::DAILY_KEEP) as $d) {
            $csv .= self::linea(array(
                $d['d'],
                (int) $d['total'],
                (int) $d['humano'],
                (int) $d['bueno'],
                (int) $d['impostor'],
                (int) $d['datacenter'],
                (int) $d['declarado'],
            ));
        }

        return $csv;
    }
}
