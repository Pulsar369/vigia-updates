<?php
/**
 * Enriquecedor rDNS — cron cada 15 min, NUNCA en el camino de la visita.
 *
 * La lista embarcada de centros de datos no puede llevar AWS/Azure/GCP enteros
 * (serían megas de rangos). Pero su DNS inverso los delata:
 * ec2-x-y.compute.amazonaws.com, *.googleusercontent.com, *.cloudapp.azure.com…
 *
 * Cada pasada: coge las IPs "humanas" con más visitas en el búfer que aún no
 * tienen rDNS resuelto (máx 20), resuelve UNA consulta por IP (cacheada en la
 * propia fila), y recoloca al cajón datacenter si el hostname canta. También
 * sirve de red de seguridad: si el rDNS confirma googlebot.com → cajón bueno.
 */

defined('ABSPATH') || exit;

class BCR_Enricher {

    const MAX_PER_RUN = 20;

    /** hostname → proveedor. */
    private static $dc_patterns = array(
        'amazonaws.com'        => 'AWS',
        'googleusercontent.com' => 'Google Cloud',
        'cloudapp.net'         => 'Azure',
        'cloudapp.azure.com'   => 'Azure',
        'azurewebsites.'       => 'Azure',
        'hetzner'              => 'Hetzner',
        'ovh.net'              => 'OVH',
        'ovh.ca'               => 'OVH',
        'digitalocean'         => 'DigitalOcean',
        'linodeusercontent'    => 'Linode/Akamai',
        'vultr'                => 'Vultr',
        'contabo'              => 'Contabo',
        'aliyun'               => 'Alibaba',
        'alibabausercontent'   => 'Alibaba',
        'tencent'              => 'Tencent',
        'huawei'               => 'Huawei Cloud',
        'oraclecloud'          => 'Oracle Cloud',
        'colocrossing'         => 'ColoCrossing',
        'leaseweb'             => 'Leaseweb',
        'scaleway'             => 'Scaleway',
        'your-server.de'       => 'Hetzner',
        'secureserver.net'     => 'GoDaddy (servidor)',
        'hostwindsdns'         => 'Hostwinds',
        'datapacket'           => 'DataPacket',
        'cdn77'                => 'DataCamp/CDN77',
        'm247'                 => 'M247',
    );

    /** hostname → dueño bueno confirmado (red de seguridad). */
    private static $good_patterns = array(
        'googlebot.com'       => 'Google',
        'google.com'          => 'Google',
        'search.msn.com'      => 'Bing',
        'applebot.apple.com'  => 'Apple',
        'crawl.baidu.com'     => 'Baidu',
        'yandex.ru'           => 'Yandex',
        'yandex.net'          => 'Yandex',
    );

    public static function init() {
        add_action('bcr_enrich_event', array(__CLASS__, 'run'));
    }

    public static function run() {
        global $wpdb;
        $v = BCR_Store::visits_table();
        // IPs "humanas" con más presencia en el búfer y sin rDNS resuelto aún.
        $ips = $wpdb->get_col($wpdb->prepare(
            "SELECT ip FROM $v WHERE bucket = 'humano' AND rdns IS NULL
             GROUP BY ip ORDER BY COUNT(*) DESC LIMIT %d",
            self::MAX_PER_RUN
        ));
        // Tope de tiempo: gethostbyaddr sin DNS inverso puede tardar ~5 s por IP
        // en hosting compartido; 20 IPs lentas matarían el cron sin marcar nada.
        // Mejor pocas por pasada pero SIEMPRE guardadas (el cron vuelve en 15 min).
        $deadline = microtime(true) + 10;
        foreach ($ips as $ip) {
            if (microtime(true) > $deadline) {
                break;
            }
            $host = self::rdns($ip);
            $verdict = self::judge($host);
            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM $v WHERE ip = %s AND bucket = 'humano'", $ip
            ));
            foreach ($rows as $id) {
                if ($verdict) {
                    BCR_Store::reclassify((int) $id, $verdict['bucket'], $verdict['who'], $host);
                } else {
                    // Marcar como resuelto (aunque sea sin hostname) para no repetir.
                    BCR_Store::reclassify((int) $id, 'humano', '', $host === '' ? '-' : $host);
                }
            }
        }
    }

    /** DNS inverso con tope de tiempo razonable. */
    public static function rdns($ip) {
        $host = @gethostbyaddr($ip);
        if (!is_string($host) || $host === $ip) {
            return '';
        }
        return strtolower($host);
    }

    /** ¿El hostname delata algo? */
    public static function judge($host) {
        if ($host === '' || $host === '-') {
            return null;
        }
        foreach (self::$good_patterns as $needle => $label) {
            if (substr($host, -strlen($needle)) === $needle) {
                return array('bucket' => 'bueno', 'who' => $label);
            }
        }
        foreach (self::$dc_patterns as $needle => $label) {
            if (strpos($host, $needle) !== false) {
                return array('bucket' => 'datacenter', 'who' => $label);
            }
        }
        return null;
    }
}
