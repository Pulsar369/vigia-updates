<?php
/**
 * Captura de visitas — hook en template_redirect (solo front-end, ya con las
 * condicionales de WP resueltas). En el camino de la visita NO hay ninguna
 * llamada externa: clasificar es comparar contra listas en memoria.
 */

defined('ABSPATH') || exit;

class BCR_Tracker {

    public static function init() {
        add_action('template_redirect', array(__CLASS__, 'track'), 1);
    }

    public static function track() {
        // Ruido que no aporta: usuarios logueados (el dueño mirándose la web),
        // previews, robots.txt y favicon (no son páginas vistas).
        if (is_user_logged_in() || is_preview() || is_robots()
            || (function_exists('is_favicon') && is_favicon())) {
            return;
        }
        if (defined('DOING_CRON') && DOING_CRON) {
            return;
        }

        $ip = self::client_ip();
        if ($ip === '') {
            return;
        }
        $ua   = isset($_SERVER['HTTP_USER_AGENT'])
            ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        $path = isset($_SERVER['REQUEST_URI'])
            ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '/';
        $path = strtok($path, '?'); // sin query string: menos ruido y ningún dato sensible

        // NO contar ficheros estáticos como visita. Una sola página arrastra
        // decenas de fuentes/imágenes; contarlas una a una infla todo y llena el
        // búfer de duplicados (bug visto 2026-08-24: 20 filas de .woff por carga).
        // Además, para el dinero solo cuentan las PÁGINAS: los anuncios salen ahí,
        // no en un .ttf. Algunos temas (Directorist) sirven las fuentes con barra
        // final, así que se admite '/' opcional tras la extensión.
        if (self::is_asset($path)) {
            return;
        }

        // La web visitándose a sí misma NO es una visita. El precargador de
        // WP Rocket y las llamadas internas de WordPress entran por aquí igual
        // que un visitante, y salían contadas como PERSONAS: en craigslist.vegas
        // eran decenas de líneas al día inflando el número de humanos.
        if (self::es_propia($ua)) {
            return;
        }

        $c = BCR_Classifier::classify($ip, $ua);
        BCR_Store::record($ip, $ua, $path, $c['bucket'], $c['who'], isset($c['owner']) ? $c['owner'] : '');
    }

    /** ¿La ruta es un fichero estático (fuente, imagen, css, js…)? */
    public static function is_asset($path) {
        return (bool) preg_match(
            '~\.(?:css|js|mjs|json|xml|map|woff2?|ttf|otf|eot|svg|png|jpe?g|gif|webp|avif|ico|bmp|cur|mp4|webm|ogg|mp3|wav|pdf|zip|gz|txt)/?$~i',
            (string) $path
        );
    }

    /** IP real del visitante: tras Cloudflare llega en CF-Connecting-IP. */
    public static function client_ip() {
        $candidates = array();
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $candidates[] = sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP']));
        }
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            $candidates[] = sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR']));
        }
        foreach ($candidates as $ip) {
            $ip = trim((string) $ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        return '';
    }

    /**
     * ¿La petición la hace la propia web (precarga de caché, cron interno,
     * herramientas del hosting)? Se mira por User-Agent porque la IP de un
     * hosting compartido cambia y no es de fiar.
     */
    public static function es_propia($ua) {
        $ua = strtolower((string) $ua);
        if ($ua === '') {
            return false;
        }
        // Precargadores de caché y llamadas internas.
        $propias = array(
            'wp rocket', 'wp-rocket', 'wordpress/', 'litespeed', 'nitropack',
            'wp fastest cache', 'wp-cli', 'wp_http', 'seonova-check',
        );
        foreach ($propias as $p) {
            if (strpos($ua, $p) !== false) {
                return true;
            }
        }
        // Cualquier UA que lleve el dominio de esta misma web dentro.
        $host = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
        return $host !== '' && strpos($ua, $host) !== false;
    }
}
