<?php
/**
 * Captura de visitas — hook en template_redirect (solo front-end, ya con las
 * condicionales de WP resueltas). En el camino de la visita NO hay ninguna
 * llamada externa: clasificar es comparar contra listas en memoria.
 */

defined('ABSPATH') || exit;

class BCR_Tracker {

    public static function init() {
        add_action('template_redirect', array(__CLASS__, 'track'), 1);
    }

    public static function track() {
        // Ruido que no aporta: usuarios logueados (el dueño mirándose la web),
        // previews, robots.txt y favicon (no son páginas vistas).
        if (is_user_logged_in() || is_preview() || is_robots() || is_favicon()) {
            return;
        }
        if (defined('DOING_CRON') && DOING_CRON) {
            return;
        }

        $ip = self::client_ip();
        if ($ip === '') {
            return;
        }
        $ua   = isset($_SERVER['HTTP_USER_AGENT']) ? wp_unslash($_SERVER['HTTP_USER_AGENT']) : '';
        $path = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $path = strtok($path, '?'); // sin query string: menos ruido y ningún dato sensible

        // NO contar ficheros estáticos como visita. Una sola página arrastra
        // decenas de fuentes/imágenes; contarlas una a una infla todo y llena el
        // búfer de duplicados (bug visto 2026-08-24: 20 filas de .woff por carga).
        // Además, para el dinero solo cuentan las PÁGINAS: los anuncios salen ahí,
        // no en un .ttf. Algunos temas (Directorist) sirven las fuentes con barra
        // final, así que se admite '/' opcional tras la extensión.
        if (self::is_asset($path)) {
            return;
        }

        $c = BCR_Classifier::classify($ip, $ua);
        BCR_Store::record($ip, $ua, $path, $c['bucket'], $c['who']);
    }

    /** ¿La ruta es un fichero estático (fuente, imagen, css, js…)? */
    public static function is_asset($path) {
        return (bool) preg_match(
            '~\.(?:css|js|mjs|json|xml|map|woff2?|ttf|otf|eot|svg|png|jpe?g|gif|webp|avif|ico|bmp|cur|mp4|webm|ogg|mp3|wav|pdf|zip|gz|txt)/?$~i',
            (string) $path
        );
    }

    /** IP real del visitante: tras Cloudflare llega en CF-Connecting-IP. */
    public static function client_ip() {
        $candidates = array();
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $candidates[] = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            $candidates[] = $_SERVER['REMOTE_ADDR'];
        }
        foreach ($candidates as $ip) {
            $ip = trim((string) $ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        return '';
    }
}
