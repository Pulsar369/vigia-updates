<?php
/**
 * ¿Hay caché de página delante de WordPress?
 *
 * POR QUÉ IMPORTA: VigIA cuenta las visitas en 'template_redirect', o sea
 * cuando la petición YA ha llegado a WordPress. Una caché de página (WP Rocket,
 * LiteSpeed, W3 Total Cache…) responde el HTML guardado ANTES de que WordPress
 * arranque del todo, así que esas visitas VigIA no las ve. Lo mismo con
 * Cloudflare si está cacheando el HTML en el borde.
 *
 * Consecuencia práctica, y hay que decirla: los TOTALES que enseña el panel son
 * un mínimo, no la cifra real. Los PORCENTAJES siguen valiendo (la caché no
 * elige a quién guardar por ser bot o persona), y los bots malos casi siempre
 * aparecen igual: van a URLs raras, con parámetros o a sitios que nadie cachea.
 *
 * Callar esto sería peor que no medir: el usuario compararía los números de
 * VigIA con los de Analytics y pensaría que uno de los dos miente.
 */

defined('ABSPATH') || exit;

class BCR_Cache {

    /**
     * Cachés de página detectadas, por su nombre de cara al usuario.
     * Se mira por constantes y por ficheros: son las señales que dejan al
     * activarse, no hace falta preguntar a nadie.
     *
     * @return string[]
     */
    public static function detectadas() {
        $out = array();

        if (defined('WP_ROCKET_VERSION')) {
            $out[] = 'WP Rocket';
        }
        if (defined('LSCWP_V') || defined('LSCACHE_ADV_CACHE')) {
            $out[] = 'LiteSpeed Cache';
        }
        if (defined('W3TC') || defined('W3TC_DIR')) {
            $out[] = 'W3 Total Cache';
        }
        if (defined('WPCACHEHOME')) {
            $out[] = 'WP Super Cache';
        }
        if (defined('WPFC_MAIN_PATH') || defined('WPFC_WP_CONTENT_BASENAME')) {
            $out[] = 'WP Fastest Cache';
        }
        if (defined('CE_FILE') || defined('CACHE_ENABLER_VERSION')) {
            $out[] = 'Cache Enabler';
        }
        if (defined('WPHB_VERSION') && defined('WPHB_ADVANCED_CACHE')) {
            $out[] = 'Hummingbird';
        }
        if (defined('SiteGround_Optimizer\VERSION') || defined('SITEGROUND_OPTIMIZER_VERSION')) {
            $out[] = 'SiteGround Optimizer';
        }
        if (defined('BREEZE_VERSION')) {
            $out[] = 'Breeze';
        }
        if (defined('SWCFPC_PLUGIN_PATH')) {
            $out[] = 'Super Page Cache';
        }

        // Cualquier otra: si WP_CACHE está encendido y hay un advanced-cache.php,
        // hay una caché de página aunque no sepamos cuál.
        if (!$out && defined('WP_CACHE') && WP_CACHE && file_exists(WP_CONTENT_DIR . '/advanced-cache.php')) {
            $out[] = __('a page cache', 'vigia-de-seonova');
        }

        return $out;
    }

    /** ¿Hay algo delante? */
    public static function hay() {
        return (bool) self::detectadas();
    }

    /**
     * El aviso, en una línea, para poner debajo de los números grandes.
     * Devuelve '' si no hay caché: sin caché no hay nada que explicar.
     */
    public static function aviso() {
        $nombres = self::detectadas();
        if (!$nombres) {
            return '';
        }
        return sprintf(
            /* translators: %s: name(s) of the page cache plugin(s) found, e.g. "WP Rocket". */
            __('Your site has a page cache (%s). VigIA counts what reaches WordPress, so visits served straight from the cache are not counted: these totals are a floor, not the full number. The percentages still hold, and bad bots show up anyway because they go for URLs nobody caches.', 'vigia-de-seonova'),
            implode(' + ', $nombres)
        );
    }
}
