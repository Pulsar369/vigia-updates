<?php
/**
 * Informe semanal por email — lunes por la mañana, wp_mail HTML.
 *
 * QUÉ LLEVA Y POR QUÉ (acordado 26-ago-2026):
 *
 *   1. Resumen de la semana Y comparación con la anterior. Un número suelto
 *      no dice nada: "421 bots malos" no significa nada hasta que lo pones al
 *      lado de "+18% que la semana pasada". La comparación va hasta en el
 *      asunto, porque un asunto con número Y dirección se abre.
 *   2. Coste de la semana + acumulado desde que se instaló. La cifra semanal
 *      es pequeña y se ignora; la acumulada es la que mueve.
 *   3. El veredicto SOLO cuando es nuevo o cuando cambia de nivel. Repetir
 *      "nivel 2" todos los lunes durante ocho meses es enseñarle al lector a
 *      ignorar el correo.
 *   4. Los peores de la semana y los bots NUEVOS. Lo único que nadie más le
 *      puede contar de su web.
 *   5. Un gancho sacado de SUS datos + una ventaja de WPO Toolkit que rota
 *      cada semana.
 *   6. Semana tranquila = correo de tres líneas. Mandar el informe completo
 *      cuando no ha pasado nada es lo que quema la confianza.
 *
 * Strings en inglés (base); el español vive en /languages.
 */

defined('ABSPATH') || exit;

class BCR_Report {

    /** Días de rodaje antes de fiarse del bloque "nuevos esta semana". */
    const NUEVOS_DESDE_DIAS = 14;

    public static function init() {
        // El acumulado se suma SIEMPRE, aunque el correo esté apagado: si no,
        // apagar el informe borraría el histórico de dinero sin avisar.
        add_action('bcr_weekly_event', array(__CLASS__, 'acumular'), 5);
        add_action('bcr_weekly_event', array(__CLASS__, 'send'), 10);
        add_action('bcr_weekly_event', array(__CLASS__, 'send_telemetry'), 20);
    }

    /** Suma los bots malos de la semana al contador que no se poda. */
    public static function acumular() {
        $t = BCR_Store::totals(7);
        BCR_Store::acumular($t['impostor'] + $t['datacenter'] + $t['declarado']);
    }

    /**
     * Todo lo que necesita el correo, en un array. Separado del HTML a
     * propósito: así las pruebas comprueban las DECISIONES (¿hay que cantar el
     * veredicto?, ¿la semana fue tranquila?) sin mirar etiquetas.
     */
    public static function datos() {
        $t  = BCR_Store::totals(7);
        $tp = BCR_Store::totals(7, 7);

        $bad  = $t['impostor'] + $t['datacenter'] + $t['declarado'];
        $badp = $tp['impostor'] + $tp['datacenter'] + $tp['declarado'];
        $pct  = $t['total'] > 0 ? (int) round($bad / $t['total'] * 100) : 0;

        // Sin semana anterior con la que comparar NO hay delta. Devolver 0 o
        // +100% sería inventarse una tendencia el primer lunes.
        $delta = ($tp['total'] > 0 && $badp > 0)
            ? (int) round(($bad - $badp) / $badp * 100)
            : null;

        $v      = BCR_Store::verdict();
        $previo = (int) get_option('bcr_report_nivel', 0);
        $cantar = ($v['state'] !== 'gathering') && ((int) $v['level'] !== $previo);

        // "Nuevos" solo tiene sentido cuando ya hay con qué comparar: recién
        // instalado, TODO es nuevo y la lista no informa de nada.
        $instalado = (int) get_option('bcr_installed_at', 0);
        $rodado    = $instalado > 0
            && (current_time('timestamp') - $instalado) > self::NUEVOS_DESDE_DIAS * DAY_IN_SECONDS;
        $nuevos = $rodado ? BCR_Store::nuevos(7) : array();

        $tranquila = ((int) $v['level'] === 1)
            && $pct < 10
            && !$cantar
            && !$nuevos
            && ($delta === null || abs($delta) < 25);

        return array(
            'total'     => $t['total'],
            'bad'       => $bad,
            'pct'       => $pct,
            'delta'     => $delta,
            'coste'     => BCR_Store::coste_de($bad),
            'acumulado' => (int) get_option('bcr_malos_total', 0),
            'nivel'     => (int) $v['level'],
            'estado'    => $v['state'],
            'cantar'    => $cantar,
            'sube'      => $cantar && (int) $v['level'] > $previo,
            'nuevos'    => $nuevos,
            'tranquila' => $tranquila,
        );
    }

    /**
     * Ventajas de WPO Toolkit, una por semana. Rotan solas con el número de
     * semana del año: sin guardar nada y sin repetir dos lunes seguidos.
     * Todas salen de lo que promete la página del producto — aquí no se
     * inventa nada que el toolkit no haga.
     */
    public static function ventajas() {
        return array(
            array(
                't' => __('Your site loads twice as fast', 'vigia-de-seonova'),
                'b' => __('A real page went from taking 8 seconds to opening in under 2. That is the difference between a visitor who leaves and one who stays.', 'vigia-de-seonova'),
            ),
            array(
                't' => __('Served from 200+ countries at once', 'vigia-de-seonova'),
                'b' => __('It puts your site on the worldwide Cloudflare network: someone in Argentina opens it as fast as someone in Madrid, and your server stops suffering.', 'vigia-de-seonova'),
            ),
            array(
                't' => __('It replaces 5 to 10 slow plugins', 'vigia-de-seonova'),
                'b' => __('Login hiding, ad insertion, image optimisation, Core Web Vitals, anti-spam: all in one tool. Fewer plugins means less weight and fewer things that break.', 'vigia-de-seonova'),
            ),
            array(
                't' => __('It keeps an eye on your ad income', 'vigia-de-seonova'),
                'b' => __('It tells you how many people block your ads and follows your RPM hour by hour, so you hear about a drop before the Google panel shows it.', 'vigia-de-seonova'),
            ),
            array(
                't' => __('Cloudflare in layers, not one wall', 'vigia-de-seonova'),
                'b' => __('It blocks AI bots, slows attacks down with rate limits, hides your login from the public and filters the countries most threats come from.', 'vigia-de-seonova'),
            ),
            array(
                't' => __('A doorman at the door', 'vigia-de-seonova'),
                'b' => __('Our own plugin looks at every visit one by one: person or bot, real reader or scraper copying your content, someone inflating your ad stats. Only the good ones get in.', 'vigia-de-seonova'),
            ),
        );
    }

    /** La ventaja que toca esta semana. */
    public static function ventaja($semana = null) {
        $v = self::ventajas();
        $semana = ($semana === null) ? (int) gmdate('W') : (int) $semana;
        return $v[abs($semana) % count($v)];
    }

    /** Textos cortos del veredicto — la versión larga vive en el panel. */
    public static function niveles() {
        return array(
            1 => array(
                // Mismos msgid que el panel: una sola traducción para los dos.
                't' => __('WPO Toolkit alone is enough', 'vigia-de-seonova'),
                'b' => __('Bot pressure is low. Blocking them from inside your own WordPress is plenty; you do not need to pay for anything extra.', 'vigia-de-seonova'),
            ),
            2 => array(
                't' => __('WPO Toolkit + free Cloudflare', 'vigia-de-seonova'),
                'b' => __('One in five visits is already a bad bot. At this point it pays to stop them BEFORE they reach your hosting, and that is what the free Cloudflare shield is for.', 'vigia-de-seonova'),
            ),
            3 => array(
                't' => __('WPO Toolkit + Cloudflare Pro', 'vigia-de-seonova'),
                'b' => __('This is swarm level. The free shield falls short here: you need the paid tier to hold big waves.', 'vigia-de-seonova'),
            ),
        );
    }

    public static function send() {
        if (get_option('bcr_report_enabled', '1') !== '1') {
            return;
        }
        $to = sanitize_email(get_option('bcr_report_email', get_option('admin_email')));
        if (!$to) {
            return;
        }
        $d = self::datos();
        if ($d['total'] < 1) {
            return; // sin datos aún: no mandar un email vacío
        }

        $site   = wp_parse_url(home_url(), PHP_URL_HOST);
        $lang   = strpos(get_locale(), 'es_') === 0 ? 'es' : 'en';
        $flecha = self::flecha($d['delta']);

        // ---------------------------------------------------------- asunto
        if ($d['tranquila']) {
            $subject = sprintf(__('A quiet week on %s', 'vigia-de-seonova'), $site);
        } elseif ($d['coste'] !== null) {
            $subject = sprintf(
                /* translators: 1: money amount, 2: change vs last week like " (+18%)", 3: site host. */
                __('Bots cost you ~$%1$s this week%2$s · %3$s', 'vigia-de-seonova'),
                number_format_i18n($d['coste'], 2), $flecha, $site
            );
        } else {
            $subject = sprintf(
                /* translators: 1: percentage, 2: change vs last week like " (+18%)", 3: site host. */
                __('%1$d%% of your visits this week were bots%2$s (%3$s)', 'vigia-de-seonova'),
                $d['pct'], $flecha, $site
            );
        }

        // ----------------------------------------------------------- cuerpo
        $b = '<div style="font-family:sans-serif;max-width:560px;color:#1d2327">'
            . '<h2 style="margin:0 0 12px">' . esc_html__('Bot radar — weekly summary', 'vigia-de-seonova') . '</h2>';

        if ($d['tranquila']) {
            $b .= '<p>' . sprintf(
                /* translators: 1: site host, 2: number of visits, 3: percentage of bots. */
                esc_html__('Quiet week on %1$s: %2$s visits and only %3$d%% bots. Nothing to do.', 'vigia-de-seonova'),
                esc_html($site), '<strong>' . number_format_i18n($d['total']) . '</strong>', $d['pct']
            ) . '</p>';
        } else {
            $b .= '<p>' . sprintf(
                esc_html__('%1$s visits this week on %2$s. %3$s%% were bots (%4$s bad ones: impostors, data centers and scrapers).', 'vigia-de-seonova'),
                '<strong>' . number_format_i18n($d['total']) . '</strong>', esc_html($site),
                '<strong>' . $d['pct'] . '</strong>', '<strong>' . number_format_i18n($d['bad']) . '</strong>'
            ) . '</p>'
            . self::linea_delta($d['delta'])
            . self::linea_coste($d)
            . self::linea_veredicto($d)
            . self::tabla_peores()
            . self::linea_nuevos($d['nuevos'])
            . self::gancho($d);
        }

        // Ventaja de la semana: va SIEMPRE, tranquila o no.
        $vent = self::ventaja();
        $b .= '<div style="margin:22px 0;padding:14px 16px;background:#f6f7f7;border-radius:6px">'
            . '<p style="margin:0 0 4px"><strong>' . esc_html($vent['t']) . '</strong></p>'
            . '<p style="margin:0;color:#50575e">' . esc_html($vent['b']) . '</p></div>';

        $b .= '<p style="margin:20px 0"><a href="' . esc_url(bcr_cta_url($lang)) . '" style="background:#d63638;color:#fff;padding:10px 18px;text-decoration:none;border-radius:4px;font-weight:bold">'
            . esc_html__('Stop them with WPO Toolkit →', 'vigia-de-seonova') . '</a></p>'
            . '<p style="color:#777;font-size:12px">' . esc_html__('You can turn this report off in the VigIA settings.', 'vigia-de-seonova') . '</p>'
            . '</div>';

        wp_mail($to, $subject, $b, array('Content-Type: text/html; charset=UTF-8'));

        // El nivel se guarda DESPUÉS de mandarlo: si el correo falla, el
        // próximo lunes se vuelve a intentar en vez de perderse el aviso.
        if ($d['cantar']) {
            update_option('bcr_report_nivel', $d['nivel'], false);
        }
    }

    /** " (+18%)" para el asunto. Cadena vacía si no hay con qué comparar. */
    public static function flecha($delta) {
        if ($delta === null || $delta === 0) {
            return '';
        }
        return sprintf(' (%s%d%%)', $delta > 0 ? '+' : '', $delta);
    }

    private static function linea_delta($delta) {
        if ($delta === null) {
            return '';
        }
        if ($delta === 0) {
            return '<p style="margin:2px 0 0;color:#50575e">' . esc_html__('The same as last week.', 'vigia-de-seonova') . '</p>';
        }
        $color = $delta > 0 ? '#d63638' : '#00844a';
        $txt = $delta > 0
            /* translators: %d: percentage increase. */
            ? sprintf(__('%d%% more bad bots than last week.', 'vigia-de-seonova'), $delta)
            /* translators: %d: percentage decrease. */
            : sprintf(__('%d%% fewer bad bots than last week.', 'vigia-de-seonova'), abs($delta));
        return '<p style="margin:2px 0 0;color:' . $color . '"><strong>' . esc_html($txt) . '</strong></p>';
    }

    private static function linea_coste($d) {
        if ($d['coste'] === null) {
            return '<p>' . esc_html__('Set your RPM in the radar settings to see how much money bots cost you.', 'vigia-de-seonova') . '</p>';
        }
        $out = '<p style="font-size:18px;margin:14px 0 0"><strong>'
            . sprintf(esc_html__('Bots cost you ~$%s this week', 'vigia-de-seonova'), number_format_i18n($d['coste'], 2))
            . '</strong></p>';
        $acum = BCR_Store::coste_de($d['acumulado']);
        if ($acum !== null && $d['acumulado'] > $d['bad']) {
            $out .= '<p style="margin:2px 0 0;color:#50575e">' . sprintf(
                /* translators: 1: money amount, 2: number of bad bots. */
                esc_html__('~$%1$s since you installed VigIA (%2$s bad bots in total).', 'vigia-de-seonova'),
                number_format_i18n($acum, 2), number_format_i18n($d['acumulado'])
            ) . '</p>';
        }
        return $out;
    }

    private static function linea_veredicto($d) {
        if (!$d['cantar']) {
            return '';
        }
        $n = self::niveles();
        $lvl = isset($n[$d['nivel']]) ? $n[$d['nivel']] : $n[1];
        $cab = $d['sube']
            /* translators: %d: verdict level, 1 to 3. */
            ? sprintf(__('You have moved up to level %d', 'vigia-de-seonova'), $d['nivel'])
            /* translators: %d: verdict level, 1 to 3. */
            : sprintf(__('You have dropped back to level %d', 'vigia-de-seonova'), $d['nivel']);
        $color = $d['nivel'] === 3 ? '#d63638' : ($d['nivel'] === 2 ? '#dba617' : '#00844a');
        $extra = $d['estado'] === 'provisional'
            ? '<p style="margin:6px 0 0;font-size:12px;color:#777">' . esc_html__('Preliminary: still few visits, it may move.', 'vigia-de-seonova') . '</p>'
            : '';
        return '<div style="margin:18px 0;padding:12px 14px;border-left:4px solid ' . $color . ';background:#fbfbfb">'
            . '<p style="margin:0"><strong>' . esc_html($cab) . ' — ' . esc_html($lvl['t']) . '</strong></p>'
            . '<p style="margin:4px 0 0">' . esc_html($lvl['b']) . '</p>' . $extra . '</div>';
    }

    private static function tabla_peores() {
        $peores = BCR_Store::top_offenders(7, 3);
        if (!$peores) {
            return '';
        }
        $rows = '';
        foreach ($peores as $o) {
            $rows .= '<tr><td style="padding:4px 12px 4px 0">' . esc_html($o->who) . '</td>'
                . '<td style="padding:4px 12px 4px 0">' . esc_html(self::bucket_label($o->bucket)) . '</td>'
                . '<td style="padding:4px 0"><strong>' . (int) $o->c . '</strong> ' . esc_html__('visits', 'vigia-de-seonova') . '</td></tr>';
        }
        // Los peores salen del búfer de últimas visitas, no de la semana
        // entera: en una web movida ese búfer son dos días. Decirlo, en vez de
        // dar por semanal un número que no lo es.
        $titulo = self::buffer_corto()
            ? sprintf(
                /* translators: %s: number of visits kept in the buffer. */
                __('Top offenders (of the last %s visits recorded)', 'vigia-de-seonova'),
                number_format_i18n(BCR_Store::MAX_VISITS)
            )
            : __('Top offenders this week', 'vigia-de-seonova');
        return '<h3 style="margin:18px 0 6px">' . esc_html($titulo) . '</h3>'
            . '<table style="border-collapse:collapse">' . $rows . '</table>';
    }

    /** ¿El búfer de visitas cubre menos de una semana? */
    public static function buffer_corto() {
        $desde = BCR_Store::buffer_desde();
        if (!$desde) {
            return false;
        }
        return strtotime($desde) > (current_time('timestamp') - 7 * DAY_IN_SECONDS);
    }

    private static function linea_nuevos($nuevos) {
        if (!$nuevos) {
            return '';
        }
        return '<p style="margin:14px 0 0">' . sprintf(
            /* translators: %s: comma-separated list of bot names. */
            esc_html__('New this week: %s', 'vigia-de-seonova'),
            '<strong>' . esc_html(implode(', ', array_slice($nuevos, 0, 6))) . '</strong>'
        ) . '</p>';
    }

    /**
     * El gancho sale de SUS números, no de una lista. Cambia solo cada semana
     * porque cambian los bots, así que nunca huele a anuncio repetido.
     */
    private static function gancho($d) {
        $peores = BCR_Store::top_offenders(7, 1);
        $escudo = (string) get_option('bcr_escudo', '');
        $txt = '';
        if ($peores) {
            $o = $peores[0];
            $txt = sprintf(
                /* translators: 1: bot name, 2: number of pages. */
                __('%1$s took %2$s pages this week and left you nothing. WPO Toolkit stops it with one rule.', 'vigia-de-seonova'),
                $o->who, number_format_i18n((int) $o->c)
            );
        } elseif ($escudo !== '' && $d['bad'] > 0) {
            $txt = sprintf(
                /* translators: %s: name of the CDN or firewall in front, e.g. "Cloudflare". */
                __('You already have %s in front and these still got through. What blocks them is the rules, not the shield.', 'vigia-de-seonova'),
                $escudo
            );
        }
        return $txt ? '<p style="margin:16px 0 0">' . esc_html($txt) . '</p>' : '';
    }

    /**
     * Telemetría anónima semanal — SOLO si el usuario la activó (opt-in).
     * Manda agregados (nivel, %, conteos); jamás dominio, IPs ni visitantes.
     */
    public static function send_telemetry() {
        if (get_option('bcr_telemetry', '') !== '1') {
            return;
        }
        if (!class_exists('BCR_Admin')) {
            require_once BCR_DIR . 'includes/class-bcr-admin.php';
        }
        wp_remote_post(BCR_API_URL, array(
            'timeout' => 8,
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode(array(
                'type' => 'telemetry',
                // id estable pero anónimo (no reversible al dominio)
                'diag' => 'site_id=' . substr(md5(home_url() . wp_salt('nonce')), 0, 12) . "\n" . BCR_Admin::diag_summary(),
                'lang' => strpos(get_locale(), 'es_') === 0 ? 'es' : 'en',
            )),
        ));
    }

    public static function bucket_label($bucket) {
        $labels = array(
            'humano'     => __('human', 'vigia-de-seonova'),
            'bueno'      => __('verified good bot', 'vigia-de-seonova'),
            'impostor'   => __('IMPOSTOR', 'vigia-de-seonova'),
            'datacenter' => __('data center', 'vigia-de-seonova'),
            'declarado'  => __('declared bot', 'vigia-de-seonova'),
        );
        return isset($labels[$bucket]) ? $labels[$bucket] : $bucket;
    }
}
