<?php
/**
 * Informe semanal por email — lunes por la mañana, wp_mail HTML.
 * "Esta semana los bots te costaron ~$X · top redes · [Páralos]".
 * Strings en inglés (base); el español vive en /languages.
 */

defined('ABSPATH') || exit;

class BCR_Report {

    public static function init() {
        add_action('bcr_weekly_event', array(__CLASS__, 'send'));
        add_action('bcr_weekly_event', array(__CLASS__, 'send_telemetry'));
    }

    public static function send() {
        if (get_option('bcr_report_enabled', '1') !== '1') {
            return;
        }
        $to = sanitize_email(get_option('bcr_report_email', get_option('admin_email')));
        if (!$to) {
            return;
        }
        $t = BCR_Store::totals(7);
        if ($t['total'] < 1) {
            return; // sin datos aún: no mandar un email vacío
        }
        $bad = $t['impostor'] + $t['datacenter'] + $t['declarado'];
        $pct = $t['total'] > 0 ? round($bad / $t['total'] * 100) : 0;
        $rpm = (float) get_option('bcr_rpm', 0);
        $cost_week = $rpm > 0 ? round($bad / 1000 * $rpm, 2) : null;

        $site = wp_parse_url(home_url(), PHP_URL_HOST);
        $subject = $cost_week !== null
            ? sprintf(__('Bots cost you ~$%1$s this week on %2$s', 'vigia-de-seonova'), number_format_i18n($cost_week, 2), $site)
            : sprintf(__('%1$d%% of your visits this week were bots (%2$s)', 'vigia-de-seonova'), $pct, $site);

        $rows = '';
        foreach (BCR_Store::top_offenders(7, 3) as $o) {
            $rows .= '<tr><td style="padding:4px 12px 4px 0">' . esc_html($o->who) . '</td>'
                . '<td style="padding:4px 12px 4px 0">' . esc_html(self::bucket_label($o->bucket)) . '</td>'
                . '<td style="padding:4px 0"><strong>' . (int) $o->c . '</strong> ' . esc_html__('visits', 'vigia-de-seonova') . '</td></tr>';
        }

        $cost_line = $cost_week !== null
            ? '<p style="font-size:18px"><strong>' . sprintf(esc_html__('Bots cost you ~$%s this week', 'vigia-de-seonova'), number_format_i18n($cost_week, 2)) . '</strong> '
              . esc_html__('(estimate based on your configured RPM)', 'vigia-de-seonova') . '</p>'
            : '<p>' . esc_html__('Set your RPM in the radar settings to see how much money bots cost you.', 'vigia-de-seonova') . '</p>';

        $body = '<div style="font-family:sans-serif;max-width:560px">'
            . '<h2 style="margin:0 0 12px">' . esc_html__('Bot radar — weekly summary', 'vigia-de-seonova') . '</h2>'
            . '<p>' . sprintf(
                esc_html__('%1$s visits this week on %2$s. %3$s%% were bots (%4$s bad ones: impostors, data centers and scrapers).', 'vigia-de-seonova'),
                '<strong>' . number_format_i18n($t['total']) . '</strong>', esc_html($site),
                '<strong>' . $pct . '</strong>', '<strong>' . number_format_i18n($bad) . '</strong>'
            ) . '</p>'
            . $cost_line
            . ($rows ? '<h3 style="margin:16px 0 6px">' . esc_html__('Top offenders', 'vigia-de-seonova') . '</h3><table style="border-collapse:collapse">' . $rows . '</table>' : '')
            . '<p style="margin:20px 0"><a href="' . esc_url(bcr_cta_url(strpos(get_locale(), 'es_') === 0 ? 'es' : 'en')) . '" style="background:#d63638;color:#fff;padding:10px 18px;text-decoration:none;border-radius:4px;font-weight:bold">'
            . esc_html__('Stop them with WPO Toolkit →', 'vigia-de-seonova') . '</a></p>'
            . '<p style="color:#777;font-size:12px">' . esc_html__('You can turn this report off in the VigIA settings.', 'vigia-de-seonova') . '</p>'
            . '</div>';

        wp_mail($to, $subject, $body, array('Content-Type: text/html; charset=UTF-8'));
    }

    /**
     * Telemetría anónima semanal — SOLO si el usuario la activó (opt-in).
     * Manda agregados (nivel, %, conteos); jamás dominio, IPs ni visitantes.
     */
    public static function send_telemetry() {
        if (get_option('bcr_telemetry', '') !== '1') {
            return;
        }
        if (!class_exists('BCR_Admin')) {
            require_once BCR_DIR . 'includes/class-bcr-admin.php';
        }
        wp_remote_post(BCR_API_URL, array(
            'timeout' => 8,
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode(array(
                'type' => 'telemetry',
                // id estable pero anónimo (no reversible al dominio)
                'diag' => 'site_id=' . substr(md5(home_url() . wp_salt('nonce')), 0, 12) . "\n" . BCR_Admin::diag_summary(),
                'lang' => strpos(get_locale(), 'es_') === 0 ? 'es' : 'en',
            )),
        ));
    }

    public static function bucket_label($bucket) {
        $labels = array(
            'humano'     => __('human', 'vigia-de-seonova'),
            'bueno'      => __('verified good bot', 'vigia-de-seonova'),
            'impostor'   => __('IMPOSTOR', 'vigia-de-seonova'),
            'datacenter' => __('data center', 'vigia-de-seonova'),
            'declarado'  => __('declared bot', 'vigia-de-seonova'),
        );
        return isset($labels[$bucket]) ? $labels[$bucket] : $bucket;
    }
}
