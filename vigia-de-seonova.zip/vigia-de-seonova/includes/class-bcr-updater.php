<?php
/**
 * Auto-actualización desde un canal PÚBLICO en GitHub — para no tener que
 * subir el ZIP a mano en cada cambio (mientras el plugin no esté en
 * wordpress.org, que trae su propio auto-update).
 *
 * Cómo funciona: un repo público (BCR_UPDATE_MANIFEST) sirve un manifest.json
 * pequeño con la última versión y la URL del ZIP. WordPress pregunta por
 * actualizaciones dos veces al día; enganchamos ahí, comparamos versiones y,
 * si hay una más nueva, le decimos a WP de dónde bajarla. WP la instala como
 * cualquier update del repositorio oficial.
 *
 * Sin secretos: Vigía es GPL y el canal es público (raw.githubusercontent.com,
 * servido por CDN, sin límite de peticiones que nos afecte). La respuesta se
 * cachea 6 h para no preguntar en cada carga del admin.
 */

defined('ABSPATH') || exit;

class BCR_Updater {

    const CACHE_KEY = 'bcr_update_manifest';
    const CACHE_TTL = 6 * HOUR_IN_SECONDS;
    /** Marca de "ya encendí las automáticas una vez": no se vuelve a tocar. */
    const OPT_AUTO_DEFECTO = 'bcr_autoupdate_default';

    public static function init() {
        if (!defined('BCR_UPDATE_MANIFEST') || !BCR_UPDATE_MANIFEST) {
            return; // canal no configurado: nos comportamos como un plugin normal
        }
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'inject'));
        add_filter('plugins_api', array(__CLASS__, 'details'), 20, 3);
        // Tras instalar el update, olvidar la caché para que no reofrezca la vieja.
        add_action('upgrader_process_complete', array(__CLASS__, 'tras_actualizar'), 10, 2);
        // Enlace "Buscar actualizaciones" en la fila de META (lado de la
        // descripción: Versión | Por … | Visitar sitio), no en la columna de
        // acciones (Desactivar). Ahí lo quiere el usuario y ahí se ve mejor.
        add_filter('plugin_row_meta', array(__CLASS__, 'row_meta_link'), 10, 2);
        add_action('admin_init', array(__CLASS__, 'handle_manual_check'));
        add_action('admin_init', array(__CLASS__, 'auto_update_por_defecto'));
        add_action('admin_init', array(__CLASS__, 'limpiar_aviso_viejo'));
        add_action('admin_notices', array(__CLASS__, 'manual_check_notice'));
    }

    /**
     * Añade "Buscar actualizaciones" a la fila de META del plugin (lado de la
     * descripción: Versión | Por … | Visitar sitio), NO a la columna de acciones.
     * $file llega para CADA plugin de la lista → sólo tocamos el nuestro.
     */
    public static function row_meta_link($meta, $file) {
        if ($file === plugin_basename(BCR_FILE) && current_user_can('update_plugins')) {
            $url = wp_nonce_url(add_query_arg('bcr_check', '1', admin_url('plugins.php')), 'bcr_check');
            $meta[] = '<a href="' . esc_url($url) . '">' . esc_html__('Check for updates', 'vigia-de-seonova') . '</a>';
        }
        return $meta;
    }

    /** Fuerza la comprobación ya: limpia caché nuestra + la de WP y re-pregunta. */
    public static function handle_manual_check() {
        if (empty($_GET['bcr_check']) || !current_user_can('update_plugins')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_check')) {
            return;
        }
        self::flush_cache();
        delete_site_transient('update_plugins');   // obliga a WP a re-evaluar
        $manifest = self::fetch_manifest(true);     // salta la caché de 6 h
        wp_update_plugins();                        // dispara nuestro inject() con datos frescos
        $hay = $manifest && empty($manifest['_error']) && version_compare($manifest['version'], self::version_instalada(), '>');
        wp_safe_redirect(add_query_arg('bcr_checked', $hay ? '1' : '0', admin_url('plugins.php')));
        exit;
    }

    /** Aviso tras la comprobación manual. */
    public static function manual_check_notice() {
        if (!isset($_GET['bcr_checked'])) {
            return;
        }
        if ($_GET['bcr_checked'] === '1') {
            echo '<div class="notice notice-warning is-dismissible"><p>'
                . esc_html__('VigIA de SeoNova: a new version is available — see the update notice on its row below.', 'vigia-de-seonova')
                . '</p></div>';
        } else {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html__('VigIA de SeoNova: you are already on the latest version.', 'vigia-de-seonova')
                . '</p></div>';
        }
    }

    /** Baja el manifest (cacheado). Devuelve array u null si no se pudo. */
    public static function fetch_manifest($force = false) {
        if (!$force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) {
                return $cached;
            }
        }
        $resp = wp_remote_get(BCR_UPDATE_MANIFEST, array(
            'timeout' => 8,
            'headers' => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) {
            // Cachear el fallo poco rato: no martillear si el canal está caído.
            set_site_transient(self::CACHE_KEY, array('_error' => true), 30 * MINUTE_IN_SECONDS);
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($data) || empty($data['version']) || empty($data['download_url'])) {
            set_site_transient(self::CACHE_KEY, array('_error' => true), 30 * MINUTE_IN_SECONDS);
            return null;
        }
        set_site_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    /**
     * Le cuenta a WordPress en qué versión vamos.
     *
     * Dos casos, y los DOS importan:
     *  - Hay versión nueva -> entra en $transient->response  (WordPress ofrece actualizar).
     *  - Estamos al día    -> entra en $transient->no_update (WordPress sabe que este
     *    plugin TIENE quien lo actualice).
     *
     * Lo segundo no es un detalle: la lista de plugins marca "update-supported"
     * mirando si el plugin sale en response o en no_update
     * (class-wp-plugins-list-table.php). Si no sale en ninguno, WordPress ESCONDE
     * el interruptor de "Activar actualizaciones automáticas" y el actualizador
     * automático ni se plantea tocarlo. Por eso nos anunciamos siempre.
     */
    public static function inject($transient) {
        if (!is_object($transient)) {
            return $transient;
        }
        $basename = plugin_basename(BCR_FILE);
        $m = self::fetch_manifest();
        $m = (is_array($m) && empty($m['_error'])) ? $m : null;
        $puesta = self::version_instalada();
        $hay = $m && version_compare($m['version'], $puesta, '>');

        $obj = array(
            'id'           => $basename,
            'slug'         => dirname($basename),
            'plugin'       => $basename,
            'new_version'  => $hay ? $m['version'] : $puesta,
            'package'      => $hay ? $m['download_url'] : '',
            'url'          => ($m && isset($m['homepage'])) ? $m['homepage'] : '',
            'tested'       => ($m && isset($m['tested'])) ? $m['tested'] : '',
            'requires'     => ($m && isset($m['requires'])) ? $m['requires'] : '',
            'requires_php' => ($m && isset($m['requires_php'])) ? $m['requires_php'] : '',
            'icons'        => array(),
            'banners'      => array(),
            'banners_rtl'  => array(),
        );

        if (!isset($transient->response) || !is_array($transient->response)) {
            $transient->response = array();
        }
        if (!isset($transient->no_update) || !is_array($transient->no_update)) {
            $transient->no_update = array();
        }

        if ($hay) {
            unset($transient->no_update[$basename]);
            $transient->response[$basename] = (object) $obj;
        } else {
            unset($transient->response[$basename]);
            $transient->no_update[$basename] = (object) $obj;
        }
        return $transient;
    }

    /** Popup "Ver detalles" del plugin. */
    public static function details($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== dirname(plugin_basename(BCR_FILE))) {
            return $result;
        }
        $m = self::fetch_manifest();
        if (!$m || !empty($m['_error'])) {
            return $result;
        }
        return (object) array(
            'name'          => isset($m['name']) ? $m['name'] : 'VigIA de SeoNova',
            'slug'          => dirname(plugin_basename(BCR_FILE)),
            'version'       => $m['version'],
            'author'        => '<a href="https://seonova.pro">SeoNova</a>',
            'homepage'      => isset($m['homepage']) ? $m['homepage'] : '',
            'download_link' => $m['download_url'],
            'requires'      => isset($m['requires']) ? $m['requires'] : '',
            'requires_php'  => isset($m['requires_php']) ? $m['requires_php'] : '',
            'tested'        => isset($m['tested']) ? $m['tested'] : '',
            'sections'      => array(
                'changelog' => isset($m['changelog']) ? wp_kses_post($m['changelog']) : '',
            ),
        );
    }

    /**
     * Actualizaciones automáticas ENCENDIDAS de fábrica, una sola vez.
     *
     * Un plugin de seguridad que se queda viejo es peor que no tenerlo: las
     * listas de bots buenos y de centros de datos cambian cada semana. Así que
     * al instalar se apunta solo a la lista de WordPress (opción de red
     * auto_update_plugins), la misma que mueve el enlace "Activar
     * actualizaciones automáticas" de la pantalla de plugins.
     *
     * Se hace UNA vez y se deja marcado. Si el usuario lo apaga, se queda
     * apagado: el interruptor es suyo, no nuestro.
     */
    public static function auto_update_por_defecto() {
        if (get_option(self::OPT_AUTO_DEFECTO)) {
            return;
        }
        update_option(self::OPT_AUTO_DEFECTO, 1, false);
        $basename = plugin_basename(BCR_FILE);
        $lista = (array) get_site_option('auto_update_plugins', array());
        if (!in_array($basename, $lista, true)) {
            $lista[] = $basename;
            update_site_option('auto_update_plugins', $lista);
        }
    }

    /**
     * La versión que hay AHORA MISMO en el disco.
     *
     * No vale la constante BCR_VERSION. Justo después de una actualización, el
     * PHP que atiende esa petición sigue teniendo en memoria el código VIEJO:
     * la constante miente durante ese rato. Si nos fiamos de ella dejamos
     * escrito en el transitorio "hay una versión nueva" cuando ya está
     * instalada, y el aviso amarillo de "actualiza" se queda pegado en la lista
     * de plugins hasta 12 h. Pasó de verdad al salir la 0.6.1 (26-ago-2026).
     * Leer la cabecera del fichero cuesta un fopen y siempre dice la verdad.
     */
    public static function version_instalada() {
        $datos = get_file_data(BCR_FILE, array('Version' => 'Version'), 'plugin');
        return empty($datos['Version']) ? BCR_VERSION : $datos['Version'];
    }

    /**
     * Tras instalar una actualización NUESTRA: olvidar nuestra caché y la lista
     * de versiones de WordPress, para que el aviso desaparezca al terminar en
     * vez de esperar a que caduque.
     */
    public static function tras_actualizar($upgrader = null, $extra = array()) {
        $yo = plugin_basename(BCR_FILE);
        $tocados = array();
        if (is_array($extra)) {
            if (!empty($extra['plugins']) && is_array($extra['plugins'])) {
                $tocados = $extra['plugins'];
            } elseif (!empty($extra['plugin'])) {
                $tocados = array($extra['plugin']);
            }
        }
        if ($tocados && !in_array($yo, $tocados, true)) {
            return;   // han actualizado otro plugin: no es cosa nuestra
        }
        self::flush_cache();
        delete_site_transient('update_plugins');
    }

    /**
     * Red de seguridad: si en la lista de versiones de WordPress hay un aviso
     * de "hay novedad" para nosotros que ofrece una versión que YA está puesta,
     * se quita. Así un aviso pegado se cae solo en la siguiente pantalla del
     * escritorio, sin esperar 12 h ni tener que pulsar nada.
     */
    public static function limpiar_aviso_viejo() {
        $t = get_site_transient('update_plugins');
        if (!is_object($t) || empty($t->response) || !is_array($t->response)) {
            return;
        }
        $yo = plugin_basename(BCR_FILE);
        if (empty($t->response[$yo])) {
            return;
        }
        $ofrecida = isset($t->response[$yo]->new_version) ? $t->response[$yo]->new_version : '';
        if ($ofrecida && version_compare($ofrecida, self::version_instalada(), '>')) {
            return;   // la novedad es de verdad: no tocar
        }
        $aviso = $t->response[$yo];
        unset($t->response[$yo]);
        if (!isset($t->no_update) || !is_array($t->no_update)) {
            $t->no_update = array();
        }
        $t->no_update[$yo] = $aviso;   // seguimos anunciados: el interruptor no se pierde
        set_site_transient('update_plugins', $t);
    }

    public static function flush_cache() {
        delete_site_transient(self::CACHE_KEY);
    }
}
