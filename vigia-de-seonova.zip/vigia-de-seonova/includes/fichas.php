<?php
/**
 * GENERADO — no editar a mano. Fuente: toolkit privado, tools/export-radar-fichas.mjs
 * (src/lib/bot-patterns.json + src/lib/bot-fichas-textos.json). Se regenera en cada build.
 *
 * Ficha en cristiano de cada bot conocido + la prosa común (familias, por qué
 * cae en cada cajón, textos para los que no tienen ficha). La misma que enseña
 * el panel de WPO Toolkit.
 */

defined('ABSPATH') || exit;

/** Fichas por bot: patrón (trozo del user-agent o del nombre) → ficha. Patrones largos primero. */
function bcr_fichas() {
    static $f = null;
    if ($f === null) {
        $f = array(
        'chrome privacy preserving prefetch proxy' => array(
            'familia' => 'infra',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Chrome precargando tu página desde Google antes de que alguien haga clic. Media visita: viene de una persona a punto de entrar.',
            'en' => 'Chrome pre-loading your page via Google before someone clicks. Half a visit: it comes from a person about to enter.',
        ),
        'serankingbacklinksbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'SE Ranking, índice de enlaces.',
            'en' => 'SE Ranking, a link index.',
        ),
        'velenpublicwebcrawler' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Velen, rastreador de datos comerciales.',
            'en' => 'Velen, a commercial data crawler.',
        ),
        '(compatible; crawler)' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un rastreador sin nombre. Quien no dice quién es, algo esconde.',
            'en' => 'A crawler with no name. Whoever will not say who they are is hiding something.',
        ),
        'backlinksextendedbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Otro índice de enlaces.',
            'en' => 'Another link index.',
        ),
        'facebookexternalhit' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Facebook e Instagram sacando la miniatura cuando alguien comparte tu enlace.',
            'en' => 'Facebook and Instagram fetching the thumbnail when someone shares your link.',
        ),
        'meta-externalagent' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Meta leyendo para entrenar su IA.',
            'en' => 'Meta reading to train its AI.',
        ),
        'palo alto networks' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Escáner de seguridad de Palo Alto Networks buscando agujeros.',
            'en' => 'Palo Alto Networks security scanner probing for holes.',
        ),
        'applebot-extended' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Igual que Google-Extended pero de Apple: un permiso de robots.txt, no un robot.',
            'en' => 'Apple\'s version of Google-Extended: a robots.txt switch, not a robot.',
        ),
        'domainemailfinder' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Busca direcciones de correo en tu web para vendérselas a spammers.',
            'en' => 'Harvests email addresses from your site to sell to spammers.',
        ),
        'claude-searchbot' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Claude (Anthropic) buscando para responder con enlaces.',
            'en' => 'Claude (Anthropic) searching to answer with links.',
        ),
        'webtrackrcrawler' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Affsignal, rastreador de afiliación.',
            'en' => 'Affsignal, an affiliate crawler.',
        ),
        'sogou web spider' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Buscador chino (Tencent). En occidente no trae nada.',
            'en' => 'Chinese search engine (Tencent). Brings nothing in the West.',
        ),
        'googlebot-image' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Google leyendo tus imágenes para Google Imágenes.',
            'en' => 'Google reading your images for Google Images.',
        ),
        'perplexity-user' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'no',
            'es' => 'Perplexity abriendo tu página a petición de un usuario.',
            'en' => 'Perplexity opening your page at a user\'s request.',
        ),
        'meta-webindexer' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Meta indexando para las búsquedas dentro de sus apps.',
            'en' => 'Meta indexing for search inside its apps.',
        ),
        'google-extended' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'No es un robot: es el permiso de robots.txt para que Google use tu contenido en Gemini. Googlebot sigue siendo el mismo.',
            'en' => 'Not a robot: it is the robots.txt switch letting Google use your content in Gemini. Googlebot itself is unchanged.',
        ),
        'googlebot-news' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Google News recogiendo tus artículos.',
            'en' => 'Google News picking up your articles.',
        ),
        'amzn-searchbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Amazon buscando productos y precios.',
            'en' => 'Amazon looking for products and prices.',
        ),
        'go-http-client' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Go sin identificarse.',
            'en' => 'A Go program that does not identify itself.',
        ),
        'awariosmartbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Awario vigila menciones de marcas para sus clientes. No te trae nada.',
            'en' => 'Awario tracks brand mentions for its clients. Brings you nothing.',
        ),
        'peer39_crawler' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Clasifica tu contenido para anuncios contextuales.',
            'en' => 'Classifies your content for contextual ads.',
        ),
        'headlesschrome' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Chrome sin ventana, manejado por un programa. Nadie navega así.',
            'en' => 'Chrome without a window, driven by a program. Nobody browses like this.',
        ),
        'oai-searchbot' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'OpenAI buscando para ChatGPT. Cuando te cita, enlaza: sí puede traer visitas.',
            'en' => 'OpenAI searching for ChatGPT. When it quotes you it links: it can bring visits.',
        ),
        'perplexitybot' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'nose',
            'es' => 'Perplexity indexando para responder con fuentes enlazadas.',
            'en' => 'Perplexity indexing to answer with linked sources.',
        ),
        'mediapartners' => array(
            'familia' => 'anuncios',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Google mirando tus páginas para decidir qué anuncios pegan. Si lo bloqueas, tus anuncios empeoran.',
            'en' => 'Google checking your pages to decide which ads fit. Block it and your ads get worse.',
        ),
        'dataforseobot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Vende posiciones y datos de búsqueda a otras herramientas.',
            'en' => 'Sells rankings and search data to other tools.',
        ),
        'duckassistbot' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'DuckDuckGo leyendo para sus respuestas con IA (DuckAssist).',
            'en' => 'DuckDuckGo reading for its AI answers (DuckAssist).',
        ),
        'adstxtcrawler' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Lee tu fichero ads.txt para confirmar quién puede vender tus anuncios.',
            'en' => 'Reads your ads.txt file to confirm who may sell your ads.',
        ),
        'google-adstxt' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Google leyendo tu ads.txt para confirmar quién puede vender tus anuncios.',
            'en' => 'Google reading your ads.txt to confirm who may sell your ads.',
        ),
        'chatgpt-user' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'no',
            'es' => 'ChatGPT abriendo tu página porque un usuario se lo pidió. Es casi una persona; por eso no mira robots.txt.',
            'en' => 'ChatGPT opening your page because a user asked for it. Almost a person; that is why it skips robots.txt.',
        ),
        'pinterestbot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Pinterest leyendo tus imágenes para los pines.',
            'en' => 'Pinterest reading your images for pins.',
        ),
        'anthropic-ai' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Anthropic (Claude), nombre antiguo del mismo robot.',
            'en' => 'Anthropic (Claude), an older name of the same robot.',
        ),
        'imagesiftbot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'ImageSift (Hive) recoge imágenes para entrenar IA.',
            'en' => 'ImageSift (Hive) collects images to train AI.',
        ),
        'bidswitchbot' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Plataforma de compra de anuncios comprobando tus páginas.',
            'en' => 'Ad-buying platform checking your pages.',
        ),
        'duckduckbot' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'El buscador DuckDuckGo.',
            'en' => 'The DuckDuckGo search engine.',
        ),
        'baiduspider' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'El buscador chino. En occidente no suele traer nada y no siempre respeta robots.txt.',
            'en' => 'The Chinese search engine. In the West it usually brings nothing and does not always respect robots.txt.',
        ),
        'claude-user' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'no',
            'es' => 'Claude abriendo tu página porque un usuario se lo pidió.',
            'en' => 'Claude opening your page because a user asked for it.',
        ),
        'linkedinbot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'LinkedIn sacando la vista previa de tu enlace.',
            'en' => 'LinkedIn fetching your link preview.',
        ),
        'telegrambot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Telegram sacando la vista previa de tu enlace.',
            'en' => 'Telegram fetching your link preview.',
        ),
        'facebookbot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Meta (Facebook) leyendo para entrenar su IA.',
            'en' => 'Meta (Facebook) reading to train its AI.',
        ),
        'libwww-perl' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Perl, herramienta clásica de raspado.',
            'en' => 'A Perl program, a classic scraping tool.',
        ),
        'seekportbot' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Buscador alemán pequeño.',
            'en' => 'Small German search engine.',
        ),
        'serpstatbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Herramienta SEO, de la misma familia.',
            'en' => 'SEO tool, same family.',
        ),
        'ias_crawler' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Integral Ad Science comprueba que tus páginas son seguras para los anunciantes. Sin él, algunos anuncios no se sirven.',
            'en' => 'Integral Ad Science checks your pages are safe for advertisers. Without it, some ads are not served.',
        ),
        'twitterbot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'X (Twitter) montando la tarjeta de tu enlace.',
            'en' => 'X (Twitter) building your link card.',
        ),
        'discordbot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Discord sacando la vista previa de tu enlace.',
            'en' => 'Discord fetching your link preview.',
        ),
        'semrushbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Herramienta SEO: apunta quién enlaza a quién y le vende ese dato a tu competencia. Si auditas tu web con Semrush, este eres tú: no lo bloquees.',
            'en' => 'SEO tool: it maps who links to whom and sells that to your competitors. If you audit your own site with Semrush, this is you: do not block it.',
        ),
        'bytespider' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'ByteDance (TikTok). De los más tragones: puede pedirte miles de páginas al día.',
            'en' => 'ByteDance (TikTok). One of the hungriest: it can hit thousands of pages a day.',
        ),
        'node-fetch' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en JavaScript (Node) sin identificarse.',
            'en' => 'A JavaScript (Node) program that does not identify itself.',
        ),
        'barkrowler' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Babbar, un índice de enlaces francés.',
            'en' => 'Babbar, a French link index.',
        ),
        'terracotta' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'nose',
            'es' => 'Rastreador SEO poco conocido.',
            'en' => 'Little-known SEO crawler.',
        ),
        'playwright' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Navegador manejado por Playwright, herramienta de automatización.',
            'en' => 'A browser driven by Playwright, an automation tool.',
        ),
        'googlebot' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'El robot que lee tus páginas para el buscador de Google.',
            'en' => 'The robot that reads your pages for the Google search index.',
        ),
        'seznambot' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Buscador checo.',
            'en' => 'Czech search engine.',
        ),
        'ahrefsbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Herramienta SEO, lo mismo que Semrush. De los que más páginas se llevan.',
            'en' => 'SEO tool, same idea as Semrush. One of the hungriest.',
        ),
        'claudebot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Anthropic (Claude) haciendo lo mismo que GPTBot.',
            'en' => 'Anthropic (Claude) doing the same as GPTBot.',
        ),
        'cohere-ai' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Cohere leyendo para entrenar sus modelos.',
            'en' => 'Cohere reading to train its models.',
        ),
        'omgilibot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Webz.io (antes Omgili) revende contenido web como datos.',
            'en' => 'Webz.io (formerly Omgili) resells web content as data.',
        ),
        'java-http' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Java sin identificarse.',
            'en' => 'A Java program that does not identify itself.',
        ),
        'brightbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Bright Data alquila su red para raspar webs. Lo que pide se lo lleva otro.',
            'en' => 'Bright Data rents out its network to scrape sites. Whatever it fetches goes to someone else.',
        ),
        'criteobot' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Criteo (retargeting) mirando tus páginas de producto.',
            'en' => 'Criteo (retargeting) looking at your product pages.',
        ),
        'mojeekbot' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Buscador independiente británico.',
            'en' => 'Independent British search engine.',
        ),
        'shap-user' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'nose',
            'es' => 'Un entorno de pruebas de IA abriendo tu página.',
            'en' => 'An AI sandbox opening your page.',
        ),
        'phantomjs' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Navegador sin ventana (antiguo). Solo lo usan programas.',
            'en' => 'An old windowless browser. Only programs use it.',
        ),
        'puppeteer' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Chrome manejado por Puppeteer, herramienta de automatización.',
            'en' => 'Chrome driven by Puppeteer, an automation tool.',
        ),
        'applebot' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Apple leyendo para Siri y Spotlight.',
            'en' => 'Apple reading for Siri and Spotlight.',
        ),
        'naverbot' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Buscador coreano.',
            'en' => 'Korean search engine.',
        ),
        'whatsapp' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'WhatsApp sacando la vista previa cuando alguien pega tu enlace en un chat.',
            'en' => 'WhatsApp fetching the preview when someone pastes your link in a chat.',
        ),
        'slackbot' => array(
            'familia' => 'social',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Slack sacando la vista previa de tu enlace.',
            'en' => 'Slack fetching your link preview.',
        ),
        'petalbot' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Huawei, para su buscador. En occidente casi no manda visitas y rastrea mucho.',
            'en' => 'Huawei, for its search engine. Barely any visits in the West, and it crawls a lot.',
        ),
        'sebot-wa' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'nose',
            'es' => 'Rastreador SEO poco conocido.',
            'en' => 'Little-known SEO crawler.',
        ),
        'mozlila/' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Se escribe "Mozlila" a propósito para colarse por "Mozilla". Disfraz torpe.',
            'en' => 'Spelled "Mozlila" on purpose to slip past as "Mozilla". A clumsy disguise.',
        ),
        'proximic' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'comScore clasifica tu contenido para que los anunciantes sepan dónde salen.',
            'en' => 'comScore classifies your content so advertisers know where they appear.',
        ),
        'selenium' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Navegador manejado por Selenium, herramienta de automatización.',
            'en' => 'A browser driven by Selenium, an automation tool.',
        ),
        'bingbot' => array(
            'familia' => 'buscador',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'Lo mismo para Bing (y para las respuestas de Copilot).',
            'en' => 'Same thing for Bing (and for Copilot\'s answers).',
        ),
        'mj12bot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Majestic, un índice de enlaces. Rastrea mucho y no devuelve nada.',
            'en' => 'Majestic, a link index. Heavy crawler, brings nothing back.',
        ),
        'blexbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'nose',
            'es' => 'Rastreador SEO (webmeup) con fama de quemar servidores.',
            'en' => 'SEO crawler (webmeup) with a reputation for burning through servers.',
        ),
        'diffbot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Diffbot convierte webs en datos para vendérselos a empresas.',
            'en' => 'Diffbot turns websites into data it sells to companies.',
        ),
        'httrack' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'HTTrack copia webs enteras al disco.',
            'en' => 'HTTrack copies whole websites to disk.',
        ),
        'aiohttp' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Python (async) sin identificarse.',
            'en' => 'A Python (async) program that does not identify itself.',
        ),
        'yandex' => array(
            'familia' => 'buscador',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'El buscador ruso. Fuera de Rusia casi no manda visitas.',
            'en' => 'The Russian search engine. Outside Russia it sends almost no visits.',
        ),
        'youbot' => array(
            'familia' => 'ia',
            'trae' => 'si',
            'robots' => 'si',
            'es' => 'El buscador con IA You.com.',
            'en' => 'The You.com AI search engine.',
        ),
        'dotbot' => array(
            'familia' => 'seo',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Moz, un índice de enlaces. Rastrea mucho y no devuelve nada.',
            'en' => 'Moz, a link index. Crawls a lot, brings nothing back.',
        ),
        'gptbot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'OpenAI (ChatGPT) leyendo tu contenido para entrenar. Puede acabar citándote, pero no te manda visitas.',
            'en' => 'OpenAI (ChatGPT) reading your content to train. It may end up quoting you, but it sends no visits.',
        ),
        'python' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Python. Casi siempre un raspador casero.',
            'en' => 'A Python program. Almost always a home-made scraper.',
        ),
        'scrapy' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Scrapy, el marco de raspado más usado.',
            'en' => 'Scrapy, the most used scraping framework.',
        ),
        'axios/' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en JavaScript (Node) sin identificarse.',
            'en' => 'A JavaScript (Node) program that does not identify itself.',
        ),
        'l9scan' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'LeakIX busca fugas de datos y servidores mal configurados.',
            'en' => 'LeakIX scans for data leaks and misconfigured servers.',
        ),
        'ias-va' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Integral Ad Science comprobando anuncios de vídeo.',
            'en' => 'Integral Ad Science checking video ads.',
        ),
        'ias-ie' => array(
            'familia' => 'anuncios',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Integral Ad Science comprobando tus páginas.',
            'en' => 'Integral Ad Science checking your pages.',
        ),
        'orbbot' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'nose',
            'es' => 'Rastreador poco conocido.',
            'en' => 'Little-known crawler.',
        ),
        'ccbot' => array(
            'familia' => 'ia',
            'trae' => 'no',
            'robots' => 'si',
            'es' => 'Common Crawl: copia la web entera a un archivo público que otros usan para entrenar IA.',
            'en' => 'Common Crawl: it copies the whole web into a public archive that others use to train AI.',
        ),
        'curl/' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Programa de línea de comandos. Ningún navegador es esto: alguien probando o raspando sin disfraz.',
            'en' => 'Command-line program. No browser looks like this: someone testing or scraping without a disguise.',
        ),
        'wget/' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Descargador masivo de línea de comandos.',
            'en' => 'Bulk command-line downloader.',
        ),
        'bun/' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en JavaScript (Bun) sin identificarse.',
            'en' => 'A JavaScript (Bun) program that does not identify itself.',
        ),
        'ruby' => array(
            'familia' => 'sospechoso',
            'trae' => 'no',
            'robots' => 'no',
            'es' => 'Un programa en Ruby sin identificarse.',
            'en' => 'A Ruby program that does not identify itself.',
        ),
    );
    }
    return $f;
}

/** Prosa común: familias, cajones, textos genéricos y valores (sí/no/no se sabe). */
function bcr_textos() {
    static $t = null;
    if ($t === null) {
        $t = array(
        'familias' => array(
            'buscador' => array(
                'nombre' => array(
                    'es' => 'Buscador',
                    'en' => 'Search engine',
                ),
                'consejo' => array(
                    'es' => 'Te trae visitas. Cuantos más, mejor.',
                    'en' => 'Brings you visits. The more, the better.',
                ),
            ),
            'ia' => array(
                'nombre' => array(
                    'es' => 'Robot de IA',
                    'en' => 'AI robot',
                ),
                'consejo' => array(
                    'es' => 'Lee para responder en ChatGPT, Claude, Perplexity… Si te cita, a veces enlaza; si solo entrena, no te manda nada.',
                    'en' => 'Reads to answer in ChatGPT, Claude, Perplexity… If it quotes you it sometimes links; if it only trains, it sends nothing.',
                ),
            ),
            'social' => array(
                'nombre' => array(
                    'es' => 'Red social',
                    'en' => 'Social network',
                ),
                'consejo' => array(
                    'es' => 'Saca la miniatura cuando alguien comparte tu enlace. Señal de que te mueven.',
                    'en' => 'Fetches the thumbnail when someone shares your link. A sign people are sharing you.',
                ),
            ),
            'seo' => array(
                'nombre' => array(
                    'es' => 'Espía SEO',
                    'en' => 'SEO spy',
                ),
                'consejo' => array(
                    'es' => 'Recoge datos de tu web para vendérselos a otros (a tu competencia, normalmente). No te trae ni una visita.',
                    'en' => 'Collects data about your site to sell to others (usually your competitors). Brings you no visits.',
                ),
            ),
            'anuncios' => array(
                'nombre' => array(
                    'es' => 'Verificador de anuncios',
                    'en' => 'Ad verifier',
                ),
                'consejo' => array(
                    'es' => 'Hace falta para que te paguen los anuncios: comprueba tu contenido y tu ads.txt. No lo bloquees.',
                    'en' => 'Needed for your ads to pay: it checks your content and your ads.txt. Do not block it.',
                ),
            ),
            'infra' => array(
                'nombre' => array(
                    'es' => 'Infraestructura',
                    'en' => 'Infrastructure',
                ),
                'consejo' => array(
                    'es' => 'Cosas del propio sistema (precargas, sondas, monitores). Ni personas ni ataques.',
                    'en' => 'Plumbing of the system itself (prefetch, probes, monitors). Neither people nor attacks.',
                ),
            ),
            'sospechoso' => array(
                'nombre' => array(
                    'es' => 'Sospechoso',
                    'en' => 'Suspicious',
                ),
                'consejo' => array(
                    'es' => 'Sin nombre o con herramienta de raspado. Aquí vive el que copia contenido.',
                    'en' => 'No name, or a scraping tool. This is where content copiers live.',
                ),
            ),
        ),
        'cajones' => array(
            'bueno' => array(
                'nombre' => array(
                    'es' => 'bot bueno verificado',
                    'en' => 'verified good bot',
                ),
                'razon' => array(
                    'es' => 'Dice ser un bot conocido Y su dirección pertenece a esa empresa. Comprobado por IP, que no se puede falsear, no por el nombre.',
                    'en' => 'It claims to be a known bot AND its address belongs to that company. Checked by IP, which cannot be faked, not by name.',
                ),
            ),
            'impostor' => array(
                'nombre' => array(
                    'es' => 'impostor',
                    'en' => 'impostor',
                ),
                'razon' => array(
                    'es' => 'Dice ser un bot conocido pero su dirección NO está en el rango oficial de esa empresa. El nombre es un disfraz.',
                    'en' => 'It claims to be a known bot but its address is NOT in that company\'s official range. The name is a costume.',
                ),
            ),
            'datacenter' => array(
                'nombre' => array(
                    'es' => 'centro de datos',
                    'en' => 'data center',
                ),
                'razon' => array(
                    'es' => 'Se presenta como un navegador normal, pero su dirección es de un centro de datos. La gente no navega desde una granja de servidores.',
                    'en' => 'It introduces itself as a normal browser, but its address belongs to a data center. People do not browse from a server farm.',
                ),
            ),
            'declarado' => array(
                'nombre' => array(
                    'es' => 'declarado',
                    'en' => 'declared',
                ),
                'razon' => array(
                    'es' => 'Dice abiertamente que es un bot en su user-agent. Es honesto; otra cosa es que te convenga.',
                    'en' => 'It says outright that it is a bot in its user-agent. It is honest about it; whether it suits you is another matter.',
                ),
            ),
            'humano' => array(
                'nombre' => array(
                    'es' => 'humano',
                    'en' => 'human',
                ),
                'razon' => array(
                    'es' => 'Navegador normal y dirección sin señal de nada.',
                    'en' => 'A normal browser from an address with no red flags.',
                ),
            ),
        ),
        'sinFicha' => array(
            'datacenter' => array(
                'es' => 'Una red de servidores de alquiler. Nadie navega desde ahí: quien viene de esa dirección es un programa, no una persona.',
                'en' => 'A rented server network. Nobody browses from there: whoever comes from that address is a program, not a person.',
            ),
            'impostor' => array(
                'es' => 'Alguien poniéndose el nombre de un bot conocido para colarse. El de verdad nunca viene de esta dirección.',
                'en' => 'Someone wearing the name of a well-known bot to get in. The real one never comes from this address.',
            ),
            'declarado' => array(
                'es' => 'Un bot que dice su nombre. De este todavía no tenemos ficha.',
                'en' => 'A bot that says its own name. We do not have a file on this one yet.',
            ),
            'bueno' => array(
                'es' => 'Un bot conocido y verificado por su dirección.',
                'en' => 'A known bot, verified by its address.',
            ),
            'sinUa' => array(
                'es' => 'No dijo quién es. Ningún navegador hace eso: es un programa.',
                'en' => 'It did not say who it is. No browser does that: it is a script.',
            ),
        ),
        'valores' => array(
            'si' => array(
                'es' => 'Sí',
                'en' => 'Yes',
            ),
            'no' => array(
                'es' => 'No',
                'en' => 'No',
            ),
            'nose' => array(
                'es' => 'No se sabe',
                'en' => 'Not known',
            ),
        ),
    );
    }
    return $t;
}
