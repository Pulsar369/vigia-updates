<?php
/**
 * Barrendero de restos — para que borrar este plugin NUNCA obligue a entrar
 * por FTP o por el gestor de ficheros del hosting.
 *
 * POR QUÉ EXISTE (casos reales, agosto 2026):
 *
 * 1) El plugin ha cambiado de nombre de carpeta por el camino:
 *    bot-cost-radar → vigia-de-bots → vigia-de-seonova. Cada cambio deja la
 *    instalación vieja en wp-content/plugins, y WordPress la sigue listando
 *    como si fuera OTRO plugin distinto.
 *
 * 2) Un ZIP empaquetado en Windows con PowerShell (Compress-Archive) mete
 *    barras INVERTIDAS en las rutas. Linux no las entiende como carpetas: al
 *    descomprimir deja ficheros SUELTOS llamados literalmente
 *    "vigia-de-bots\vigia-de-bots.php". WordPress lee su cabecera y lo lista
 *    como plugin; pero al pulsar "Borrar", el núcleo decide entre borrar una
 *    carpeta o un fichero mirando si el nombre lleva una barra NORMAL
 *    (delete_plugins() usa strpos($plugin_file, '/')). Con barra invertida no
 *    la lleva, así que borra "el fichero" y deja detrás el resto del árbol.
 *    El usuario pulsa diez veces y el fantasma sigue en la lista.
 *
 * 3) Ficheros que PHP no puede borrar (los subió otro usuario por FTP o se
 *    descomprimieron desde cPanel): WordPress avisa con un rojo pequeñito que
 *    es fácil no ver, y el plugin se queda ahí para siempre.
 *
 * QUÉ HACE: mira SOLO dentro de wp-content/plugins (y en la copia temporal de
 * actualización de WordPress), SOLO nombres que han sido nuestros, NUNCA la
 * instalación que está corriendo, y borra lo que sobra. Si no puede borrar
 * algo, lo dice con la RUTA EXACTA en vez de dejar al usuario adivinando.
 */

defined('ABSPATH') || exit;

class BCR_Cleanup {

    /** Aviso pendiente de enseñar (lo que se borró en la última pasada). */
    const OPT_AVISO = 'bcr_cleanup_aviso';
    /** Restos que NO se pudieron borrar: se guardan hasta que desaparezcan. */
    const OPT_FALLOS = 'bcr_cleanup_fallos';
    /** Sello para no barrer en cada carga del admin. */
    const TR_SELLO = 'bcr_cleanup_sello';

    public static function init() {
        add_action('admin_init', array(__CLASS__, 'boton_manual'));
        add_action('admin_init', array(__CLASS__, 'quizas_barrer'));
        add_action('admin_notices', array(__CLASS__, 'aviso'));
    }

    /**
     * Nombres de carpeta que este plugin ha tenido. Cualquier entrada de
     * wp-content/plugins con uno de estos nombres que NO sea la instalación
     * actual es un resto nuestro y se puede barrer.
     */
    public static function nombres() {
        return array('vigia-de-seonova', 'vigia-de-bots', 'bot-cost-radar');
    }

    /** Entrada de wp-content/plugins que ocupa la instalación EN MARCHA. */
    public static function entrada_propia() {
        $base = plugin_basename(BCR_FILE);          // "vigia-de-seonova/vigia-de-seonova.php"
        $pos  = strpos($base, '/');
        return $pos === false ? $base : substr($base, 0, $pos);
    }

    /** Primer tramo de una entrada, sin ".php" y con las barras normalizadas. */
    private static function slug_de($entrada) {
        $n = str_replace('\\', '/', $entrada);
        $partes = explode('/', $n);
        $n = $partes[0];
        if (substr($n, -4) === '.php') {
            $n = substr($n, 0, -4);
        }
        return $n;
    }

    /**
     * ¿Esta entrada del directorio de plugins es un resto nuestro?
     * Normaliza barras invertidas para pillar también los ficheros sueltos
     * del ZIP roto ("vigia-de-bots\includes\class-bcr-store.php").
     */
    public static function es_resto($entrada) {
        if ($entrada === '.' || $entrada === '..' || $entrada === '') {
            return false;
        }
        if ($entrada === self::entrada_propia()) {
            return false;   // la instalación que está corriendo: ni tocarla
        }
        return in_array(self::slug_de($entrada), self::nombres(), true);
    }

    /**
     * Lista de restos encontrados. Se miran dos sitios: wp-content/plugins y
     * la copia temporal que WordPress 6.3+ deja en
     * wp-content/upgrade-temp-backup/plugins/ cuando una actualización falla.
     *
     * @return array<int, array{ruta:string, entrada:string, donde:string}>
     */
    public static function restos() {
        $out = array();

        foreach (self::listar(WP_PLUGIN_DIR) as $entrada) {
            if (self::es_resto($entrada)) {
                $out[] = array(
                    'ruta'    => WP_PLUGIN_DIR . '/' . $entrada,
                    'entrada' => $entrada,
                    'donde'   => 'plugins',
                );
            }
        }

        $backup = dirname(WP_PLUGIN_DIR) . '/upgrade-temp-backup/plugins';
        foreach (self::listar($backup) as $entrada) {
            // Aquí SÍ cuenta nuestro propio nombre: es una copia, no la instalación.
            if ($entrada === '.' || $entrada === '..') {
                continue;
            }
            if (in_array(self::slug_de($entrada), self::nombres(), true)) {
                $out[] = array(
                    'ruta'    => $backup . '/' . $entrada,
                    'entrada' => $entrada,
                    'donde'   => 'copia-temporal',
                );
            }
        }

        return $out;
    }

    /** Entradas de un directorio (vacío si no existe o no se puede leer). */
    private static function listar($dir) {
        if (!is_dir($dir) || !is_readable($dir)) {
            return array();
        }
        $e = @scandir($dir);
        return is_array($e) ? $e : array();
    }

    /**
     * Barre los restos. Antes de borrar, desengancha el fantasma de la lista
     * de plugins activos: si no, WordPress intenta cargar un fichero que ya
     * no existe y suelta un warning en cada petición.
     *
     * @return array{borrados: string[], fallidos: string[]}
     */
    public static function barrer() {
        $restos   = self::restos();
        $borrados = array();
        $fallidos = array();

        if ($restos) {
            self::desactivar_fantasmas($restos);
        }

        foreach ($restos as $r) {
            if (self::borrar($r['ruta'])) {
                $borrados[] = $r['entrada'];
                self::borrar_traducciones($r['entrada']);
            } else {
                $fallidos[] = $r['ruta'];
            }
        }

        if ($borrados || $fallidos) {
            // Que WordPress relea el directorio: si no, sigue enseñando el
            // fantasma en la lista hasta la siguiente carga.
            if (function_exists('wp_clean_plugins_cache')) {
                wp_clean_plugins_cache(false);
            }
            delete_site_transient('update_plugins');
        }

        if ($fallidos) {
            update_option(self::OPT_FALLOS, $fallidos, false);
        } else {
            delete_option(self::OPT_FALLOS);
        }
        if ($borrados) {
            update_option(self::OPT_AVISO, $borrados, false);
        }

        return array('borrados' => $borrados, 'fallidos' => $fallidos);
    }

    /**
     * Quita de active_plugins (y de la red, en multisitio) cualquier entrada
     * que apunte a un resto.
     */
    private static function desactivar_fantasmas($restos) {
        $entradas = array();
        foreach ($restos as $r) {
            if ($r['donde'] === 'plugins') {
                $entradas[] = $r['entrada'];
            }
        }
        if (!$entradas) {
            return;
        }

        $yo      = plugin_basename(BCR_FILE);
        $activos = (array) get_option('active_plugins', array());
        $quedan  = array();
        foreach ($activos as $a) {
            if ($a === $yo) {
                $quedan[] = $a;      // jamás desactivarse a sí mismo
                continue;
            }
            $fuera = false;
            foreach ($entradas as $e) {
                if (self::apunta_a($a, $e)) {
                    $fuera = true;
                    break;
                }
            }
            if (!$fuera) {
                $quedan[] = $a;
            }
        }
        if (count($quedan) !== count($activos)) {
            update_option('active_plugins', array_values($quedan));
        }

        if (is_multisite()) {
            $red    = (array) get_site_option('active_sitewide_plugins', array());
            $cambio = false;
            foreach (array_keys($red) as $clave) {
                if ($clave === $yo) {
                    continue;
                }
                foreach ($entradas as $e) {
                    if (self::apunta_a($clave, $e)) {
                        unset($red[$clave]);
                        $cambio = true;
                        break;
                    }
                }
            }
            if ($cambio) {
                update_site_option('active_sitewide_plugins', $red);
            }
        }
    }

    /**
     * ¿Esta entrada de active_plugins apunta a ese resto? Solo vale la
     * coincidencia exacta o estar DENTRO de la carpeta del resto. Nada de
     * "empieza parecido": "vigia-de-bots-pro" no es "vigia-de-bots", y un
     * fichero plano con nuestro propio nombre no puede arrastrar a la
     * instalación que está corriendo.
     */
    private static function apunta_a($activo, $entrada) {
        return $activo === $entrada || strpos($activo, $entrada . '/') === 0;
    }

    /** Traducciones sueltas en wp-content/languages/plugins/<slug>-*.mo|po. */
    private static function borrar_traducciones($entrada) {
        if (!defined('WP_LANG_DIR')) {
            return;
        }
        if (strpos($entrada, '\\') !== false || strpos($entrada, '/') !== false) {
            return;     // fichero suelto del ZIP roto: no tiene traducciones propias
        }
        $slug = self::slug_de($entrada);
        if (!in_array($slug, self::nombres(), true) || $slug === self::entrada_propia()) {
            return;
        }
        $ficheros = glob(WP_LANG_DIR . '/plugins/' . $slug . '-*.{mo,po}', GLOB_BRACE);
        foreach ((array) $ficheros as $f) {
            @unlink($f);
        }
    }

    /**
     * Borra un fichero o una carpeta entera. Cinturón de seguridad: la ruta
     * tiene que quedar DENTRO de wp-content (nunca se sale de ahí, ni por
     * enlaces simbólicos ni por "..").
     */
    private static function borrar($ruta) {
        $raiz = realpath(dirname(WP_PLUGIN_DIR));
        $real = realpath($ruta);
        if (!$raiz || !$real || strpos($real, $raiz) !== 0) {
            return false;
        }
        if (is_link($real) || is_file($real)) {
            return (bool) @unlink($real);
        }
        if (!is_dir($real)) {
            return false;
        }
        $ok = true;
        foreach (self::listar($real) as $hijo) {
            if ($hijo === '.' || $hijo === '..') {
                continue;
            }
            $ok = self::borrar($real . '/' . $hijo) && $ok;
        }
        return @rmdir($real) && $ok;
    }

    /**
     * Barrido automático: una vez al día como mucho. Leer un directorio no
     * cuesta nada, pero tampoco hace falta hacerlo en cada carga del admin.
     */
    public static function quizas_barrer() {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        if (get_transient(self::TR_SELLO)) {
            return;
        }
        set_transient(self::TR_SELLO, 1, DAY_IN_SECONDS);
        self::barrer();
    }

    /** Botón "Reintentar" del aviso. */
    public static function boton_manual() {
        if (empty($_GET['bcr_limpiar']) || !current_user_can('activate_plugins')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_limpiar')) {
            return;
        }
        delete_transient(self::TR_SELLO);
        self::barrer();
        wp_safe_redirect(remove_query_arg(array('bcr_limpiar', '_wpnonce')));
        exit;
    }

    /** Aviso en el admin: qué se barrió, o qué no se pudo barrer y dónde está. */
    public static function aviso() {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        $borrados = get_option(self::OPT_AVISO);
        if (is_array($borrados) && $borrados) {
            delete_option(self::OPT_AVISO);
            echo '<div class="notice notice-success is-dismissible"><p>'
                . esc_html(sprintf(
                    /* translators: %s: comma-separated list of leftover folders or files that were removed. */
                    __('VigIA de SeoNova cleaned up leftovers from an older install: %s. Nothing of yours was touched.', 'vigia-de-seonova'),
                    implode(', ', array_map('sanitize_text_field', $borrados))
                ))
                . '</p></div>';
        }

        $fallos = get_option(self::OPT_FALLOS);
        if (is_array($fallos) && $fallos) {
            $url = wp_nonce_url(add_query_arg('bcr_limpiar', '1'), 'bcr_limpiar');
            echo '<div class="notice notice-warning"><p><strong>'
                . esc_html__('VigIA de SeoNova: an older install left files behind and WordPress cannot delete them (file permissions).', 'vigia-de-seonova')
                . '</strong></p><p>'
                . esc_html__('Delete these exact paths from your hosting file manager or over FTP:', 'vigia-de-seonova')
                . '</p><ul style="list-style:disc;margin-left:22px">';
            foreach ($fallos as $f) {
                echo '<li><code>' . esc_html($f) . '</code></li>';
            }
            echo '</ul><p><a class="button" href="' . esc_url($url) . '">'
                . esc_html__('Try again', 'vigia-de-seonova') . '</a></p></div>';
        }
    }
}
