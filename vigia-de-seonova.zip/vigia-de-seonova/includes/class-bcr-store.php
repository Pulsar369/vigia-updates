<?php
/**
 * Almacenamiento — pensado para hosting compartido:
 *
 *   wp_bcr_visits — búfer circular de las últimas 500 visitas (se poda solo).
 *   wp_bcr_daily  — 1 fila por día con contadores por cajón (60 días).
 *
 * Cero crecimiento infinito. La escritura por visita es 1 INSERT + 1 UPSERT.
 */

defined('ABSPATH') || exit;

class BCR_Store {

    const MAX_VISITS   = 1000;
    const PRUNE_EVERY  = 50;   // poda el búfer 1 de cada 50 inserts
    const DAILY_KEEP   = 60;   // días de agregados que se conservan

    public static function visits_table() {
        global $wpdb;
        return $wpdb->prefix . 'bcr_visits';
    }

    public static function daily_table() {
        global $wpdb;
        return $wpdb->prefix . 'bcr_daily';
    }

    public static function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $v = self::visits_table();
        $d = self::daily_table();
        dbDelta("CREATE TABLE $v (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ts DATETIME NOT NULL,
            ip VARCHAR(45) NOT NULL,
            ua VARCHAR(255) NOT NULL DEFAULT '',
            path VARCHAR(191) NOT NULL DEFAULT '',
            bucket VARCHAR(12) NOT NULL,
            who VARCHAR(60) NOT NULL DEFAULT '',
            rdns VARCHAR(191) NULL DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY ip (ip),
            KEY bucket (bucket)
        ) $charset;");
        dbDelta("CREATE TABLE $d (
            d DATE NOT NULL,
            total INT UNSIGNED NOT NULL DEFAULT 0,
            humano INT UNSIGNED NOT NULL DEFAULT 0,
            bueno INT UNSIGNED NOT NULL DEFAULT 0,
            impostor INT UNSIGNED NOT NULL DEFAULT 0,
            datacenter INT UNSIGNED NOT NULL DEFAULT 0,
            declarado INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY  (d)
        ) $charset;");
    }

    private static $buckets = array('humano', 'bueno', 'impostor', 'datacenter', 'declarado');

    /** Registra una visita clasificada. */
    public static function record($ip, $ua, $path, $bucket, $who) {
        global $wpdb;
        if (!in_array($bucket, self::$buckets, true)) {
            $bucket = 'humano';
        }
        // Anti-duplicado: misma IP + misma página en <60 s = una sola visita.
        // (Caso real 2026-08-25: cada página aparecía DOS veces en el mismo
        // segundo — dobles peticiones del cliente que inflaban búfer y conteos.)
        $dup = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . self::visits_table() . "
             WHERE ip = %s AND path = %s AND ts >= %s LIMIT 1",
            substr($ip, 0, 45), mb_substr($path, 0, 191),
            gmdate('Y-m-d H:i:s', strtotime(current_time('mysql')) - 60)
        ));
        if ($dup) {
            return;
        }
        $wpdb->insert(self::visits_table(), array(
            'ts'     => current_time('mysql'),
            'ip'     => substr($ip, 0, 45),
            'ua'     => mb_substr($ua, 0, 255),
            'path'   => mb_substr($path, 0, 191),
            'bucket' => $bucket,
            'who'    => mb_substr($who, 0, 60),
        ), array('%s', '%s', '%s', '%s', '%s', '%s'));
        $id = (int) $wpdb->insert_id;

        // Agregado del día (UPSERT).
        $col = esc_sql($bucket); // nombre de columna validado arriba contra la lista
        $wpdb->query($wpdb->prepare(
            "INSERT INTO " . self::daily_table() . " (d, total, $col) VALUES (%s, 1, 1)
             ON DUPLICATE KEY UPDATE total = total + 1, $col = $col + 1",
            current_time('Y-m-d')
        ));

        // Poda del búfer circular + de agregados viejos.
        if ($id && ($id % self::PRUNE_EVERY) === 0) {
            $wpdb->query($wpdb->prepare(
                "DELETE FROM " . self::visits_table() . " WHERE id <= %d",
                $id - self::MAX_VISITS
            ));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM " . self::daily_table() . " WHERE d < %s",
                gmdate('Y-m-d', time() - self::DAILY_KEEP * DAY_IN_SECONDS)
            ));
        }
    }

    /** Recoloca una visita de cajón (la usa el enriquecedor rDNS) ajustando el día. */
    public static function reclassify($visit_id, $new_bucket, $who, $rdns) {
        global $wpdb;
        if (!in_array($new_bucket, self::$buckets, true)) {
            return;
        }
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT id, ts, bucket FROM " . self::visits_table() . " WHERE id = %d", $visit_id
        ));
        if (!$row || $row->bucket === $new_bucket) {
            if ($row) {
                $wpdb->update(self::visits_table(), array('rdns' => mb_substr((string) $rdns, 0, 191)), array('id' => $visit_id), array('%s'), array('%d'));
            }
            return;
        }
        $wpdb->update(self::visits_table(), array(
            'bucket' => $new_bucket,
            'who'    => mb_substr($who, 0, 60),
            'rdns'   => mb_substr((string) $rdns, 0, 191),
        ), array('id' => $visit_id), array('%s', '%s', '%s'), array('%d'));

        $old = esc_sql($row->bucket);
        $new = esc_sql($new_bucket);
        if (in_array($row->bucket, self::$buckets, true)) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . self::daily_table() . " SET $old = GREATEST($old, 1) - 1, $new = $new + 1 WHERE d = %s",
                substr($row->ts, 0, 10)
            ));
        }
    }

    /** Últimas N visitas para la tabla del panel (paginada). */
    public static function last_visits($n = 25, $offset = 0) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT ts, ip, ua, path, bucket, who, rdns FROM " . self::visits_table() . " ORDER BY id DESC LIMIT %d OFFSET %d",
            $n, $offset
        ));
    }

    /** Cuántas visitas hay ahora mismo en el búfer. */
    public static function count_visits() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::visits_table());
    }

    // ── Veredicto sin IA ─────────────────────────────────────────────────
    // Umbrales FIJOS y auditables (nada de magia): con suficiente historial,
    // el radar dictamina qué protección necesita esta web. Se calibraron con
    // lo medido en una flota real de 10 sitios WordPress con AdSense.
    const VERDICT_MIN_DAYS   = 3;    // días con tráfico recomendados antes de opinar
    const VERDICT_MIN_TOTAL  = 1000; // visitas recomendadas antes de opinar (más = más fino)
    const VERDICT_L2_BAD_PCT = 20;   // ≥20% bots malos → hace falta el borde (CF)
    const VERDICT_L2_HOSTILE = 10;   // ≥10 hostiles/día (impostor+datacenter) → ídem
    const VERDICT_L3_BAD_PCT = 50;   // ≥50% bots malos → nivel enjambre (CF Pro)
    const VERDICT_L3_HOSTILE = 100;  // ≥100 hostiles/día → ídem

    /**
     * @return array{state:string, level:int, days:int, total:int, bad_pct:float, hostile_day:float}
     *   state 'gathering' (aún sin datos suficientes) o 'ready' (level 1|2|3).
     */
    public static function verdict() {
        $days_rows = self::daily(30);
        $days = 0;
        foreach ($days_rows as $d) {
            if ((int) $d['total'] > 0) {
                $days++;
            }
        }
        $t = self::totals(30);
        $bad = $t['impostor'] + $t['datacenter'] + $t['declarado'];
        $hostile = $t['impostor'] + $t['datacenter'];
        $bad_pct = $t['total'] > 0 ? round($bad / $t['total'] * 100, 1) : 0;
        $hostile_day = $days > 0 ? round($hostile / $days, 1) : 0;
        $out = array('days' => $days, 'total' => $t['total'], 'bad_pct' => $bad_pct, 'hostile_day' => $hostile_day);
        // El NIVEL se calcula SIEMPRE (aunque falten datos), para el modo
        // "verlo ya" de los impacientes. El estado dice si ya es fiable o no.
        if ($bad_pct >= self::VERDICT_L3_BAD_PCT || $hostile_day >= self::VERDICT_L3_HOSTILE) {
            $level = 3;
        } elseif ($bad_pct >= self::VERDICT_L2_BAD_PCT || $hostile_day >= self::VERDICT_L2_HOSTILE) {
            $level = 2;
        } else {
            $level = 1;
        }
        $ready = ($days >= self::VERDICT_MIN_DAYS && $t['total'] >= self::VERDICT_MIN_TOTAL);
        return $out + array('state' => $ready ? 'ready' : 'gathering', 'level' => $level);
    }

    /** Agregados de los últimos $days días (ascendente, huecos incluidos como cero). */
    public static function daily($days = 30) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::daily_table() . " WHERE d >= %s ORDER BY d ASC",
            gmdate('Y-m-d', time() - $days * DAY_IN_SECONDS)
        ), ARRAY_A);
        $by = array();
        foreach ($rows as $r) {
            $by[$r['d']] = $r;
        }
        $out = array();
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = gmdate('Y-m-d', time() - $i * DAY_IN_SECONDS);
            $out[] = isset($by[$d]) ? $by[$d] : array(
                'd' => $d, 'total' => 0, 'humano' => 0, 'bueno' => 0,
                'impostor' => 0, 'datacenter' => 0, 'declarado' => 0,
            );
        }
        return $out;
    }

    /** Totales por cajón en los últimos $days días. */
    public static function totals($days = 7) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(humano),0) humano,
                    COALESCE(SUM(bueno),0) bueno, COALESCE(SUM(impostor),0) impostor,
                    COALESCE(SUM(datacenter),0) datacenter, COALESCE(SUM(declarado),0) declarado
             FROM " . self::daily_table() . " WHERE d >= %s",
            gmdate('Y-m-d', time() - $days * DAY_IN_SECONDS)
        ), ARRAY_A);
        return array_map('intval', (array) $row);
    }

    /** Coste estimado al mes: páginas de bots malos (30d) /1000 × RPM. */
    public static function monthly_cost() {
        $rpm = (float) get_option('bcr_rpm', 0);
        if ($rpm <= 0) {
            return null;
        }
        $t = self::totals(30);
        $bad = $t['impostor'] + $t['datacenter'] + $t['declarado'];
        return round($bad / 1000 * $rpm, 2);
    }

    /**
     * Quién ha pasado, agrupado por cajón + nombre, últimos $days días.
     * @param string[] $buckets  cajones a incluir
     * @return array filas {bucket, who, n, ips} ordenadas por n desc
     */
    public static function who_breakdown($buckets, $days = 7) {
        global $wpdb;
        $buckets = array_values(array_intersect((array) $buckets, self::$buckets));
        if (!$buckets) {
            return array();
        }
        $ph = implode(',', array_fill(0, count($buckets), '%s'));
        $since = gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS);
        $sql = "SELECT bucket, who, COUNT(*) n, COUNT(DISTINCT ip) ips
                FROM " . self::visits_table() . "
                WHERE ts >= %s AND bucket IN ($ph) AND who <> ''
                GROUP BY bucket, who ORDER BY n DESC";
        return $wpdb->get_results($wpdb->prepare($sql, array_merge(array($since), $buckets)));
    }

    /**
     * Ficha completa de cada "quién": cuándo apareció, qué páginas se llevó, con
     * qué IPs y cómo se presenta. Lo enseña el desplegable del panel.
     *
     * TRES consultas para TODA la lista, no una por bot: con 15 nombres en
     * pantalla, una consulta por fila serían 45 viajes a la base de datos en
     * cada carga del panel — en hosting compartido eso se nota.
     *
     * @return array<string, array> indexado por `who`
     */
    public static function who_details($buckets, $days = 7) {
        global $wpdb;
        $buckets = array_values(array_intersect((array) $buckets, self::$buckets));
        if (!$buckets) {
            return array();
        }
        $ph    = implode(',', array_fill(0, count($buckets), '%s'));
        $since = gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS);
        $args  = array_merge(array($since), $buckets);
        $t     = self::visits_table();
        $out   = array();

        // 1) Resumen por nombre (+ un user-agent de muestra: para un mismo
        //    "quién" puede haber varios disfraces, así que se avisa de que es
        //    un ejemplo, no el único).
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT who, MIN(ts) primera, MAX(ts) ultima, COUNT(*) n,
                    COUNT(DISTINCT ip) ips, COUNT(DISTINCT ua) uas, MAX(ua) ua
             FROM $t WHERE ts >= %s AND bucket IN ($ph) AND who <> '' GROUP BY who",
            $args
        ));
        foreach ($rows as $r) {
            $out[$r->who] = array(
                'primera' => $r->primera, 'ultima' => $r->ultima,
                'n' => (int) $r->n, 'ips' => (int) $r->ips, 'uas' => (int) $r->uas,
                'ua' => $r->ua, 'paths' => array(), 'ip_list' => array(),
            );
        }

        // 2) Páginas que se llevó y 3) desde qué IPs. Se ordenan aquí y se
        //    recortan en PHP: el LIMIT por grupo no existe en MySQL sin
        //    ventanas (MariaDB viejo de hosting compartido no las tiene).
        $paths = $wpdb->get_results($wpdb->prepare(
            "SELECT who, path, COUNT(*) c FROM $t
             WHERE ts >= %s AND bucket IN ($ph) AND who <> '' AND path <> ''
             GROUP BY who, path ORDER BY c DESC",
            $args
        ));
        foreach ($paths as $p) {
            if (isset($out[$p->who]) && count($out[$p->who]['paths']) < 5) {
                $out[$p->who]['paths'][] = array('path' => $p->path, 'c' => (int) $p->c);
            }
        }
        $ips = $wpdb->get_results($wpdb->prepare(
            "SELECT who, ip, MAX(rdns) rdns, COUNT(*) c FROM $t
             WHERE ts >= %s AND bucket IN ($ph) AND who <> ''
             GROUP BY who, ip ORDER BY c DESC",
            $args
        ));
        foreach ($ips as $i) {
            if (isset($out[$i->who]) && count($out[$i->who]['ip_list']) < 4) {
                $out[$i->who]['ip_list'][] = array('ip' => $i->ip, 'rdns' => $i->rdns, 'c' => (int) $i->c);
            }
        }
        return $out;
    }

    /** Top de "quiénes" malos en los últimos $days días (para el email). */
    public static function top_offenders($days = 7, $n = 3) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT who, bucket, COUNT(*) c FROM " . self::visits_table() . "
             WHERE bucket IN ('impostor','datacenter','declarado') AND ts >= %s AND who <> ''
             GROUP BY who, bucket ORDER BY c DESC LIMIT %d",
            gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS), $n
        ));
    }
}
