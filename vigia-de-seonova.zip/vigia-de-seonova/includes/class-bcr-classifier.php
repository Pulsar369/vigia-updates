<?php
/**
 * Clasificador de visitas — 5 cajones, todo local, sin llamadas externas.
 *
 *   humano     — UA de navegador, IP sin señal de nada.
 *   bueno      — el UA dice ser un bot conocido Y la IP está en su rango oficial.
 *   impostor   — el UA dice ser un bot conocido pero la IP NO es suya.
 *   datacenter — UA de navegador pero la IP es de un centro de datos.
 *   util       — bot declarado que TE SUMA: anuncios, redes, buscadores o
 *                cualquiera cuya ficha diga que te trae visitas.
 *   declarado  — bot que se identifica honestamente pero no te da nada
 *                (Ahrefs, GPTBot cuando solo entrena, curl…).
 *
 * La verificación es por IP, no por User-Agent: el disfraz se falsifica, el
 * rango oficial no. Misma lógica que usamos en producción para destapar
 * Googlebots falsos.
 */

defined('ABSPATH') || exit;

class BCR_Classifier {

    /** UA que RECLAMA ser un bot verificable → clave del dueño en bcr_good_bot_ranges(). */
    private static $claims = array(
        'google'     => '/googlebot|mediapartners-google|adsbot-google|apis-google|storebot-google|google-inspectiontool|feedfetcher-google|googleother|google-adstxt/i',
        'bing'       => '/bingbot|adidxbot|bingpreview|msnbot/i',
        'apple'      => '/applebot/i',
        'duckduckgo' => '/duckduckbot/i',
        'meta'       => '/facebookexternalhit|meta-externalagent|facebookcatalog|facebot/i',
    );

    /** Bots que se declaran con nombre propio (no se verifican: se les cree). */
    private static $declared_named = array(
        'gptbot' => 'GPTBot (OpenAI)', 'claudebot' => 'ClaudeBot (Anthropic)',
        'anthropic' => 'Anthropic', 'ccbot' => 'CCBot (Common Crawl)',
        'bytespider' => 'Bytespider (TikTok)', 'petalbot' => 'PetalBot (Huawei)',
        'amazonbot' => 'Amazonbot', 'ahrefsbot' => 'AhrefsBot',
        'semrushbot' => 'SemrushBot', 'mj12bot' => 'MJ12bot (Majestic)',
        'dotbot' => 'DotBot (Moz)', 'dataforseo' => 'DataForSEO',
        'serpstatbot' => 'Serpstat', 'blexbot' => 'BLEXBot',
        'yandex' => 'Yandex', 'baiduspider' => 'Baidu',
        'seznambot' => 'Seznam', 'qwantbot' => 'Qwant',
        'uptimerobot' => 'UptimeRobot', 'pingdom' => 'Pingdom',
        'statuscake' => 'StatusCake', 'lighthouse' => 'Lighthouse/PageSpeed',
        'chrome-lighthouse' => 'Lighthouse/PageSpeed',
        // Vistos en el registro real de craigslist.vegas (26-ago-2026).
        'youbot' => 'YouBot (You.com)', 'amzn-searchbot' => 'Amazon SearchBot',
        'peer39' => 'Peer39 (anuncios)', 'proximic' => 'Proximic (Comscore)',
        'hubspot' => 'HubSpot', 'sofyabot' => 'SofyaBot',
        'sogou' => 'Sogou (China)', 'applebot-extended' => 'Applebot-Extended (IA)',
        // WhatsApp no lleva "bot" en el nombre: sin esta linea, sus visitas
        // para montar la tarjeta del enlace se contaban como personas.
        'whatsapp/' => 'WhatsApp',
    );

    /** Herramientas y patrones genéricos de bot. */
    /**
     * Herramientas y patrones genéricos de bot.
     *
     * OJO con el \b de delante: lo tenía y dejaba pasar a todo bot cuyo
     * nombre acaba en "Bot" pegado a otra palabra. "YouBot" y
     * "Amzn-SearchBot" se contaban como PERSONAS porque \bbot\b exige un
     * separador justo antes de "bot", y dentro de una palabra no lo hay.
     * Lo mismo con el guion bajo de "peer39_crawler". Ahora basta con que
     * la palabra TERMINE en bot/crawler/spider/scraper.
     */
    private static $declared_generic = '/(bot|crawler|spider|scraper|crawl)\b|curl\/|wget\/|python-requests|python\/|aiohttp|httpx\/|go-http-client|okhttp|java\/|libwww|node-fetch|axios\/|headlesschrome|phantomjs|scrapy/i';

    /**
     * ¿Este bot declarado te SUMA algo? Se decide con su propia ficha:
     *  - familia "anuncios": sin el no te pagan los anuncios;
     *  - familia "social": monta la tarjeta cuando alguien te comparte;
     *  - familia "buscador": es un buscador de verdad, aunque no publique IPs;
     *  - o su ficha dice que te trae visitas.
     * Todo lo demas (espias SEO, herramientas, IA que solo entrena) sigue
     * contando como basura.
     *
     * Antes iban TODOS al mismo saco rojo, y el panel acababa diciendo dos
     * cosas contrarias: "malo" arriba y "no lo bloquees" en la ficha.
     */
    private static function suma($who, $ua) {
        if (!class_exists('BCR_Fichas') || !function_exists('bcr_fichas')) {
            return false;
        }
        $f = BCR_Fichas::buscar($who, $ua);
        if (!is_array($f)) {
            return false;
        }
        $familia = isset($f['familia']) ? $f['familia'] : '';
        $trae    = isset($f['trae']) ? $f['trae'] : '';
        return in_array($familia, array('anuncios', 'social', 'buscador'), true) || $trae === 'si';
    }

    /** El cajon de un bot declarado: util si suma, declarado si no. */
    private static function cajon_declarado($who, $ua) {
        return self::suma($who, $ua) ? 'util' : 'declarado';
    }

    /**
     * Clasifica una visita.
     *
     * @return array{bucket:string, who:string}
     */
    public static function classify($ip, $ua) {
        $ua = (string) $ua;

        if ($ua === '') {
            return array('bucket' => 'declarado', 'who' => 'sin user-agent');
        }

        // 1) ¿Reclama ser un bot verificable? → verificar por IP.
        $good = bcr_good_bot_ranges();
        foreach (self::$claims as $owner => $regex) {
            if (!isset($good[$owner]) || !preg_match($regex, $ua)) {
                continue;
            }
            // Nombre CONCRETO: AdSense/Mediapartners vs Googlebot vs Bing Ads…
            // (antes todo caía en "Google"/"Bing" y no se distinguía).
            $quien = self::refine_who($ua, $good[$owner]['label']);
            // `owner` (google|bing|...) sale ADEMAS de `who`, para poder separar
            // en la barra que parte del rastreo bueno es de Google y cual de Bing
            // sin volver a mirar el user-agent. Clave nueva y opcional: quien no
            // la lea sigue funcionando igual.
            if (self::ip_in_cidrs($ip, $good[$owner]['cidrs'])) {
                return array('bucket' => 'bueno', 'who' => $quien, 'owner' => $owner);
            }
            return array('bucket' => 'impostor', 'who' => 'falso ' . $quien, 'owner' => $owner);
        }

        // 2) Bots declarados con nombre.
        $lc = strtolower($ua);
        foreach (self::$declared_named as $token => $label) {
            if (strpos($lc, $token) !== false) {
                return array('bucket' => self::cajon_declarado($label, $ua), 'who' => $label);
            }
        }
        if (preg_match(self::$declared_generic, $ua)) {
            $quien = self::short_ua($ua);
            return array('bucket' => self::cajon_declarado($quien, $ua), 'who' => $quien);
        }

        // 3) UA de navegador pero IP de centro de datos → disfrazado.
        foreach (bcr_datacenter_ranges() as $provider => $cidrs) {
            if (self::ip_in_cidrs($ip, $cidrs)) {
                return array('bucket' => 'datacenter', 'who' => $provider);
            }
        }

        // 4) Nada raro a la vista. (El enriquecedor rDNS puede recolocarlo.)
        return array('bucket' => 'humano', 'who' => '');
    }

    /** ¿IP dentro de alguno de los CIDRs? IPv4 e IPv6, vía inet_pton. */
    public static function ip_in_cidrs($ip, $cidrs) {
        $bin = @inet_pton($ip);
        if ($bin === false) {
            return false;
        }
        foreach ((array) $cidrs as $cidr) {
            if (self::cidr_contains($cidr, $ip, $bin)) {
                return true;
            }
        }
        return false;
    }

    /** ¿$ip ∈ $cidr? Acepta IP suelta como /32 (v4) o /128 (v6). */
    public static function cidr_contains($cidr, $ip, $ip_bin = null) {
        if ($ip_bin === null) {
            $ip_bin = @inet_pton($ip);
        }
        if ($ip_bin === false || $ip_bin === null) {
            return false;
        }
        $parts = explode('/', (string) $cidr, 2);
        $base_bin = @inet_pton($parts[0]);
        if ($base_bin === false || strlen($base_bin) !== strlen($ip_bin)) {
            return false; // familia distinta (v4 vs v6) o base inválida
        }
        $max_bits = strlen($ip_bin) * 8;
        $bits = isset($parts[1]) ? (int) $parts[1] : $max_bits;
        if ($bits < 0 || $bits > $max_bits) {
            return false;
        }
        if ($bits === 0) {
            return true;
        }
        $bytes = intdiv($bits, 8);
        $rest  = $bits % 8;
        if ($bytes && substr($ip_bin, 0, $bytes) !== substr($base_bin, 0, $bytes)) {
            return false;
        }
        if ($rest === 0) {
            return true;
        }
        $mask = 0xFF & (0xFF << (8 - $rest));
        return (ord($ip_bin[$bytes]) & $mask) === (ord($base_bin[$bytes]) & $mask);
    }

    /** Token de UA → nombre concreto del crawler. Se comprueba en orden. */
    private static $good_subtypes = array(
        'googleother-image'     => 'GoogleOther Image',
        'googleother'           => 'GoogleOther',
        'mediapartners-google'  => 'AdSense (Mediapartners)',
        'adsbot-google'         => 'AdSense (AdsBot)',
        'storebot-google'       => 'Google StoreBot',
        'google-inspectiontool' => 'Google Inspection',
        'feedfetcher-google'    => 'Google FeedFetcher',
        'apis-google'           => 'Google APIs',
        'googlebot'             => 'Googlebot',
        'adidxbot'              => 'Bing Ads (AdIdxBot)',
        'bingpreview'           => 'Bing Preview',
        'msnbot'                => 'MSNBot (Bing)',
        'bingbot'               => 'Bingbot',
        'applebot'              => 'Applebot',
        'duckduckbot'           => 'DuckDuckBot',
        'meta-externalagent'    => 'Meta AI',
        'facebookcatalog'       => 'Facebook Catalog',
        'facebookexternalhit'   => 'Facebook',
        'facebot'               => 'Facebook',
    );

    /** Devuelve el nombre concreto del bot bueno, o el genérico del dueño. */
    public static function refine_who($ua, $fallback) {
        $lc = strtolower($ua);
        foreach (self::$good_subtypes as $token => $name) {
            if (strpos($lc, $token) !== false) {
                return $name;
            }
        }
        return $fallback;
    }

    /** Nombre corto legible desde un UA de herramienta ("curl/8.4.0" → "curl"). */
    /**
     * Palabras del user-agent que describen el ORDENADOR, no al visitante.
     * Sin esta lista, un bot con user-agent de Mac se llamaba "Intel".
     */
    private static function es_palabra_de_sistema($p) {
        return (bool) preg_match(
            '/^(windows|macintosh|mac|intel|ppc|x11|linux|ubuntu|debian|fedora|cros|android|iphone|ipad|ipod|'
            . 'khtml|gecko|applewebkit|webkit|presto|trident|edge|edga|edgios|version|mobile|safari|chrome|'
            . 'chromium|firefox|opr|opera|crios|fxios|wow64|win64|x64|arm|arm64|nt|os|rv|like|u|en-us|es-es)$/i',
            $p
        );
    }

    private static function short_ua($ua) {
        $ua = trim($ua);
        // "Mozilla/5.0 (compatible; LoQueSea/1.0; +http://...)" -> "LoQueSea".
        // Sin esto, TODO bot que se disfraza de navegador salía en el panel
        // llamándose "Mozilla" (le pasaba a GoogleOther): el nombre de verdad
        // va DENTRO del paréntesis, no al principio.
        if (stripos($ua, 'mozilla/') === 0 && preg_match_all('/\(([^)]*)\)/', $ua, $pars)) {
            // TODOS los parentesis, no solo el primero: el del sistema
            // ("Macintosh; Intel Mac OS X") va antes que el del bot.
            foreach ($pars[1] as $dentro) {
                foreach (explode(';', $dentro) as $trozo) {
                    $trozo = trim($trozo);
                    if ($trozo === '' || stripos($trozo, 'compatible') === 0 || $trozo[0] === '+') {
                        continue;
                    }
                    if (preg_match('/^([a-z0-9_.-]+)/i', $trozo, $m) && !self::es_palabra_de_sistema($m[1])) {
                        return $m[1];
                    }
                }
            }
        }
        // El nombre puede ir al final, fuera de todo parentesis:
        // "...Safari/537.36; compatible; OAI-SearchBot/1.4; +https://...".
        // Se coge el ULTIMO "Algo/1.2" que no sea del navegador.
        if (preg_match_all('/([a-z0-9_.-]+)\/[0-9]/i', $ua, $todos)) {
            for ($i = count($todos[1]) - 1; $i >= 0; $i--) {
                if (!self::es_palabra_de_sistema($todos[1][$i])) {
                    return $todos[1][$i];
                }
            }
        }
        if (preg_match('/^([a-z0-9_.-]+)\//i', $ua, $m)) {
            return $m[1];
        }
        return mb_substr($ua, 0, 40);
    }
}
