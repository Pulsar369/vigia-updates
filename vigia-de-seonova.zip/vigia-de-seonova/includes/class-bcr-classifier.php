<?php
/**
 * Clasificador de visitas — 5 cajones, todo local, sin llamadas externas.
 *
 *   humano     — UA de navegador, IP sin señal de nada.
 *   bueno      — el UA dice ser un bot conocido Y la IP está en su rango oficial.
 *   impostor   — el UA dice ser un bot conocido pero la IP NO es suya.
 *   datacenter — UA de navegador pero la IP es de un centro de datos.
 *   declarado  — bot que se identifica honestamente (GPTBot, Ahrefs, curl…).
 *
 * La verificación es por IP, no por User-Agent: el disfraz se falsifica, el
 * rango oficial no. Misma lógica que usamos en producción para destapar
 * Googlebots falsos.
 */

defined('ABSPATH') || exit;

class BCR_Classifier {

    /** UA que RECLAMA ser un bot verificable → clave del dueño en bcr_good_bot_ranges(). */
    private static $claims = array(
        'google'     => '/googlebot|mediapartners-google|adsbot-google|apis-google|storebot-google|google-inspectiontool|feedfetcher-google|googleother/i',
        'bing'       => '/bingbot|adidxbot|bingpreview|msnbot/i',
        'apple'      => '/applebot/i',
        'duckduckgo' => '/duckduckbot/i',
        'meta'       => '/facebookexternalhit|meta-externalagent|facebookcatalog|facebot/i',
    );

    /** Bots que se declaran con nombre propio (no se verifican: se les cree). */
    private static $declared_named = array(
        'gptbot' => 'GPTBot (OpenAI)', 'claudebot' => 'ClaudeBot (Anthropic)',
        'anthropic' => 'Anthropic', 'ccbot' => 'CCBot (Common Crawl)',
        'bytespider' => 'Bytespider (TikTok)', 'petalbot' => 'PetalBot (Huawei)',
        'amazonbot' => 'Amazonbot', 'ahrefsbot' => 'AhrefsBot',
        'semrushbot' => 'SemrushBot', 'mj12bot' => 'MJ12bot (Majestic)',
        'dotbot' => 'DotBot (Moz)', 'dataforseo' => 'DataForSEO',
        'serpstatbot' => 'Serpstat', 'blexbot' => 'BLEXBot',
        'yandex' => 'Yandex', 'baiduspider' => 'Baidu',
        'seznambot' => 'Seznam', 'qwantbot' => 'Qwant',
        'uptimerobot' => 'UptimeRobot', 'pingdom' => 'Pingdom',
        'statuscake' => 'StatusCake', 'lighthouse' => 'Lighthouse/PageSpeed',
        'chrome-lighthouse' => 'Lighthouse/PageSpeed',
        // Vistos en el registro real de craigslist.vegas (26-ago-2026).
        'youbot' => 'YouBot (You.com)', 'amzn-searchbot' => 'Amazon SearchBot',
        'peer39' => 'Peer39 (anuncios)', 'proximic' => 'Proximic (Comscore)',
        'hubspot' => 'HubSpot', 'sofyabot' => 'SofyaBot',
        'sogou' => 'Sogou (China)', 'applebot-extended' => 'Applebot-Extended (IA)',
    );

    /** Herramientas y patrones genéricos de bot. */
    /**
     * Herramientas y patrones genéricos de bot.
     *
     * OJO con el \b de delante: lo tenía y dejaba pasar a todo bot cuyo
     * nombre acaba en "Bot" pegado a otra palabra. "YouBot" y
     * "Amzn-SearchBot" se contaban como PERSONAS porque \bbot\b exige un
     * separador justo antes de "bot", y dentro de una palabra no lo hay.
     * Lo mismo con el guion bajo de "peer39_crawler". Ahora basta con que
     * la palabra TERMINE en bot/crawler/spider/scraper.
     */
    private static $declared_generic = '/(bot|crawler|spider|scraper|crawl)\b|curl\/|wget\/|python-requests|python\/|aiohttp|httpx\/|go-http-client|okhttp|java\/|libwww|node-fetch|axios\/|headlesschrome|phantomjs|scrapy/i';

    /**
     * Clasifica una visita.
     *
     * @return array{bucket:string, who:string}
     */
    public static function classify($ip, $ua) {
        $ua = (string) $ua;

        if ($ua === '') {
            return array('bucket' => 'declarado', 'who' => 'sin user-agent');
        }

        // 1) ¿Reclama ser un bot verificable? → verificar por IP.
        $good = bcr_good_bot_ranges();
        foreach (self::$claims as $owner => $regex) {
            if (!isset($good[$owner]) || !preg_match($regex, $ua)) {
                continue;
            }
            // Nombre CONCRETO: AdSense/Mediapartners vs Googlebot vs Bing Ads…
            // (antes todo caía en "Google"/"Bing" y no se distinguía).
            $quien = self::refine_who($ua, $good[$owner]['label']);
            if (self::ip_in_cidrs($ip, $good[$owner]['cidrs'])) {
                return array('bucket' => 'bueno', 'who' => $quien);
            }
            return array('bucket' => 'impostor', 'who' => 'falso ' . $quien);
        }

        // 2) Bots declarados con nombre.
        $lc = strtolower($ua);
        foreach (self::$declared_named as $token => $label) {
            if (strpos($lc, $token) !== false) {
                return array('bucket' => 'declarado', 'who' => $label);
            }
        }
        if (preg_match(self::$declared_generic, $ua)) {
            return array('bucket' => 'declarado', 'who' => self::short_ua($ua));
        }

        // 3) UA de navegador pero IP de centro de datos → disfrazado.
        foreach (bcr_datacenter_ranges() as $provider => $cidrs) {
            if (self::ip_in_cidrs($ip, $cidrs)) {
                return array('bucket' => 'datacenter', 'who' => $provider);
            }
        }

        // 4) Nada raro a la vista. (El enriquecedor rDNS puede recolocarlo.)
        return array('bucket' => 'humano', 'who' => '');
    }

    /** ¿IP dentro de alguno de los CIDRs? IPv4 e IPv6, vía inet_pton. */
    public static function ip_in_cidrs($ip, $cidrs) {
        $bin = @inet_pton($ip);
        if ($bin === false) {
            return false;
        }
        foreach ((array) $cidrs as $cidr) {
            if (self::cidr_contains($cidr, $ip, $bin)) {
                return true;
            }
        }
        return false;
    }

    /** ¿$ip ∈ $cidr? Acepta IP suelta como /32 (v4) o /128 (v6). */
    public static function cidr_contains($cidr, $ip, $ip_bin = null) {
        if ($ip_bin === null) {
            $ip_bin = @inet_pton($ip);
        }
        if ($ip_bin === false || $ip_bin === null) {
            return false;
        }
        $parts = explode('/', (string) $cidr, 2);
        $base_bin = @inet_pton($parts[0]);
        if ($base_bin === false || strlen($base_bin) !== strlen($ip_bin)) {
            return false; // familia distinta (v4 vs v6) o base inválida
        }
        $max_bits = strlen($ip_bin) * 8;
        $bits = isset($parts[1]) ? (int) $parts[1] : $max_bits;
        if ($bits < 0 || $bits > $max_bits) {
            return false;
        }
        if ($bits === 0) {
            return true;
        }
        $bytes = intdiv($bits, 8);
        $rest  = $bits % 8;
        if ($bytes && substr($ip_bin, 0, $bytes) !== substr($base_bin, 0, $bytes)) {
            return false;
        }
        if ($rest === 0) {
            return true;
        }
        $mask = 0xFF & (0xFF << (8 - $rest));
        return (ord($ip_bin[$bytes]) & $mask) === (ord($base_bin[$bytes]) & $mask);
    }

    /** Token de UA → nombre concreto del crawler. Se comprueba en orden. */
    private static $good_subtypes = array(
        'googleother-image'     => 'GoogleOther Image',
        'googleother'           => 'GoogleOther',
        'mediapartners-google'  => 'AdSense (Mediapartners)',
        'adsbot-google'         => 'AdSense (AdsBot)',
        'storebot-google'       => 'Google StoreBot',
        'google-inspectiontool' => 'Google Inspection',
        'feedfetcher-google'    => 'Google FeedFetcher',
        'apis-google'           => 'Google APIs',
        'googlebot'             => 'Googlebot',
        'adidxbot'              => 'Bing Ads (AdIdxBot)',
        'bingpreview'           => 'Bing Preview',
        'msnbot'                => 'MSNBot (Bing)',
        'bingbot'               => 'Bingbot',
        'applebot'              => 'Applebot',
        'duckduckbot'           => 'DuckDuckBot',
        'meta-externalagent'    => 'Meta AI',
        'facebookcatalog'       => 'Facebook Catalog',
        'facebookexternalhit'   => 'Facebook',
        'facebot'               => 'Facebook',
    );

    /** Devuelve el nombre concreto del bot bueno, o el genérico del dueño. */
    public static function refine_who($ua, $fallback) {
        $lc = strtolower($ua);
        foreach (self::$good_subtypes as $token => $name) {
            if (strpos($lc, $token) !== false) {
                return $name;
            }
        }
        return $fallback;
    }

    /** Nombre corto legible desde un UA de herramienta ("curl/8.4.0" → "curl"). */
    private static function short_ua($ua) {
        $ua = trim($ua);
        // "Mozilla/5.0 (compatible; LoQueSea/1.0; +http://...)" -> "LoQueSea".
        // Sin esto, TODO bot que se disfraza de navegador salía en el panel
        // llamándose "Mozilla" (le pasaba a GoogleOther): el nombre de verdad
        // va DENTRO del paréntesis, no al principio.
        if (stripos($ua, 'mozilla/') === 0 && preg_match('/\(([^)]*)\)/', $ua, $par)) {
            foreach (explode(';', $par[1]) as $trozo) {
                $trozo = trim($trozo);
                if ($trozo === '' || stripos($trozo, 'compatible') === 0 || $trozo[0] === '+') {
                    continue;
                }
                if (preg_match('/^([a-z0-9_.-]+)/i', $trozo, $m)
                    && !preg_match('/^(windows|macintosh|x11|linux|android|iphone|ipad|khtml|like|u|en-us)$/i', $m[1])) {
                    return $m[1];
                }
            }
        }
        if (preg_match('/^([a-z0-9_.-]+)\//i', $ua, $m)) {
            return $m[1];
        }
        return mb_substr($ua, 0, 40);
    }
}
