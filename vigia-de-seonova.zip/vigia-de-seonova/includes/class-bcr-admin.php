<?php
/**
 * Panel de admin — 1 pantalla: tarjetas (con el RPM DENTRO de la tarjeta del
 * dinero, al lado de donde se ve su efecto), veredicto sin IA, desglose,
 * gráfico 30 días, tabla paginada de últimas visitas y CTA al toolkit.
 *
 * Tema noche/día por variables CSS. Strings en inglés (base); es_* en /languages.
 */

defined('ABSPATH') || exit;

class BCR_Admin {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
        add_action('admin_init', array(__CLASS__, 'handle_lang_switch'));
        add_action('admin_post_bcr_feedback', array(__CLASS__, 'handle_feedback'));
        add_action('admin_init', array(__CLASS__, 'handle_review_dismiss'));
        add_action('admin_notices', array(__CLASS__, 'review_notice'));
    }

    /** Idioma efectivo del panel: 'es' | 'en'. */
    private static function panel_lang() {
        $p = self::lang_pref();
        if ($p !== '') {
            return $p;
        }
        return strpos(get_locale(), 'es_') === 0 ? 'es' : 'en';
    }

    /** Idioma elegido a mano para el panel: 'es' | 'en' | '' (auto = manda WP). */
    private static function lang_pref() {
        $p = get_user_meta(get_current_user_id(), 'bcr_lang', true);
        return ($p === 'es' || $p === 'en') ? $p : '';
    }

    /** Guarda la elección de idioma y recarga. Se recuerda POR USUARIO (user_meta),
     *  igual que el modo noche/día — pero server-side porque las traducciones son
     *  del servidor (PHP/gettext), no del navegador. */
    public static function handle_lang_switch() {
        if (!isset($_GET['bcr_lang']) || !current_user_can('manage_options')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_lang')) {
            return;
        }
        $raw = sanitize_key($_GET['bcr_lang']);
        $val = ($raw === 'es' || $raw === 'en') ? $raw : '';
        update_user_meta(get_current_user_id(), 'bcr_lang', $val);
        wp_safe_redirect(remove_query_arg(array('bcr_lang', '_wpnonce')));
        exit;
    }

    /** URL con nonce para fijar un idioma. */
    private static function lang_url($lang) {
        return wp_nonce_url(add_query_arg('bcr_lang', $lang), 'bcr_lang');
    }

    public static function menu() {
        add_menu_page(
            __('VigIA de SeoNova', 'vigia-de-seonova'),
            __('VigIA', 'vigia-de-seonova'),
            'manage_options',
            'vigia-de-seonova',
            array(__CLASS__, 'render'),
            'dashicons-shield-alt',
            58
        );
    }

    public static function settings() {
        // Grupos SEPARADOS: el mini-form del RPM (en la tarjeta del dinero) no
        // puede compartir grupo con el email — options.php machaca a null todo
        // campo del grupo que no viaje en el POST.
        register_setting('bcr_money', 'bcr_rpm', array(
            'type' => 'number', 'sanitize_callback' => array(__CLASS__, 'san_rpm'), 'default' => 0,
        ));
        register_setting('bcr_report', 'bcr_report_enabled', array(
            'type' => 'string', 'sanitize_callback' => array(__CLASS__, 'san_bool'), 'default' => '1',
        ));
        register_setting('bcr_report', 'bcr_report_email', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_email', 'default' => '',
        ));
        // Telemetría anónima OPT-IN (apagada por defecto): solo agregados, sin
        // dominio ni IPs. Viaja con el cron semanal.
        register_setting('bcr_report', 'bcr_telemetry', array(
            'type' => 'string', 'sanitize_callback' => array(__CLASS__, 'san_bool'), 'default' => '',
        ));
    }

    public static function san_rpm($v) {
        $v = (float) str_replace(',', '.', (string) $v);
        return ($v >= 0 && $v < 1000) ? $v : 0;
    }

    public static function san_bool($v) {
        return $v === '1' ? '1' : '0';
    }

    /** Tamaño de página de la tabla: lo elige el usuario y se le recuerda. */
    private static function per_page() {
        $allowed = array(10, 25, 50, 100);
        $uid = get_current_user_id();
        if (isset($_GET['bcr_pp'])) {
            $pp = (int) $_GET['bcr_pp'];
            if (in_array($pp, $allowed, true)) {
                update_user_meta($uid, 'bcr_per_page', $pp);
                return $pp;
            }
        }
        $saved = (int) get_user_meta($uid, 'bcr_per_page', true);
        return in_array($saved, $allowed, true) ? $saved : 25;
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        // Belt-and-suspenders: además del filtro plugin_locale (que actúa al
        // cargar el textdomain), forzamos AQUÍ el .mo exacto justo antes de
        // pintar. Así el idioma elegido se aplica sí o sí, sin depender del
        // momento de carga ni de la caché de traducciones de WP.
        $bcr_pref = self::lang_pref();
        $bcr_mo_ok = false;
        if ($bcr_pref !== '') {
            $bcr_want = $bcr_pref === 'es' ? 'es_ES' : 'en_US';
            unload_textdomain('vigia-de-seonova');
            $bcr_mo = BCR_DIR . 'languages/vigia-de-seonova-' . $bcr_want . '.mo';
            if (is_readable($bcr_mo)) {
                $bcr_mo_ok = load_textdomain('vigia-de-seonova', $bcr_mo);
            }
        }
        $t7  = BCR_Store::totals(7);
        $bad7 = $t7['impostor'] + $t7['datacenter'] + $t7['declarado'];
        $pct7 = $t7['total'] > 0 ? round($bad7 / $t7['total'] * 100) : 0;
        $cost = BCR_Store::monthly_cost();
        $rpm  = (float) get_option('bcr_rpm', 0);
        ?>
        <div class="wrap">
        <div class="bcr-root" id="bcr-root">
            <div class="bcr-head">
                <h1><?php esc_html_e('VigIA de SeoNova', 'vigia-de-seonova'); ?>
                    <span class="bcr-sub"><?php esc_html_e('who visits you and what it costs', 'vigia-de-seonova'); ?></span></h1>
                <div class="bcr-head-tools">
                    <?php $lp = self::lang_pref(); ?>
                    <span class="bcr-lang" title="<?php esc_attr_e('Panel language', 'vigia-de-seonova'); ?>">
                        <a class="<?php echo $lp === 'es' ? 'on' : ''; ?>" href="<?php echo esc_url(self::lang_url('es')); ?>">ES</a>
                        <a class="<?php echo $lp === 'en' ? 'on' : ''; ?>" href="<?php echo esc_url(self::lang_url('en')); ?>">EN</a>
                    </span>
                    <button type="button" class="bcr-theme-toggle" id="bcr-theme-toggle"
                            title="<?php esc_attr_e('Light / dark mode', 'vigia-de-seonova'); ?>">🌙</button>
                </div>
            </div>

            <?php $bcr_cache_aviso = BCR_Cache::aviso(); ?>
            <?php $bcr_escudo_aviso = BCR_Cache::aviso_escudo(); ?>
            <?php
            // Se apunta el escudo para el informe semanal: el cron sale del
            // propio servidor, ahí NO llegan las cabeceras de Cloudflare.
            $bcr_escudo = BCR_Cache::escudo();
            if ($bcr_escudo !== (string) get_option('bcr_escudo', '')) {
                update_option('bcr_escudo', $bcr_escudo, false);
            }
            ?>
            <?php if ($bcr_cache_aviso) : ?>
                <p class="bcr-nota-cache"><span class="dashicons dashicons-info-outline"></span> <?php echo esc_html($bcr_cache_aviso); ?></p>
            <?php endif; ?>
            <?php if ($bcr_escudo_aviso) : ?>
                <p class="bcr-nota-cache bcr-nota-escudo"><span class="dashicons dashicons-shield-alt"></span> <?php echo esc_html($bcr_escudo_aviso); ?></p>
            <?php endif; ?>

            <div class="bcr-cards">
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html(number_format_i18n($t7['total'])); ?></div>
                    <div><?php esc_html_e('visits in the last 7 days', 'vigia-de-seonova'); ?></div>
                </div>
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html($pct7); ?>%</div>
                    <div><?php esc_html_e('were bots', 'vigia-de-seonova'); ?></div>
                </div>
                <div class="bcr-card bcr-card-money">
                    <?php if ($cost !== null) : ?>
                        <div class="bcr-big">~$<?php echo esc_html(number_format_i18n($cost, 2)); ?></div>
                        <div><?php esc_html_e('per month of junk traffic polluting your ads (estimate from your RPM)', 'vigia-de-seonova'); ?></div>
                    <?php else : ?>
                        <div class="bcr-big">$?</div>
                        <div><?php esc_html_e('enter your RPM here to see what bots cost you', 'vigia-de-seonova'); ?></div>
                    <?php endif; ?>
                    <?php /* El ajuste vive AL LADO de su efecto — pedido del usuario: al llegar
                             abajo del listado ya no se acordaba de para qué era el campo. */ ?>
                    <form method="post" action="options.php" class="bcr-rpm-form">
                        <?php settings_fields('bcr_money'); ?>
                        <label for="bcr_rpm"><?php esc_html_e('Your AdSense RPM ($)', 'vigia-de-seonova'); ?></label>
                        <input name="bcr_rpm" id="bcr_rpm" type="number" step="0.01" min="0"
                               value="<?php echo esc_attr($rpm ?: ''); ?>" />
                        <button class="button button-small"><?php esc_html_e('Save', 'vigia-de-seonova'); ?></button>
                        <span class="bcr-muted"><?php esc_html_e('What you earn per 1,000 pageviews (your AdSense panel shows it). With this, the radar estimates how much money bots are polluting.', 'vigia-de-seonova'); ?></span>
                    </form>
                </div>
                <div class="bcr-card bcr-card-cta">
                    <a class="button button-primary button-hero" href="<?php echo esc_url(bcr_cta_url(self::panel_lang())); ?>" target="_blank" rel="noopener">
                        <?php esc_html_e('Stop them with WPO Toolkit →', 'vigia-de-seonova'); ?>
                    </a>
                    <div class="bcr-muted"><?php esc_html_e('This radar only watches. Blocking them is the toolkit\'s job.', 'vigia-de-seonova'); ?></div>
                </div>
            </div>

            <?php self::verdict_card(); ?>

            <h2><?php esc_html_e('Breakdown, last 7 days', 'vigia-de-seonova'); ?></h2>
            <div class="bcr-buckets">
                <?php
                $defs = array(
                    'humano'     => array('🟢', __('Humans', 'vigia-de-seonova')),
                    'bueno'      => array('🔵', __('Verified good bots (real Google/Bing)', 'vigia-de-seonova')),
                    'impostor'   => array('🔴', __('IMPOSTORS (claim to be Google/Bing and are not)', 'vigia-de-seonova')),
                    'datacenter' => array('🟠', __('Data centers disguised as people', 'vigia-de-seonova')),
                    'declarado'  => array('⚪', __('Declared bots (AI, SEO, tools)', 'vigia-de-seonova')),
                );
                foreach ($defs as $key => $def) : ?>
                    <div class="bcr-bucket">
                        <span><?php echo esc_html($def[0]); ?></span>
                        <strong><?php echo esc_html(number_format_i18n($t7[$key])); ?></strong>
                        <span><?php echo esc_html($def[1]); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <h2><?php esc_html_e('Who has visited (last 7 days)', 'vigia-de-seonova'); ?></h2>
            <?php self::who_tables(); ?>

            <h2><?php printf(esc_html__('Last %d days — humans vs bots', 'vigia-de-seonova'), (int) BCR_Store::dias_con_datos()); ?></h2>
            <?php self::chart(); ?>

            <h2><?php esc_html_e('Latest visits', 'vigia-de-seonova'); ?></h2>
            <?php self::visits_table(); ?>

            <h2><?php esc_html_e('Weekly email report', 'vigia-de-seonova'); ?></h2>
            <form method="post" action="options.php" class="bcr-settings">
                <?php settings_fields('bcr_report'); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Weekly email report', 'vigia-de-seonova'); ?></th>
                        <td><label><input name="bcr_report_enabled" type="checkbox" value="1" <?php checked(get_option('bcr_report_enabled', '1'), '1'); ?> />
                            <?php esc_html_e('Email me every Monday what the bots cost', 'vigia-de-seonova'); ?></label><br><br>
                            <input name="bcr_report_email" type="email" value="<?php echo esc_attr(get_option('bcr_report_email', get_option('admin_email'))); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Anonymous stats', 'vigia-de-seonova'); ?></th>
                        <td><label><input name="bcr_telemetry" type="checkbox" value="1" <?php checked(get_option('bcr_telemetry', ''), '1'); ?> />
                            <?php esc_html_e('Help improve VigIA: share anonymous weekly aggregates (verdict level, bot percentages — never your domain, IPs or visitors).', 'vigia-de-seonova'); ?></label></td>
                    </tr>
                </table>
                <?php submit_button(__('Save', 'vigia-de-seonova')); ?>
            </form>

            <?php // Fuera del formulario de ajustes: este va a admin-post, no a options.php. ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="bcr-prueba">
                <?php wp_nonce_field('bcr_prueba'); ?>
                <input type="hidden" name="action" value="bcr_prueba" />
                <button class="button"><?php esc_html_e('Send me a test report now', 'vigia-de-seonova'); ?></button>
                <span class="description"><?php esc_html_e('It sends the Monday email to that address with what your site has right now. Save first if you changed it.', 'vigia-de-seonova'); ?></span>
            </form>

            <?php self::feedback_form(); ?>
        </div>
        </div>
        <style><?php echo self::css(); ?></style>
        <script><?php echo self::theme_js(); ?></script>
        <?php
    }

    /** Veredicto sin IA: umbrales fijos y auditables sobre lo medido. */
    private static function verdict_card() {
        $v = BCR_Store::verdict();
        $need_d = (int) BCR_Store::VERDICT_MIN_DAYS;
        $need_t = (int) BCR_Store::VERDICT_MIN_TOTAL;
        $pct_d  = $need_d ? min(100, (int) round(min((int) $v['days'], $need_d) / $need_d * 100)) : 100;
        $pct_t  = $need_t ? min(100, (int) round(min((int) $v['total'], $need_t) / $need_t * 100)) : 100;
        $pct_all = min($pct_d, $pct_t); // hacen falta LAS DOS metas
        // 'ready' = firme. 'provisional' = ya se puede opinar (3 días y 200
        // visitas) pero se enseña con su etiqueta y sus barras. 'gathering' =
        // todavía no hay para opinar, salvo que el impaciente pulse 'verlo ya'.
        $gathering = ($v['state'] !== 'ready');
        $peek = !empty($_GET['bcr_peek']); // el impaciente pidió verlo ya
        $mostrar_veredicto = ($v['state'] !== 'gathering') || $peek;

        $titles = array(
            1 => __('WPO Toolkit alone is enough', 'vigia-de-seonova'),
            2 => __('WPO Toolkit + free Cloudflare', 'vigia-de-seonova'),
            3 => __('WPO Toolkit + Cloudflare Pro', 'vigia-de-seonova'),
        );
        // Escritos para gente que no sabe qué es Cloudflare ni "el borde":
        // cada nivel explica QUÉ es la pieza que recomienda y POR QUÉ.
        $explains = array(
            1 => __('Low bot pressure: only %1$s%% are bad bots (~%2$s harmful visits/day). Blocking them from inside your own WordPress — exactly what WPO Toolkit does — is plenty. No need to pay for anything extra. If you want a bonus anyway, you can put Cloudflare in front (a free shield that filters visitors on its own network): not needed for bots at this level, but it makes your site load faster.', 'vigia-de-seonova'),
            2 => __('Moderate pressure: %1$s%% are bad bots (~%2$s harmful visits/day). Worth stopping them BEFORE they reach your hosting, and that is what Cloudflare is for. Cloudflare is a free shield that sits IN FRONT of your website: it filters bad visitors on its own network, so your server never even sees them — and your site loads faster too. WPO Toolkit sets it up and decides who gets blocked.', 'vigia-de-seonova'),
            3 => __('Heavy pressure: %1$s%% are bad bots (~%2$s harmful visits/day) — swarm level. Here the free shield falls short: you need Cloudflare Pro, the paid tier (about $20/month), with more muscle to withstand big waves and stronger rules. WPO Toolkit drives it all for you, on top of your WordPress.', 'vigia-de-seonova'),
        );
        $lvl = (int) $v['level'];

        // Firme, provisional, o el usuario pulsó "verlo ya" → se enseña.
        if ($mostrar_veredicto) {
            // Color SIEMPRE según el nivel (verde/ámbar/rojo); en preliminar se
            // añade el borde discontinuo + etiqueta ámbar para avisar.
            $klass = 'bcr-v' . $lvl . ($gathering ? ' bcr-preview' : '');
            ?>
            <div class="bcr-verdict <?php echo esc_attr($klass); ?>">
                <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-seonova'); ?>
                    <span class="bcr-verdict-title"><?php echo esc_html($titles[$lvl]); ?></span></h2>
                <?php if ($gathering) : ?>
                    <p class="bcr-preview-tag"><?php printf(
                        esc_html__('Preliminary — for a solid read we recommend %1$d days with traffic and %2$s visits. So far: %3$d days, %4$s visits.', 'vigia-de-seonova'),
                        $need_d, esc_html(number_format_i18n($need_t)),
                        (int) $v['days'], esc_html(number_format_i18n((int) $v['total']))
                    ); ?></p>
                <?php endif; ?>
                <p><?php printf(esc_html($explains[$lvl]),
                    esc_html(number_format_i18n($v['bad_pct'], 1)), esc_html(number_format_i18n($v['hostile_day'], 1))); ?></p>
                <?php
                // La guía en el idioma del panel: elección manual manda; sin
                // elección, el idioma del sitio decide.
                $bcr_es = self::lang_pref() === 'es'
                    || (self::lang_pref() === '' && strpos(get_locale(), 'es_') === 0);
                ?>
                <p><a href="<?php echo esc_url($bcr_es ? BCR_LEARN_CF_URL_ES : BCR_LEARN_CF_URL_EN); ?>" target="_blank" rel="noopener">
                    <?php esc_html_e('What Cloudflare can do for your site — plain guide (free vs Pro) →', 'vigia-de-seonova'); ?></a></p>
                <?php if ($gathering) : ?>
                    <?php self::verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t); ?>
                    <?php if ($peek && $v['state'] === 'gathering') : ?>
                        <p><a href="<?php echo esc_url(remove_query_arg('bcr_peek')); ?>"><?php esc_html_e('Hide it until there is enough data', 'vigia-de-seonova'); ?></a></p>
                    <?php endif; ?>
                <?php else : ?>
                    <p class="bcr-muted"><?php printf(
                        esc_html__('Based on the last %d days measured by this radar. No AI involved: fixed thresholds you can audit.', 'vigia-de-seonova'),
                        30
                    ); ?></p>
                <?php endif; ?>
            </div>
            <?php
            return;
        }

        // Reuniendo datos, sin "verlo ya": barras que se llenan + botón para impacientes.
        ?>
        <div class="bcr-verdict bcr-v0">
            <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-seonova'); ?>
                <span class="bcr-verdict-title"><?php printf(esc_html__('%d%% ready', 'vigia-de-seonova'), (int) $pct_all); ?></span></h2>
            <p><?php esc_html_e('Gathering data before giving a verdict — it needs a bit of history so the advice is solid, not a guess.', 'vigia-de-seonova'); ?></p>
            <?php self::verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t); ?>
            <p><a class="button button-secondary" href="<?php echo esc_url(add_query_arg('bcr_peek', '1')); ?>"><?php esc_html_e('Show me the verdict now anyway', 'vigia-de-seonova'); ?></a></p>
        </div>
        <?php
    }

    /** Barras que se van llenando hacia las metas (días con tráfico + visitas). */
    private static function verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t) {
        ?>
        <div class="bcr-progress">
            <div class="bcr-progress-row">
                <span class="bcr-progress-label"><?php esc_html_e('Days with traffic', 'vigia-de-seonova'); ?></span>
                <span class="bcr-progress-track"><span class="bcr-progress-fill<?php echo $pct_d >= 100 ? ' done' : ''; ?>" style="width:<?php echo (int) $pct_d; ?>%"></span></span>
                <span class="bcr-progress-num"><?php echo (int) $v['days']; ?>/<?php echo (int) $need_d; ?></span>
            </div>
            <div class="bcr-progress-row">
                <span class="bcr-progress-label"><?php esc_html_e('Visits', 'vigia-de-seonova'); ?></span>
                <span class="bcr-progress-track"><span class="bcr-progress-fill<?php echo $pct_t >= 100 ? ' done' : ''; ?>" style="width:<?php echo (int) $pct_t; ?>%"></span></span>
                <span class="bcr-progress-num"><?php echo esc_html(number_format_i18n((int) $v['total'])); ?>/<?php echo esc_html(number_format_i18n($need_t)); ?></span>
            </div>
        </div>
        <?php
    }

    /** Tabla de últimas visitas, paginada y con tamaño a elegir (se recuerda). */
    /**
     * Tres colores y no más: verde = persona, azul = bot bueno de verdad,
     * rojo = malo. "Declarado" y "centro de datos" van en rojo porque el
     * panel entero los cuenta como bots que se comen tus páginas; el matiz
     * exacto lo da el texto de la etiqueta, no el color.
     */
    private static function color_de($bucket) {
        if ($bucket === 'humano') {
            return 'humano';
        }
        if ($bucket === 'bueno') {
            return 'bueno';
        }
        return 'malo';
    }
    private static function visits_table() {
        $pp = self::per_page();
        $total = BCR_Store::count_visits();
        $pages = max(1, (int) ceil($total / $pp));
        $pg = isset($_GET['bcr_pg']) ? max(1, min($pages, (int) $_GET['bcr_pg'])) : 1;
        $base = remove_query_arg(array('bcr_pg', 'bcr_pp'));
        ?>
        <div class="bcr-tablebar">
            <span><?php printf(esc_html__('%1$s recorded visits (the last %2$s are kept in detail)', 'vigia-de-seonova'), esc_html(number_format_i18n($total)), esc_html(number_format_i18n(BCR_Store::MAX_VISITS))); ?></span>
            <span class="bcr-pp">
                <?php esc_html_e('Show per page:', 'vigia-de-seonova'); ?>
                <?php foreach (array(10, 25, 50, 100) as $opt) : ?>
                    <?php if ($opt === $pp) : ?><strong><?php echo (int) $opt; ?></strong>
                    <?php else : ?><a href="<?php echo esc_url(add_query_arg(array('bcr_pp' => $opt, 'bcr_pg' => 1), $base)); ?>"><?php echo (int) $opt; ?></a><?php endif; ?>
                <?php endforeach; ?>
            </span>
            <span class="bcr-export">
                <a class="button button-small" href="<?php echo esc_url(BCR_Export::url('visitas')); ?>">
                    <?php esc_html_e('Download these visits (CSV)', 'vigia-de-seonova'); ?></a>
                <a class="button button-small" href="<?php echo esc_url(BCR_Export::url('dias')); ?>">
                    <?php esc_html_e('Download day by day (CSV)', 'vigia-de-seonova'); ?></a>
            </span>
        </div>
        <table class="bcr-table">
            <thead><tr>
                <th><?php esc_html_e('When', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('IP', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('What it is', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('Who', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('Page', 'vigia-de-seonova'); ?></th>
            </tr></thead>
            <tbody>
            <?php foreach (BCR_Store::last_visits($pp, ($pg - 1) * $pp) as $v) : ?>
                <tr>
                    <td><?php echo esc_html(mysql2date('d M H:i', $v->ts)); ?></td>
                    <td><code><?php echo esc_html($v->ip); ?></code></td>
                    <td><span class="bcr-pill bcr-p-<?php echo esc_attr(self::color_de($v->bucket)); ?>"><?php echo esc_html(BCR_Report::bucket_label($v->bucket)); ?></span></td>
                    <td><?php echo esc_html($v->who !== '' ? $v->who : '—'); ?>
                        <?php if ($v->rdns && $v->rdns !== '-') : ?><br><small><?php echo esc_html($v->rdns); ?></small><?php endif; ?></td>
                    <td><code><?php echo esc_html($v->path); ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1) : ?>
        <div class="bcr-pag">
            <?php if ($pg > 1) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg - 1), $base)); ?>">‹ <?php esc_html_e('Previous', 'vigia-de-seonova'); ?></a>
            <?php endif; ?>
            <span><?php printf(esc_html__('Page %1$d of %2$d', 'vigia-de-seonova'), (int) $pg, (int) $pages); ?></span>
            <?php if ($pg < $pages) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg + 1), $base)); ?>"><?php esc_html_e('Next', 'vigia-de-seonova'); ?> ›</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php
    }

    /** Dos listas: qué bots BUENOS han pasado y qué bots MALOS (con su tipo). */
    /**
     * Desplegable "¿Quieres dejarnos tu duda u opinión?" — manda al buzón de
     * seonova.pro (endpoint /api/vigia) DESDE EL SERVIDOR (wp_remote_post):
     * sin CORS, sin exponer nada en el navegador. Con casilla (marcada) para
     * adjuntar el diagnóstico: así cada duda nos llega con contexto.
     */
    private static function feedback_form() {
        $user = wp_get_current_user();
        $sent = isset($_GET['bcr_sent']) ? $_GET['bcr_sent'] : null;
        ?>
        <details class="bcr-feedback" <?php echo $sent !== null ? 'open' : ''; ?>>
            <summary><?php esc_html_e('Want to leave us a question or your opinion?', 'vigia-de-seonova'); ?></summary>
            <?php if ($sent === '1') : ?>
                <p class="bcr-sent-ok">✅ <?php esc_html_e('Sent — thank you! We read everything and reply by email.', 'vigia-de-seonova'); ?></p>
            <?php elseif ($sent === '0') : ?>
                <p class="bcr-sent-ko">⚠️ <?php esc_html_e('It could not be sent (the server may be blocking outgoing requests). Please email us instead: hola@seonova.pro', 'vigia-de-seonova'); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="bcr_feedback" />
                <?php wp_nonce_field('bcr_feedback'); ?>
                <p>
                    <input name="bcr_fb_name" type="text" placeholder="<?php esc_attr_e('Your name', 'vigia-de-seonova'); ?>"
                           value="<?php echo esc_attr($user->display_name); ?>" required />
                    <input name="bcr_fb_email" type="email" placeholder="<?php esc_attr_e('Your email (so we can reply)', 'vigia-de-seonova'); ?>"
                           value="<?php echo esc_attr($user->user_email); ?>" required />
                </p>
                <p><textarea name="bcr_fb_msg" rows="4" class="large-text" required
                    placeholder="<?php esc_attr_e('Your question, idea or opinion about VigIA…', 'vigia-de-seonova'); ?>"></textarea></p>
                <p><label><input name="bcr_fb_diag" type="checkbox" value="1" checked />
                    <?php esc_html_e('Attach my site\'s diagnosis (verdict + bot numbers) so you can help me better', 'vigia-de-seonova'); ?></label></p>
                <p><button class="button button-primary"><?php esc_html_e('Send', 'vigia-de-seonova'); ?></button></p>
            </form>
        </details>
        <?php
    }

    /** Recibe el formulario de dudas y lo reenvía al buzón de seonova.pro. */
    public static function handle_feedback() {
        if (!current_user_can('manage_options') || !check_admin_referer('bcr_feedback')) {
            wp_die('nope');
        }
        $payload = array(
            'type'    => 'feedback',
            'name'    => sanitize_text_field(wp_unslash(isset($_POST['bcr_fb_name']) ? $_POST['bcr_fb_name'] : '')),
            'email'   => sanitize_email(wp_unslash(isset($_POST['bcr_fb_email']) ? $_POST['bcr_fb_email'] : '')),
            'message' => sanitize_textarea_field(wp_unslash(isset($_POST['bcr_fb_msg']) ? $_POST['bcr_fb_msg'] : '')),
            'site'    => home_url('/'),
            'lang'    => self::panel_lang(),
        );
        if (!empty($_POST['bcr_fb_diag'])) {
            $payload['diag'] = self::diag_summary();
        }
        $r = wp_remote_post(BCR_API_URL, array(
            'timeout' => 8,
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($payload),
        ));
        $ok = !is_wp_error($r) && (int) wp_remote_retrieve_response_code($r) === 200;
        wp_safe_redirect(add_query_arg('bcr_sent', $ok ? '1' : '0', admin_url('admin.php?page=vigia-de-seonova')));
        exit;
    }

    /** Resumen del diagnóstico en texto plano (para el buzón y la telemetría). */
    public static function diag_summary() {
        $v = BCR_Store::verdict();
        $t = BCR_Store::totals(7);
        return sprintf(
            "verdict_level=%d state=%s days=%d total_30d=%d bad_pct=%s hostile_day=%s\n7d: total=%d humano=%d bueno=%d impostor=%d datacenter=%d declarado=%d\nplugin=%s wp=%s",
            (int) $v['level'], $v['state'], (int) $v['days'], (int) $v['total'],
            $v['bad_pct'], $v['hostile_day'],
            (int) $t['total'], (int) $t['humano'], (int) $t['bueno'],
            (int) $t['impostor'], (int) $t['datacenter'], (int) $t['declarado'],
            BCR_VERSION, get_bloginfo('version')
        );
    }

    /** Aviso "déjanos una reseña" — DORMIDO hasta que BCR_WPORG_SLUG tenga valor. */
    public static function review_notice() {
        if (BCR_WPORG_SLUG === '' || !current_user_can('manage_options')) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || strpos((string) $screen->id, 'vigia-de-seonova') === false) {
            return;
        }
        $installed = (int) get_option('bcr_installed_at', 0);
        if (!$installed || time() - $installed < 14 * DAY_IN_SECONDS) {
            return;
        }
        if (get_user_meta(get_current_user_id(), 'bcr_review_dismissed', true)) {
            return;
        }
        $url = 'https://wordpress.org/support/plugin/' . BCR_WPORG_SLUG . '/reviews/#new-post';
        $dismiss = wp_nonce_url(add_query_arg('bcr_review_dismiss', '1'), 'bcr_review');
        echo '<div class="notice notice-info"><p>'
            . esc_html__('Two weeks with VigIA! If it is helping you see your bots, a ★★★★★ review helps other site owners find it.', 'vigia-de-seonova')
            . ' <a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html__('Leave a review', 'vigia-de-seonova') . '</a>'
            . ' · <a href="' . esc_url($dismiss) . '">' . esc_html__('No thanks', 'vigia-de-seonova') . '</a>'
            . '</p></div>';
    }

    public static function handle_review_dismiss() {
        if (empty($_GET['bcr_review_dismiss']) || !current_user_can('manage_options')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_review')) {
            return;
        }
        update_user_meta(get_current_user_id(), 'bcr_review_dismissed', 1);
        wp_safe_redirect(remove_query_arg(array('bcr_review_dismiss', '_wpnonce')));
        exit;
    }

    private static function who_tables() {
        $bad_kind = array(
            'impostor'   => __('impostor', 'vigia-de-seonova'),
            'datacenter' => __('data center', 'vigia-de-seonova'),
            'declarado'  => __('declared', 'vigia-de-seonova'),
        );
        $good = BCR_Store::who_breakdown(array('bueno'), 7);
        $bad  = BCR_Store::who_breakdown(array('impostor', 'datacenter', 'declarado'), 7);
        // Fichas de TODOS de una vez (tres consultas), no una por fila.
        $det_good = BCR_Store::who_details(array('bueno'), 7);
        $det_bad  = BCR_Store::who_details(array('impostor', 'datacenter', 'declarado'), 7);
        echo '<div class="bcr-who">';

        // BUENOS
        echo '<div class="bcr-who-col">';
        $tot_buenos = 0;
        foreach ($good as $r) {
            $tot_buenos += (int) $r->n;
        }
        echo '<table class="bcr-table bcr-who-tabla"><thead><tr>'
            . '<th class="bcr-cab bcr-cab-buenos">' . esc_html__('Good bots that visited', 'vigia-de-seonova') . '</th>'
            . '<th class="bcr-cab bcr-cab-buenos bcr-num">' . esc_html(number_format_i18n($tot_buenos)) . '</th>'
            . '</tr></thead><tbody>';
        if (!$good) {
            echo '<tr><td colspan="2" class="bcr-muted">' . esc_html__('None yet.', 'vigia-de-seonova') . '</td></tr>';
        } else {
            foreach ($good as $r) {
                $d = isset($det_good[$r->who]) ? $det_good[$r->who] : null;
                echo '<tr><td><details class="bcr-det"><summary>' . esc_html(self::good_hint($r->who)) . '</summary>'
                    . self::bot_detail_html($r->who, 'bueno', $d) . '</details></td>'
                    . '<td class="bcr-num"><strong>' . esc_html(number_format_i18n($r->n)) . '</strong></td></tr>';
            }
        }
        echo '</tbody></table>';
        echo '</div>';

        // MALOS
        echo '<div class="bcr-who-col">';
        $tot_malos = 0;
        foreach ($bad as $r) {
            $tot_malos += (int) $r->n;
        }
        echo '<table class="bcr-table bcr-who-tabla"><thead><tr>'
            . '<th class="bcr-cab bcr-cab-malos">' . esc_html__('Bad bots that visited', 'vigia-de-seonova') . '</th>'
            . '<th class="bcr-cab bcr-cab-malos bcr-num">' . esc_html(number_format_i18n($tot_malos)) . '</th>'
            . '</tr></thead><tbody>';
        if (!$bad) {
            echo '<tr><td colspan="2" class="bcr-muted">' . esc_html__('None yet — good news.', 'vigia-de-seonova') . '</td></tr>';
        } else {
            // Por cada tipo de malo, QUÉ haría WPO Toolkit con él: convierte la
            // lista de males en una demo del producto.
            $pitch = array(
                'impostor'   => __('→ WPO Toolkit would block it instantly: it is not who it claims to be.', 'vigia-de-seonova'),
                'datacenter' => __('→ WPO Toolkit would stop its whole network at the edge, before it touches your hosting.', 'vigia-de-seonova'),
                'declarado'  => __('→ WPO Toolkit would cut it with one rule so it stops burning your pages.', 'vigia-de-seonova'),
            );
            echo '<table class="bcr-table"><tbody>';
            foreach ($bad as $r) {
                $kind = isset($bad_kind[$r->bucket]) ? $bad_kind[$r->bucket] : $r->bucket;
                $d    = isset($det_bad[$r->who]) ? $det_bad[$r->who] : null;
                echo '<tr><td><details class="bcr-det"><summary>' . esc_html($r->who)
                    . ' <span class="bcr-muted">(' . esc_html($kind) . ')</span>'
                    . (isset($pitch[$r->bucket]) ? '<br><small class="bcr-pitch">' . esc_html($pitch[$r->bucket]) . '</small>' : '')
                    . '</summary>'
                    . self::bot_detail_html($r->who, $r->bucket, $d)
                    . '</details></td>'
                    . '<td class="bcr-num"><strong>' . esc_html(number_format_i18n($r->n)) . '</strong></td></tr>';
            }
        }
        echo '</tbody></table>';
        if ($bad) {
            echo '<p><a href="' . esc_url(bcr_cta_url(self::panel_lang())) . '" target="_blank" rel="noopener">'
                . esc_html__('I want WPO Toolkit to stop them for me →', 'vigia-de-seonova') . '</a></p>';
        }
        echo '</div>';
        echo '</div>';
        echo '<p class="description">' . esc_html__('Good bots (Google, Bing, AdSense…) bring you traffic and money — never blocked. Bad bots are impostors, data-center swarms and scrapers.', 'vigia-de-seonova') . '</p>';
    }

    /**
     * Lo que sabemos de cada visitante, en cristiano. Se enseña al desplegar su
     * fila. Los textos salen del catálogo compartido con WPO Toolkit
     * (includes/fichas.php, generado): las mismas palabras en los dos sitios.
     *
     * @return array{que:string, razon:string, trae:string, robots:string, familia:string, consejo:string}
     */
    private static function bot_facts($who, $bucket, $ua = '') {
        $f = BCR_Fichas::de($who, $bucket, self::panel_lang(), $ua);
        return array(
            'que'     => $f['que'],
            'razon'   => $f['razon'],
            'trae'    => $f['trae'],
            'robots'  => $f['robots'],
            'familia' => $f['familiaNombre'],
            'consejo' => $f['consejo'],
        );
    }

    /** Contenido del desplegable de una fila (bot bueno o malo). */
    private static function bot_detail_html($who, $bucket, $det, $pitch = '') {
        $f = self::bot_facts($who, $bucket, $det && !empty($det['ua']) ? $det['ua'] : '');
        $h = '<div class="bcr-ficha">';
        $h .= '<p><strong>' . esc_html__('What it is:', 'vigia-de-seonova') . '</strong> ' . esc_html($f['que']) . '</p>';
        $h .= '<p><strong>' . esc_html__('Why it is in this list:', 'vigia-de-seonova') . '</strong> ' . esc_html($f['razon']) . '</p>';
        $h .= '<p class="bcr-ficha-si"><span>' . esc_html__('Does it bring you visits?', 'vigia-de-seonova') . ' <b>' . esc_html($f['trae']) . '</b></span>'
            . '<span>' . esc_html__('Does it respect robots.txt?', 'vigia-de-seonova') . ' <b>' . esc_html($f['robots']) . '</b></span>'
            . ($f['familia'] !== '' ? '<span>' . esc_html__('Family:', 'vigia-de-seonova') . ' <b>' . esc_html($f['familia']) . '</b></span>' : '')
            . '</p>';
        if ($f['consejo'] !== '') {
            $h .= '<p class="bcr-muted">' . esc_html($f['consejo']) . '</p>';
        }

        if ($det) {
            $fmt = get_option('date_format') . ' H:i';
            $h .= '<p><strong>' . esc_html__('Seen here:', 'vigia-de-seonova') . '</strong> '
                . esc_html(sprintf(
                    /* translators: 1: first date, 2: last date, 3: number of visits, 4: number of IPs */
                    __('first time %1$s, last time %2$s · %3$s visits from %4$s different addresses', 'vigia-de-seonova'),
                    mysql2date($fmt, $det['primera']), mysql2date($fmt, $det['ultima']),
                    number_format_i18n($det['n']), number_format_i18n($det['ips'])
                )) . '</p>';

            if (!empty($det['paths'])) {
                $trozos = array();
                foreach ($det['paths'] as $p) {
                    $trozos[] = '<code>' . esc_html($p['path']) . '</code> <span class="bcr-muted">×' . esc_html(number_format_i18n($p['c'])) . '</span>';
                }
                $h .= '<p><strong>' . esc_html__('Pages it took:', 'vigia-de-seonova') . '</strong> ' . implode(' · ', $trozos) . '</p>';
            }
            if (!empty($det['ip_list'])) {
                $trozos = array();
                foreach ($det['ip_list'] as $i) {
                    $t = '<code>' . esc_html($i['ip']) . '</code>';
                    if (!empty($i['rdns'])) {
                        $t .= ' <span class="bcr-muted">(' . esc_html($i['rdns']) . ')</span>';
                    }
                    $trozos[] = $t . ' <span class="bcr-muted">×' . esc_html(number_format_i18n($i['c'])) . '</span>';
                }
                $h .= '<p><strong>' . esc_html__('Addresses it came from:', 'vigia-de-seonova') . '</strong> ' . implode(' · ', $trozos) . '</p>';
            }
            if (!empty($det['ua'])) {
                $extra = $det['uas'] > 1
                    ? ' <span class="bcr-muted">(' . esc_html(sprintf(
                        /* translators: %s: number of different user agents */
                        __('one example of the %s disguises it used', 'vigia-de-seonova'),
                        number_format_i18n($det['uas'])
                    )) . ')</span>'
                    : '';
                $h .= '<p><strong>' . esc_html__('How it introduces itself:', 'vigia-de-seonova') . '</strong> <code class="bcr-ua">'
                    . esc_html($det['ua']) . '</code>' . $extra . '</p>';
            }
        }
        if ($pitch) {
            $h .= '<p class="bcr-pitch">' . esc_html($pitch) . '</p>';
        }
        $h .= '</div>';
        return $h;
    }

    /** Añade una pista corta a ciertos bots buenos conocidos. */
    private static function good_hint($who) {
        $hints = array(
            'Googlebot'                => __('Google search index', 'vigia-de-seonova'),
            'Bingbot'                  => __('Bing search index', 'vigia-de-seonova'),
            'AdSense (Mediapartners)'  => __('AdSense checking your ads', 'vigia-de-seonova'),
            'AdSense (AdsBot)'         => __('AdSense checking your ads', 'vigia-de-seonova'),
            'Bing Ads (AdIdxBot)'      => __('Bing Ads', 'vigia-de-seonova'),
            'Applebot'                 => __('Apple / Siri', 'vigia-de-seonova'),
            'Facebook'                 => __('Facebook link previews', 'vigia-de-seonova'),
        );
        return isset($hints[$who]) ? $who . ' — ' . $hints[$who] : $who;
    }

    /**
     * Gráfico en TRES colores bien separados (petición del usuario): humanos
     * (verde), bots buenos (azul), bots malos (rojo). Arriba una barra grande
     * de la semana con números y %; abajo el apilado diario de 30 días.
     */
    private static function chart() {
        $C_HUM = '#2fb344'; $C_GOOD = '#2271b1'; $C_BAD = '#e0555a';

        // Barra grande de la semana con los 3 números.
        $t = BCR_Store::totals(7);
        $hum = (int) $t['humano'];
        $good = (int) $t['bueno'];
        $bad = (int) $t['impostor'] + (int) $t['datacenter'] + (int) $t['declarado'];
        $sum = max(1, $hum + $good + $bad);
        $seg = function ($n, $color, $label) use ($sum) {
            if ($n <= 0) { return ''; }
            $pct = round($n / $sum * 100);
            $w = max(3, $n / $sum * 100); // ancho mínimo para que se vea aunque sea poco
            return '<div class="bcr-seg" style="width:' . esc_attr($w) . '%;background:' . esc_attr($color) . '" '
                . 'title="' . esc_attr($label . ': ' . number_format_i18n($n) . ' (' . $pct . '%)') . '">'
                . '</div>'; // el número va arriba, en su etiqueta de color
        };
        // Fila de cabecera: quién es cada color y cuánto hay, a todo el ancho.
        $cel = function ($color, $label, $n) {
            return '<div class="bcr-cab-cel" style="background:' . esc_attr($color) . '">'
                . '<span>' . esc_html($label) . '</span><b>' . esc_html(number_format_i18n($n)) . '</b></div>';
        };
        echo '<div class="bcr-cabecera">'
            . $cel($C_HUM, __('Humans', 'vigia-de-seonova'), $hum)
            . $cel($C_GOOD, __('Good bots', 'vigia-de-seonova'), $good)
            . $cel($C_BAD, __('Bad bots', 'vigia-de-seonova'), $bad)
            . '</div>';

        // Y debajo, la misma barra de siempre pero a escala real.
        echo '<div class="bcr-bigbar">';
        echo $seg($hum, $C_HUM, __('Humans', 'vigia-de-seonova'));
        echo $seg($good, $C_GOOD, __('Good bots', 'vigia-de-seonova'));
        echo $seg($bad, $C_BAD, __('Bad bots', 'vigia-de-seonova'));
        echo '</div>';

        // Apilado diario, 3 colores. Se pintan los días QUE HAY (ver
        // dias_con_datos), no 30 siempre: con cuatro días de datos, un
        // gráfico de 30 columnas sale vacío casi entero.
        $days = BCR_Store::daily(BCR_Store::dias_con_datos());
        $max = 1;
        foreach ($days as $d) {
            $max = max($max, (int) $d['total']);
        }

        // PAD_T: sin hueco arriba, la cifra del maximo se cortaba por la mitad.
        $W = 1200; $H = 110; $PAD_L = 40; $PAD_B = 22; $PAD_T = 9;
        $plot = $W - $PAD_L - 8;
        $bw = $plot / max(1, count($days));
        $barra = max(3, min($bw - 6, $bw * 0.7)); // barra con aire a los lados
        echo '<svg class="bcr-chart" viewBox="0 0 ' . (int) $W . ' ' . (int) ($PAD_T + $H + $PAD_B) . '" role="img" aria-label="'
            . esc_attr__('Daily visits: humans, good bots, bad bots', 'vigia-de-seonova') . '">';

        // Rejilla: sin ella las barras son bonitas pero no se pueden leer.
        foreach (array(0, 0.5, 1) as $f) {
            $gy = $PAD_T + $H - $f * $H;
            echo '<line class="bcr-grid" x1="' . $PAD_L . '" y1="' . $gy . '" x2="' . $W . '" y2="' . $gy . '"/>';
            echo '<text x="' . ($PAD_L - 7) . '" y="' . ($gy + 3) . '" font-size="9" text-anchor="end">'
                . esc_html(number_format_i18n((int) round($max * $f))) . '</text>';
        }

        $paso = max(1, (int) ceil(count($days) / 6));
        foreach ($days as $i => $d) {
            $vh = (int) $d['humano'];
            $vg = (int) $d['bueno'];
            $vb = (int) $d['impostor'] + (int) $d['datacenter'] + (int) $d['declarado'];
            $x  = $PAD_L + $i * $bw + ($bw - $barra) / 2;
            $cx = $x + $barra / 2;
            $ph = round($vh / $max * $H);
            $pg = round($vg / $max * $H);
            $pb = round($vb / $max * $H);
            $y  = $PAD_T + $H;
            // apilado de abajo arriba: humanos, buenos, malos
            $tramos = array(
                array($ph, $C_HUM, __('Humans', 'vigia-de-seonova'), $vh),
                array($pg, $C_GOOD, __('Good bots', 'vigia-de-seonova'), $vg),
                array($pb, $C_BAD, __('Bad bots', 'vigia-de-seonova'), $vb),
            );
            foreach ($tramos as $t) {
                if ($t[0] <= 0) {
                    continue;
                }
                $y -= $t[0];
                echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" width="' . esc_attr($barra) . '"'
                    . ' height="' . esc_attr($t[0]) . '" fill="' . esc_attr($t[1]) . '">'
                    . '<title>' . esc_attr($d['d'] . ' · ' . $t[2] . ': ' . number_format_i18n($t[3])) . '</title></rect>';
            }
            if ($i % $paso === 0 || $i === count($days) - 1) {
                echo '<text x="' . esc_attr($cx) . '" y="' . esc_attr($PAD_T + $H + 15) . '" font-size="9" text-anchor="middle">'
                    . esc_html(substr($d['d'], 5)) . '</text>';
            }
        }
        echo '</svg>';
    }

    /**
     * Tema por variables. Regla de oro: NINGÚN color fuera de las variables
     * (el fallo del modo noche v0.1: la cabecera de la tabla se quedaba con el
     * blanco de WP y las etiquetas eran ilegibles).
     */
    private static function css() {
        $vars_dark = '--bcr-bg:#1b1e23;--bcr-card:#23272e;--bcr-border:#3a3f47;--bcr-text:#dfe3e8;--bcr-muted:#9aa2ac;--bcr-code:#2c313a;--bcr-link:#4f94d4;';
        return '
        .bcr-root{--bcr-bg:#f0f0f1;--bcr-card:#fff;--bcr-border:#dcdcde;--bcr-text:#1d2327;--bcr-muted:#777;--bcr-code:#f0f0f1;--bcr-link:#2271b1;
            background:var(--bcr-bg);color:var(--bcr-text);margin:12px 0 0 0;padding:16px;border-radius:8px;min-height:calc(100vh - 120px)}
        @media (prefers-color-scheme: dark){ .bcr-root:not(.bcr-light){' . $vars_dark . '} }
        .bcr-root.bcr-dark{' . $vars_dark . '}
        /* Pintar TODA la columna de WordPress cuando el panel está oscuro, para
           que no quede la franja clara del admin alrededor (bug 2026-08-24). */
        @media (prefers-color-scheme: dark){
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpcontent,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpbody-content,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpbody,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpfooter{background:#1b1e23!important}
        }
        body.wp-admin:has(#bcr-root.bcr-dark) #wpcontent,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpbody-content,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpbody,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpfooter{background:#1b1e23!important}
        body.wp-admin:has(#bcr-root.bcr-light) #wpcontent,
        body.wp-admin:has(#bcr-root.bcr-light) #wpbody-content,
        body.wp-admin:has(#bcr-root.bcr-light) #wpbody{background:#f0f0f1}
        .bcr-root h1,.bcr-root h2{color:var(--bcr-text)}
        .bcr-head{display:flex;justify-content:space-between;align-items:center}
        .bcr-sub{font-size:14px;color:var(--bcr-muted);font-weight:normal;margin-left:8px}
        .bcr-theme-toggle{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:50%;
            width:36px;height:36px;font-size:16px;cursor:pointer;line-height:1}
        .bcr-head-tools{display:flex;align-items:center;gap:10px}
        .bcr-lang{display:inline-flex;border:1px solid var(--bcr-border);border-radius:6px;overflow:hidden}
        .bcr-lang a{padding:4px 10px;font-size:12px;font-weight:700;text-decoration:none;color:var(--bcr-muted);background:var(--bcr-card)}
        .bcr-lang a.on{background:#4f94d4;color:#fff}
        .bcr-progress{display:flex;flex-direction:column;gap:8px;max-width:520px;margin:10px 0 2px}
        .bcr-progress-row{display:flex;align-items:center;gap:10px}
        .bcr-progress-label{flex:0 0 130px;font-size:12px;color:var(--bcr-muted)}
        .bcr-progress-track{flex:1;height:12px;border-radius:6px;background:var(--bcr-bg);border:1px solid var(--bcr-border);overflow:hidden}
        .bcr-progress-fill{display:block;height:100%;width:0;background:#4f94d4;transition:width .5s ease;
            background-image:linear-gradient(45deg,rgba(255,255,255,.25) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.25) 50%,rgba(255,255,255,.25) 75%,transparent 75%,transparent);
            background-size:16px 16px;animation:bcr-stripe 1s linear infinite}
        .bcr-progress-fill.done{background-color:#2fb344;animation:none}
        .bcr-progress-num{flex:0 0 auto;font-size:12px;font-variant-numeric:tabular-nums;color:var(--bcr-text)}
        @keyframes bcr-stripe{from{background-position:0 0}to{background-position:16px 0}}
        @media (prefers-reduced-motion:reduce){.bcr-progress-fill{animation:none}}
        .bcr-cards{display:flex;gap:16px;flex-wrap:wrap;margin:16px 0}
        .bcr-nota-cache{margin:14px 0 0;padding:10px 12px;border-left:4px solid #dba617;background:var(--bcr-panel);border-radius:0 4px 4px 0;max-width:900px;line-height:1.5}
        .bcr-nota-cache .dashicons{color:#dba617;vertical-align:text-bottom}
        .bcr-prueba{margin:-14px 0 26px}
        .bcr-prueba .description{margin-left:10px}
        .bcr-nota-escudo{border-left-color:#4f94d4}
        .bcr-nota-escudo .dashicons{color:#4f94d4}
        .bcr-card{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:16px 20px;min-width:200px;flex:1;color:var(--bcr-text)}
        .bcr-card .bcr-big{font-size:28px;font-weight:700;line-height:1.2}
        .bcr-card-money{border-color:#d63638}
        .bcr-card-money .bcr-big{color:#e65054}
        .bcr-rpm-form{margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:6px}
        .bcr-rpm-form label{font-weight:600}
        .bcr-rpm-form input{width:80px;background:var(--bcr-card);color:var(--bcr-text);border:1px solid var(--bcr-border)}
        .bcr-rpm-form .bcr-muted{flex-basis:100%}
        .bcr-card-cta{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:8px}
        .bcr-muted{color:var(--bcr-muted);font-size:12px}
        .bcr-root .description{color:var(--bcr-muted)}
        .bcr-verdict{background:var(--bcr-card);border:1px solid var(--bcr-border);border-left:4px solid var(--bcr-muted);border-radius:6px;padding:12px 20px;margin:16px 0}
        .bcr-verdict h2{margin:4px 0}
        .bcr-verdict-title{margin-left:10px}
        /* Recuadro entero teñido según el veredicto (tinte translúcido: funciona
           igual sobre fondo claro y oscuro). Borde y título a juego. */
        .bcr-v1{border-left-color:#00a32a;border-color:rgba(0,163,42,.45);background:rgba(0,163,42,.10)}
        .bcr-v1 .bcr-verdict-title{color:#2fb344}
        .bcr-v2{border-left-color:#e08b1a;border-color:rgba(224,139,26,.45);background:rgba(224,139,26,.10)}
        .bcr-v2 .bcr-verdict-title{color:#e08b1a}
        .bcr-v3{border-left-color:#d63638;border-color:rgba(214,54,56,.45);background:rgba(214,54,56,.10)}
        .bcr-v3 .bcr-verdict-title{color:#e65054}
        .bcr-v1,.bcr-v2,.bcr-v3{border-left-width:4px}
        /* Preliminar: mismo color del nivel, pero borde discontinuo + aviso ámbar. */
        .bcr-verdict.bcr-preview{border-left-style:dashed}
        .bcr-preview-tag{color:#e08b1a;font-weight:600;font-size:12px;margin:2px 0 8px}
        .bcr-verdict .button{margin-top:4px}
        .bcr-buckets{display:flex;flex-direction:column;gap:4px;margin-bottom:16px}
        .bcr-who{display:flex;gap:20px;flex-wrap:wrap}
        .bcr-who-col{flex:1;min-width:300px}
        .bcr-who-col h3{margin:6px 0}
        /* En modo noche este enlace salía azul oscuro sobre fondo oscuro y no
           se leía: usa el color de enlace del tema, como el resto. */
        .bcr-who a{color:var(--bcr-link)}
        /* Cabecera de color de cada tabla: se lee de un vistazo de quién es
           la lista sin tener que leer nada. Más específico que la regla
           general de thead, que pinta el fondo de la tarjeta. */
        .bcr-root table.bcr-who-tabla thead th.bcr-cab{color:#fff!important;border-bottom:0;font-size:14px;padding:9px 12px}
        .bcr-root table.bcr-who-tabla thead th.bcr-cab-buenos{background:#2271b1!important}
        .bcr-root table.bcr-who-tabla thead th.bcr-cab-malos{background:#e0555a!important}
        .bcr-root table.bcr-who-tabla thead th.bcr-num{text-align:right;font-variant-numeric:tabular-nums}
        /* La misma fila de color, arriba de la barra de 30 días. */
        .bcr-cabecera{display:flex;gap:8px;margin:10px 0 8px;flex-wrap:wrap}
        .bcr-cab-cel{flex:1;display:flex;align-items:center;justify-content:space-between;gap:10px;border-radius:6px;
            padding:9px 14px;color:#fff;font-weight:600;font-size:14px;min-width:160px}
        .bcr-cab-cel span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .bcr-cab-cel b{font-variant-numeric:tabular-nums;font-size:16px}
        .bcr-who td.bcr-num{text-align:right;width:80px;font-variant-numeric:tabular-nums;vertical-align:top}
        /* Desplegable de cada visitante: el título es el disparador. */
        .bcr-det>summary{cursor:pointer;list-style:none;padding:2px 0 2px 16px;position:relative;color:var(--bcr-link)}
        .bcr-det>summary .bcr-muted{color:var(--bcr-muted)}
        .bcr-det>summary::-webkit-details-marker{display:none}
        .bcr-det>summary::before{content:"▸";position:absolute;left:0;top:2px;color:var(--bcr-muted);transition:transform .15s}
        .bcr-det[open]>summary::before{transform:rotate(90deg)}
        .bcr-det>summary:hover{text-decoration:underline}
        .bcr-ficha{margin:6px 0 4px 16px;padding:10px 12px;border-left:3px solid var(--bcr-border);background:var(--bcr-bg);border-radius:0 4px 4px 0;font-size:13px}
        .bcr-ficha p{margin:0 0 6px}
        .bcr-ficha p:last-child{margin-bottom:0}
        .bcr-ficha code{font-size:12px;word-break:break-all}
        .bcr-ficha .bcr-ua{display:inline-block;max-width:100%}
        .bcr-ficha-si{display:flex;gap:18px;flex-wrap:wrap;color:var(--bcr-muted)}
        .bcr-bucket strong{min-width:56px;display:inline-block;text-align:right;margin:0 8px}
        .bcr-bigbar{display:flex;height:14px;border-radius:7px;overflow:hidden;margin:0 0 16px}
        .bcr-seg{display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:13px;min-width:0;transition:width .3s}
        .bcr-legend{display:flex;gap:20px;flex-wrap:wrap;max-width:900px;margin:2px 0 12px;color:var(--bcr-text)}
        .bcr-legend span{display:inline-flex;align-items:center;gap:6px}
        .bcr-legend i{width:12px;height:12px;border-radius:3px;display:inline-block}
        .bcr-legend b{font-variant-numeric:tabular-nums}
        .bcr-chart{width:100%;height:auto;background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:6px}
        .bcr-chart text{fill:var(--bcr-muted)}
        .bcr-chart .bcr-grid{stroke:var(--bcr-border);stroke-width:1}
        .bcr-tablebar{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:6px 0;color:var(--bcr-muted)}
        .bcr-tablebar a,.bcr-pag a{color:#4f94d4;text-decoration:none;margin:0 3px}
        .bcr-tablebar strong{margin:0 3px}
        .bcr-pag{margin:8px 0;display:flex;gap:16px;justify-content:center;color:var(--bcr-muted)}
        /* Tablas 100% propias (sin la clase widefat de WP, que forzaba blanco). */
        .bcr-root table.bcr-table{width:100%;border-collapse:collapse;background:var(--bcr-card)!important;border:1px solid var(--bcr-border);color:var(--bcr-text);margin:4px 0}
        .bcr-root table.bcr-table thead th,.bcr-root table.bcr-table thead td{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border-bottom:1px solid var(--bcr-border);text-align:left;padding:8px 10px;font-weight:700}
        .bcr-root table.bcr-table td{color:var(--bcr-text)!important;border-top:1px solid var(--bcr-border);padding:6px 10px}
        .bcr-root table.bcr-table tbody tr{background:var(--bcr-card)!important}
        .bcr-root table.bcr-table tbody tr:nth-child(odd){background:var(--bcr-bg)!important}
        .bcr-root code{background:var(--bcr-code)!important;color:var(--bcr-text)!important}
        .bcr-root .form-table th,.bcr-root .form-table td{color:var(--bcr-text)}
        .bcr-root input[type=number],.bcr-root input[type=email]{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border:1px solid var(--bcr-border)}
        /* Red de seguridad: cualquier caja de WP que se cuele en el panel toma el tema. */
        .bcr-root .widefat,.bcr-root .card,.bcr-root .postbox{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border-color:var(--bcr-border)!important}
        .bcr-pitch{color:#8B5CF6}
        .bcr-feedback{max-width:700px;margin:20px 0;background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:10px 16px;color:var(--bcr-text)}
        .bcr-feedback summary{cursor:pointer;font-weight:600}
        .bcr-feedback input[type=text],.bcr-feedback input[type=email]{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border:1px solid var(--bcr-border);min-width:230px;margin-right:8px}
        .bcr-feedback textarea{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border:1px solid var(--bcr-border)}
        .bcr-sent-ok{color:#2fb344;font-weight:600}
        .bcr-sent-ko{color:#e08b1a;font-weight:600}
        .bcr-export{display:inline-flex;gap:8px;margin-left:auto;flex-wrap:wrap}
        .bcr-pill{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;white-space:nowrap;border:1px solid transparent}
        .bcr-pill::before{content:"";width:8px;height:8px;border-radius:50%;background:currentColor;flex:none}
        .bcr-p-humano{color:#1a7f37;background:rgba(47,179,68,.14);border-color:rgba(47,179,68,.35)}
        .bcr-p-bueno{color:#2c6ba8;background:rgba(79,148,212,.16);border-color:rgba(79,148,212,.38)}
        .bcr-p-malo{color:#c0362c;background:rgba(230,80,84,.14);border-color:rgba(230,80,84,.35)}
        .bcr-root.bcr-dark .bcr-p-humano,.bcr-dark .bcr-p-humano{color:#5ed17a}
        .bcr-root.bcr-dark .bcr-p-bueno,.bcr-dark .bcr-p-bueno{color:#7fb6ea}
        .bcr-root.bcr-dark .bcr-p-malo,.bcr-dark .bcr-p-malo{color:#ff8b8b}
        @media (prefers-color-scheme: dark){
          .bcr-root:not(.bcr-light) .bcr-p-humano{color:#5ed17a}
          .bcr-root:not(.bcr-light) .bcr-p-bueno{color:#7fb6ea}
          .bcr-root:not(.bcr-light) .bcr-p-malo{color:#ff8b8b}
        }
        .bcr-b-impostor{color:#e65054;font-weight:700}
        .bcr-b-datacenter{color:#e08b1a;font-weight:600}
        .bcr-b-bueno{color:#4f94d4}
        .bcr-b-humano{color:#2fb344}
        ';
    }

    /** Botón 🌙/☀️: fuerza noche o día y lo recuerda; sin elección, manda el sistema. */
    private static function theme_js() {
        return "(function(){\n"
            . "var root=document.getElementById('bcr-root'),btn=document.getElementById('bcr-theme-toggle');\n"
            . "if(!root||!btn)return;\n"
            . "function sysDark(){return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;}\n"
            . "function effDark(){if(root.classList.contains('bcr-dark'))return true;if(root.classList.contains('bcr-light'))return false;return sysDark();}\n"
            . "function paint(){btn.textContent=effDark()?'\\u2600\\uFE0F':'\\uD83C\\uDF19';}\n"
            . "var saved=null;try{saved=localStorage.getItem('bcr-theme');}catch(e){}\n"
            . "if(saved==='dark')root.classList.add('bcr-dark');\n"
            . "if(saved==='light')root.classList.add('bcr-light');\n"
            . "paint();\n"
            . "btn.addEventListener('click',function(){\n"
            . "var toDark=!effDark();\n"
            . "root.classList.toggle('bcr-dark',toDark);\n"
            . "root.classList.toggle('bcr-light',!toDark);\n"
            . "try{localStorage.setItem('bcr-theme',toDark?'dark':'light');}catch(e){}\n"
            . "paint();\n"
            . "});\n"
            . "})();";
    }
}
