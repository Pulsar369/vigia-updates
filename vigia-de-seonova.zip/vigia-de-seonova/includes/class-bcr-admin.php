<?php
/**
 * Panel de admin — 1 pantalla: tarjetas (con el RPM DENTRO de la tarjeta del
 * dinero, al lado de donde se ve su efecto), veredicto sin IA, desglose,
 * gráfico 30 días, tabla paginada de últimas visitas y CTA al toolkit.
 *
 * Tema noche/día por variables CSS. Strings en inglés (base); es_* en /languages.
 */

defined('ABSPATH') || exit;

class BCR_Admin {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'settings'));
        add_action('admin_init', array(__CLASS__, 'handle_lang_switch'));
    }

    /** Idioma elegido a mano para el panel: 'es' | 'en' | '' (auto = manda WP). */
    private static function lang_pref() {
        $p = get_user_meta(get_current_user_id(), 'bcr_lang', true);
        return ($p === 'es' || $p === 'en') ? $p : '';
    }

    /** Guarda la elección de idioma y recarga. Se recuerda POR USUARIO (user_meta),
     *  igual que el modo noche/día — pero server-side porque las traducciones son
     *  del servidor (PHP/gettext), no del navegador. */
    public static function handle_lang_switch() {
        if (!isset($_GET['bcr_lang']) || !current_user_can('manage_options')) {
            return;
        }
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_key($_GET['_wpnonce']), 'bcr_lang')) {
            return;
        }
        $raw = sanitize_key($_GET['bcr_lang']);
        $val = ($raw === 'es' || $raw === 'en') ? $raw : '';
        update_user_meta(get_current_user_id(), 'bcr_lang', $val);
        wp_safe_redirect(remove_query_arg(array('bcr_lang', '_wpnonce')));
        exit;
    }

    /** URL con nonce para fijar un idioma. */
    private static function lang_url($lang) {
        return wp_nonce_url(add_query_arg('bcr_lang', $lang), 'bcr_lang');
    }

    public static function menu() {
        add_menu_page(
            __('VigIA de SeoNova', 'vigia-de-seonova'),
            __('VigIA', 'vigia-de-seonova'),
            'manage_options',
            'vigia-de-seonova',
            array(__CLASS__, 'render'),
            'dashicons-shield-alt',
            58
        );
    }

    public static function settings() {
        // Grupos SEPARADOS: el mini-form del RPM (en la tarjeta del dinero) no
        // puede compartir grupo con el email — options.php machaca a null todo
        // campo del grupo que no viaje en el POST.
        register_setting('bcr_money', 'bcr_rpm', array(
            'type' => 'number', 'sanitize_callback' => array(__CLASS__, 'san_rpm'), 'default' => 0,
        ));
        register_setting('bcr_report', 'bcr_report_enabled', array(
            'type' => 'string', 'sanitize_callback' => array(__CLASS__, 'san_bool'), 'default' => '1',
        ));
        register_setting('bcr_report', 'bcr_report_email', array(
            'type' => 'string', 'sanitize_callback' => 'sanitize_email', 'default' => '',
        ));
    }

    public static function san_rpm($v) {
        $v = (float) str_replace(',', '.', (string) $v);
        return ($v >= 0 && $v < 1000) ? $v : 0;
    }

    public static function san_bool($v) {
        return $v === '1' ? '1' : '0';
    }

    /** Tamaño de página de la tabla: lo elige el usuario y se le recuerda. */
    private static function per_page() {
        $allowed = array(10, 25, 50, 100);
        $uid = get_current_user_id();
        if (isset($_GET['bcr_pp'])) {
            $pp = (int) $_GET['bcr_pp'];
            if (in_array($pp, $allowed, true)) {
                update_user_meta($uid, 'bcr_per_page', $pp);
                return $pp;
            }
        }
        $saved = (int) get_user_meta($uid, 'bcr_per_page', true);
        return in_array($saved, $allowed, true) ? $saved : 25;
    }

    public static function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        // Belt-and-suspenders: además del filtro plugin_locale (que actúa al
        // cargar el textdomain), forzamos AQUÍ el .mo exacto justo antes de
        // pintar. Así el idioma elegido se aplica sí o sí, sin depender del
        // momento de carga ni de la caché de traducciones de WP.
        $bcr_pref = self::lang_pref();
        $bcr_mo_ok = false;
        if ($bcr_pref !== '') {
            $bcr_want = $bcr_pref === 'es' ? 'es_ES' : 'en_US';
            unload_textdomain('vigia-de-seonova');
            $bcr_mo = BCR_DIR . 'languages/vigia-de-seonova-' . $bcr_want . '.mo';
            if (is_readable($bcr_mo)) {
                $bcr_mo_ok = load_textdomain('vigia-de-seonova', $bcr_mo);
            }
        }
        $t7  = BCR_Store::totals(7);
        $bad7 = $t7['impostor'] + $t7['datacenter'] + $t7['declarado'];
        $pct7 = $t7['total'] > 0 ? round($bad7 / $t7['total'] * 100) : 0;
        $cost = BCR_Store::monthly_cost();
        $rpm  = (float) get_option('bcr_rpm', 0);
        ?>
        <div class="wrap">
        <div class="bcr-root" id="bcr-root">
            <div class="bcr-head">
                <h1><?php esc_html_e('VigIA de SeoNova', 'vigia-de-seonova'); ?>
                    <span class="bcr-sub"><?php esc_html_e('who visits you and what it costs', 'vigia-de-seonova'); ?></span></h1>
                <div class="bcr-head-tools">
                    <?php $lp = self::lang_pref(); ?>
                    <span class="bcr-lang" title="<?php esc_attr_e('Panel language', 'vigia-de-seonova'); ?>">
                        <a class="<?php echo $lp === 'es' ? 'on' : ''; ?>" href="<?php echo esc_url(self::lang_url('es')); ?>">ES</a>
                        <a class="<?php echo $lp === 'en' ? 'on' : ''; ?>" href="<?php echo esc_url(self::lang_url('en')); ?>">EN</a>
                    </span>
                    <button type="button" class="bcr-theme-toggle" id="bcr-theme-toggle"
                            title="<?php esc_attr_e('Light / dark mode', 'vigia-de-seonova'); ?>">🌙</button>
                </div>
            </div>

            <div class="bcr-cards">
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html(number_format_i18n($t7['total'])); ?></div>
                    <div><?php esc_html_e('visits in the last 7 days', 'vigia-de-seonova'); ?></div>
                </div>
                <div class="bcr-card">
                    <div class="bcr-big"><?php echo esc_html($pct7); ?>%</div>
                    <div><?php esc_html_e('were bots', 'vigia-de-seonova'); ?></div>
                </div>
                <div class="bcr-card bcr-card-money">
                    <?php if ($cost !== null) : ?>
                        <div class="bcr-big">~$<?php echo esc_html(number_format_i18n($cost, 2)); ?></div>
                        <div><?php esc_html_e('per month of junk traffic polluting your ads (estimate from your RPM)', 'vigia-de-seonova'); ?></div>
                    <?php else : ?>
                        <div class="bcr-big">$?</div>
                        <div><?php esc_html_e('enter your RPM here to see what bots cost you', 'vigia-de-seonova'); ?></div>
                    <?php endif; ?>
                    <?php /* El ajuste vive AL LADO de su efecto — pedido del usuario: al llegar
                             abajo del listado ya no se acordaba de para qué era el campo. */ ?>
                    <form method="post" action="options.php" class="bcr-rpm-form">
                        <?php settings_fields('bcr_money'); ?>
                        <label for="bcr_rpm"><?php esc_html_e('Your AdSense RPM ($)', 'vigia-de-seonova'); ?></label>
                        <input name="bcr_rpm" id="bcr_rpm" type="number" step="0.01" min="0"
                               value="<?php echo esc_attr($rpm ?: ''); ?>" />
                        <button class="button button-small"><?php esc_html_e('Save', 'vigia-de-seonova'); ?></button>
                        <span class="bcr-muted"><?php esc_html_e('What you earn per 1,000 pageviews (your AdSense panel shows it). With this, the radar estimates how much money bots are polluting.', 'vigia-de-seonova'); ?></span>
                    </form>
                </div>
                <div class="bcr-card bcr-card-cta">
                    <a class="button button-primary button-hero" href="<?php echo esc_url(BCR_CTA_URL); ?>" target="_blank" rel="noopener">
                        <?php esc_html_e('Stop them with WPO Toolkit →', 'vigia-de-seonova'); ?>
                    </a>
                    <div class="bcr-muted"><?php esc_html_e('This radar only watches. Blocking them is the toolkit\'s job.', 'vigia-de-seonova'); ?></div>
                </div>
            </div>

            <?php self::verdict_card(); ?>

            <h2><?php esc_html_e('Breakdown, last 7 days', 'vigia-de-seonova'); ?></h2>
            <div class="bcr-buckets">
                <?php
                $defs = array(
                    'humano'     => array('🟢', __('Humans', 'vigia-de-seonova')),
                    'bueno'      => array('🔵', __('Verified good bots (real Google/Bing)', 'vigia-de-seonova')),
                    'impostor'   => array('🔴', __('IMPOSTORS (claim to be Google/Bing and are not)', 'vigia-de-seonova')),
                    'datacenter' => array('🟠', __('Data centers disguised as people', 'vigia-de-seonova')),
                    'declarado'  => array('⚪', __('Declared bots (AI, SEO, tools)', 'vigia-de-seonova')),
                );
                foreach ($defs as $key => $def) : ?>
                    <div class="bcr-bucket">
                        <span><?php echo esc_html($def[0]); ?></span>
                        <strong><?php echo esc_html(number_format_i18n($t7[$key])); ?></strong>
                        <span><?php echo esc_html($def[1]); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <h2><?php esc_html_e('Who has visited (last 7 days)', 'vigia-de-seonova'); ?></h2>
            <?php self::who_tables(); ?>

            <h2><?php esc_html_e('Last 30 days — humans vs bots', 'vigia-de-seonova'); ?></h2>
            <?php self::chart(); ?>

            <h2><?php esc_html_e('Latest visits', 'vigia-de-seonova'); ?></h2>
            <?php self::visits_table(); ?>

            <h2><?php esc_html_e('Weekly email report', 'vigia-de-seonova'); ?></h2>
            <form method="post" action="options.php" class="bcr-settings">
                <?php settings_fields('bcr_report'); ?>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Weekly email report', 'vigia-de-seonova'); ?></th>
                        <td><label><input name="bcr_report_enabled" type="checkbox" value="1" <?php checked(get_option('bcr_report_enabled', '1'), '1'); ?> />
                            <?php esc_html_e('Email me every Monday what the bots cost', 'vigia-de-seonova'); ?></label><br><br>
                            <input name="bcr_report_email" type="email" value="<?php echo esc_attr(get_option('bcr_report_email', get_option('admin_email'))); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <?php submit_button(__('Save', 'vigia-de-seonova')); ?>
            </form>
        </div>
        </div>
        <style><?php echo self::css(); ?></style>
        <script><?php echo self::theme_js(); ?></script>
        <?php
    }

    /** Veredicto sin IA: umbrales fijos y auditables sobre lo medido. */
    private static function verdict_card() {
        $v = BCR_Store::verdict();
        $need_d = (int) BCR_Store::VERDICT_MIN_DAYS;
        $need_t = (int) BCR_Store::VERDICT_MIN_TOTAL;
        $pct_d  = $need_d ? min(100, (int) round(min((int) $v['days'], $need_d) / $need_d * 100)) : 100;
        $pct_t  = $need_t ? min(100, (int) round(min((int) $v['total'], $need_t) / $need_t * 100)) : 100;
        $pct_all = min($pct_d, $pct_t); // hacen falta LAS DOS metas
        $gathering = ($v['state'] === 'gathering');
        $peek = !empty($_GET['bcr_peek']); // el impaciente pidió verlo ya

        $titles = array(
            1 => __('WPO Toolkit alone is enough', 'vigia-de-seonova'),
            2 => __('WPO Toolkit + free Cloudflare', 'vigia-de-seonova'),
            3 => __('WPO Toolkit + Cloudflare Pro', 'vigia-de-seonova'),
        );
        // Escritos para gente que no sabe qué es Cloudflare ni "el borde":
        // cada nivel explica QUÉ es la pieza que recomienda y POR QUÉ.
        $explains = array(
            1 => __('Low bot pressure: only %1$s%% are bad bots (~%2$s harmful visits/day). Blocking them from inside your own WordPress — exactly what WPO Toolkit does — is plenty. No need to pay for anything extra or put more protection in front.', 'vigia-de-seonova'),
            2 => __('Moderate pressure: %1$s%% are bad bots (~%2$s harmful visits/day). Worth stopping them BEFORE they reach your hosting, and that is what Cloudflare is for. Cloudflare is a free shield that sits IN FRONT of your website: it filters bad visitors on its own network, so your server never even sees them — and your site loads faster too. WPO Toolkit sets it up and decides who gets blocked.', 'vigia-de-seonova'),
            3 => __('Heavy pressure: %1$s%% are bad bots (~%2$s harmful visits/day) — swarm level. Here the free shield falls short: you need Cloudflare Pro, the paid tier (about $20/month), with more muscle to withstand big waves and stronger rules. WPO Toolkit drives it all for you, on top of your WordPress.', 'vigia-de-seonova'),
        );
        $lvl = (int) $v['level'];

        // Ya hay datos suficientes, O el usuario pulsó "verlo ya" → mostramos el veredicto.
        if (!$gathering || $peek) {
            $klass = $gathering ? 'bcr-v0 bcr-preview' : ('bcr-v' . $lvl);
            ?>
            <div class="bcr-verdict <?php echo esc_attr($klass); ?>">
                <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-seonova'); ?>
                    <span class="bcr-verdict-title"><?php echo esc_html($titles[$lvl]); ?></span></h2>
                <?php if ($gathering) : ?>
                    <p class="bcr-preview-tag"><?php printf(
                        esc_html__('Preliminary — for a solid read we recommend %1$d days with traffic and %2$s visits. So far: %3$d days, %4$s visits.', 'vigia-de-seonova'),
                        $need_d, esc_html(number_format_i18n($need_t)),
                        (int) $v['days'], esc_html(number_format_i18n((int) $v['total']))
                    ); ?></p>
                <?php endif; ?>
                <p><?php printf(esc_html($explains[$lvl]),
                    esc_html(number_format_i18n($v['bad_pct'], 1)), esc_html(number_format_i18n($v['hostile_day'], 1))); ?></p>
                <?php if ($gathering) : ?>
                    <?php self::verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t); ?>
                    <p><a href="<?php echo esc_url(remove_query_arg('bcr_peek')); ?>"><?php esc_html_e('Hide it until there is enough data', 'vigia-de-seonova'); ?></a></p>
                <?php else : ?>
                    <p class="bcr-muted"><?php printf(
                        esc_html__('Based on the last %d days measured by this radar. No AI involved: fixed thresholds you can audit.', 'vigia-de-seonova'),
                        30
                    ); ?></p>
                <?php endif; ?>
            </div>
            <?php
            return;
        }

        // Reuniendo datos, sin "verlo ya": barras que se llenan + botón para impacientes.
        ?>
        <div class="bcr-verdict bcr-v0">
            <h2><?php esc_html_e('Verdict: what does this site need?', 'vigia-de-seonova'); ?>
                <span class="bcr-verdict-title"><?php printf(esc_html__('%d%% ready', 'vigia-de-seonova'), (int) $pct_all); ?></span></h2>
            <p><?php esc_html_e('Gathering data before giving a verdict — it needs a bit of history so the advice is solid, not a guess.', 'vigia-de-seonova'); ?></p>
            <?php self::verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t); ?>
            <p><a class="button button-secondary" href="<?php echo esc_url(add_query_arg('bcr_peek', '1')); ?>"><?php esc_html_e('Show me the verdict now anyway', 'vigia-de-seonova'); ?></a></p>
        </div>
        <?php
    }

    /** Barras que se van llenando hacia las metas (días con tráfico + visitas). */
    private static function verdict_progress($v, $need_d, $need_t, $pct_d, $pct_t) {
        ?>
        <div class="bcr-progress">
            <div class="bcr-progress-row">
                <span class="bcr-progress-label"><?php esc_html_e('Days with traffic', 'vigia-de-seonova'); ?></span>
                <span class="bcr-progress-track"><span class="bcr-progress-fill<?php echo $pct_d >= 100 ? ' done' : ''; ?>" style="width:<?php echo (int) $pct_d; ?>%"></span></span>
                <span class="bcr-progress-num"><?php echo (int) $v['days']; ?>/<?php echo (int) $need_d; ?></span>
            </div>
            <div class="bcr-progress-row">
                <span class="bcr-progress-label"><?php esc_html_e('Visits', 'vigia-de-seonova'); ?></span>
                <span class="bcr-progress-track"><span class="bcr-progress-fill<?php echo $pct_t >= 100 ? ' done' : ''; ?>" style="width:<?php echo (int) $pct_t; ?>%"></span></span>
                <span class="bcr-progress-num"><?php echo esc_html(number_format_i18n((int) $v['total'])); ?>/<?php echo esc_html(number_format_i18n($need_t)); ?></span>
            </div>
        </div>
        <?php
    }

    /** Tabla de últimas visitas, paginada y con tamaño a elegir (se recuerda). */
    private static function visits_table() {
        $pp = self::per_page();
        $total = BCR_Store::count_visits();
        $pages = max(1, (int) ceil($total / $pp));
        $pg = isset($_GET['bcr_pg']) ? max(1, min($pages, (int) $_GET['bcr_pg'])) : 1;
        $base = remove_query_arg(array('bcr_pg', 'bcr_pp'));
        ?>
        <div class="bcr-tablebar">
            <span><?php printf(esc_html__('%s recorded visits (buffer keeps the last 500)', 'vigia-de-seonova'), esc_html(number_format_i18n($total))); ?></span>
            <span class="bcr-pp">
                <?php esc_html_e('Show per page:', 'vigia-de-seonova'); ?>
                <?php foreach (array(10, 25, 50, 100) as $opt) : ?>
                    <?php if ($opt === $pp) : ?><strong><?php echo (int) $opt; ?></strong>
                    <?php else : ?><a href="<?php echo esc_url(add_query_arg(array('bcr_pp' => $opt, 'bcr_pg' => 1), $base)); ?>"><?php echo (int) $opt; ?></a><?php endif; ?>
                <?php endforeach; ?>
            </span>
        </div>
        <table class="bcr-table">
            <thead><tr>
                <th><?php esc_html_e('When', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('IP', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('What it is', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('Who', 'vigia-de-seonova'); ?></th>
                <th><?php esc_html_e('Page', 'vigia-de-seonova'); ?></th>
            </tr></thead>
            <tbody>
            <?php foreach (BCR_Store::last_visits($pp, ($pg - 1) * $pp) as $v) : ?>
                <tr>
                    <td><?php echo esc_html(mysql2date('d M H:i', $v->ts)); ?></td>
                    <td><code><?php echo esc_html($v->ip); ?></code></td>
                    <td class="bcr-b-<?php echo esc_attr($v->bucket); ?>"><?php echo esc_html(BCR_Report::bucket_label($v->bucket)); ?></td>
                    <td><?php echo esc_html($v->who !== '' ? $v->who : '—'); ?>
                        <?php if ($v->rdns && $v->rdns !== '-') : ?><br><small><?php echo esc_html($v->rdns); ?></small><?php endif; ?></td>
                    <td><code><?php echo esc_html($v->path); ?></code></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1) : ?>
        <div class="bcr-pag">
            <?php if ($pg > 1) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg - 1), $base)); ?>">‹ <?php esc_html_e('Previous', 'vigia-de-seonova'); ?></a>
            <?php endif; ?>
            <span><?php printf(esc_html__('Page %1$d of %2$d', 'vigia-de-seonova'), (int) $pg, (int) $pages); ?></span>
            <?php if ($pg < $pages) : ?>
                <a href="<?php echo esc_url(add_query_arg(array('bcr_pg' => $pg + 1), $base)); ?>"><?php esc_html_e('Next', 'vigia-de-seonova'); ?> ›</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php
    }

    /** Dos listas: qué bots BUENOS han pasado y qué bots MALOS (con su tipo). */
    private static function who_tables() {
        $bad_kind = array(
            'impostor'   => __('impostor', 'vigia-de-seonova'),
            'datacenter' => __('data center', 'vigia-de-seonova'),
            'declarado'  => __('declared', 'vigia-de-seonova'),
        );
        $good = BCR_Store::who_breakdown(array('bueno'), 7);
        $bad  = BCR_Store::who_breakdown(array('impostor', 'datacenter', 'declarado'), 7);
        echo '<div class="bcr-who">';

        // BUENOS
        echo '<div class="bcr-who-col"><h3>🔵 ' . esc_html__('Good bots that visited', 'vigia-de-seonova') . '</h3>';
        if (!$good) {
            echo '<p class="bcr-muted">' . esc_html__('None yet.', 'vigia-de-seonova') . '</p>';
        } else {
            echo '<table class="bcr-table"><tbody>';
            foreach ($good as $r) {
                echo '<tr><td>' . esc_html(self::good_hint($r->who)) . '</td>'
                    . '<td class="bcr-num"><strong>' . esc_html(number_format_i18n($r->n)) . '</strong></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';

        // MALOS
        echo '<div class="bcr-who-col"><h3>🔴 ' . esc_html__('Bad bots that visited', 'vigia-de-seonova') . '</h3>';
        if (!$bad) {
            echo '<p class="bcr-muted">' . esc_html__('None yet — good news.', 'vigia-de-seonova') . '</p>';
        } else {
            echo '<table class="bcr-table"><tbody>';
            foreach ($bad as $r) {
                $kind = isset($bad_kind[$r->bucket]) ? $bad_kind[$r->bucket] : $r->bucket;
                echo '<tr><td>' . esc_html($r->who) . ' <span class="bcr-muted">(' . esc_html($kind) . ')</span></td>'
                    . '<td class="bcr-num"><strong>' . esc_html(number_format_i18n($r->n)) . '</strong></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
        echo '</div>';
        echo '<p class="description">' . esc_html__('Good bots (Google, Bing, AdSense…) bring you traffic and money — never blocked. Bad bots are impostors, data-center swarms and scrapers.', 'vigia-de-seonova') . '</p>';
    }

    /** Añade una pista corta a ciertos bots buenos conocidos. */
    private static function good_hint($who) {
        $hints = array(
            'Googlebot'                => __('Google search index', 'vigia-de-seonova'),
            'Bingbot'                  => __('Bing search index', 'vigia-de-seonova'),
            'AdSense (Mediapartners)'  => __('AdSense checking your ads', 'vigia-de-seonova'),
            'AdSense (AdsBot)'         => __('AdSense checking your ads', 'vigia-de-seonova'),
            'Bing Ads (AdIdxBot)'      => __('Bing Ads', 'vigia-de-seonova'),
            'Applebot'                 => __('Apple / Siri', 'vigia-de-seonova'),
            'Facebook'                 => __('Facebook link previews', 'vigia-de-seonova'),
        );
        return isset($hints[$who]) ? $who . ' — ' . $hints[$who] : $who;
    }

    /**
     * Gráfico en TRES colores bien separados (petición del usuario): humanos
     * (verde), bots buenos (azul), bots malos (rojo). Arriba una barra grande
     * de la semana con números y %; abajo el apilado diario de 30 días.
     */
    private static function chart() {
        $C_HUM = '#2fb344'; $C_GOOD = '#2271b1'; $C_BAD = '#e0555a';

        // Barra grande de la semana con los 3 números.
        $t = BCR_Store::totals(7);
        $hum = (int) $t['humano'];
        $good = (int) $t['bueno'];
        $bad = (int) $t['impostor'] + (int) $t['datacenter'] + (int) $t['declarado'];
        $sum = max(1, $hum + $good + $bad);
        $seg = function ($n, $color, $label) use ($sum) {
            if ($n <= 0) { return ''; }
            $pct = round($n / $sum * 100);
            $w = max(3, $n / $sum * 100); // ancho mínimo para que se vea aunque sea poco
            return '<div class="bcr-seg" style="width:' . esc_attr($w) . '%;background:' . esc_attr($color) . '" '
                . 'title="' . esc_attr($label . ': ' . number_format_i18n($n) . ' (' . $pct . '%)') . '">'
                . ($w > 8 ? esc_html(number_format_i18n($n)) : '') . '</div>';
        };
        echo '<div class="bcr-bigbar">';
        echo $seg($hum, $C_HUM, __('Humans', 'vigia-de-seonova'));
        echo $seg($good, $C_GOOD, __('Good bots', 'vigia-de-seonova'));
        echo $seg($bad, $C_BAD, __('Bad bots', 'vigia-de-seonova'));
        echo '</div>';
        echo '<div class="bcr-legend">'
            . '<span><i style="background:' . $C_HUM . '"></i>' . esc_html__('Humans', 'vigia-de-seonova') . ' <b>' . esc_html(number_format_i18n($hum)) . '</b></span>'
            . '<span><i style="background:' . $C_GOOD . '"></i>' . esc_html__('Good bots', 'vigia-de-seonova') . ' <b>' . esc_html(number_format_i18n($good)) . '</b></span>'
            . '<span><i style="background:' . $C_BAD . '"></i>' . esc_html__('Bad bots', 'vigia-de-seonova') . ' <b>' . esc_html(number_format_i18n($bad)) . '</b></span>'
            . '</div>';

        // Apilado diario 30 días, 3 colores.
        $days = BCR_Store::daily(30);
        $max = 1;
        foreach ($days as $d) {
            $max = max($max, (int) $d['total']);
        }
        $w = 900; $h = 150; $bw = $w / max(1, count($days));
        echo '<svg class="bcr-chart" viewBox="0 0 ' . (int) $w . ' ' . (int) ($h + 18) . '" role="img" aria-label="' . esc_attr__('Daily visits: humans, good bots, bad bots', 'vigia-de-seonova') . '">';
        foreach ($days as $i => $d) {
            $vh = (int) $d['humano'];
            $vg = (int) $d['bueno'];
            $vb = (int) $d['impostor'] + (int) $d['datacenter'] + (int) $d['declarado'];
            $x = $i * $bw + 2;
            $ph = round($vh / $max * $h);
            $pg = round($vg / $max * $h);
            $pb = round($vb / $max * $h);
            $y = $h;
            // apilado de abajo arriba: humanos, buenos, malos
            $y -= $ph; echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" width="' . esc_attr($bw - 4) . '" height="' . esc_attr($ph) . '" fill="' . $C_HUM . '"><title>' . esc_attr($d['d'] . ' · ' . esc_attr__('Humans', 'vigia-de-seonova') . ': ' . $vh) . '</title></rect>';
            $y -= $pg; echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" width="' . esc_attr($bw - 4) . '" height="' . esc_attr($pg) . '" fill="' . $C_GOOD . '"><title>' . esc_attr($d['d'] . ' · ' . esc_attr__('Good bots', 'vigia-de-seonova') . ': ' . $vg) . '</title></rect>';
            $y -= $pb; echo '<rect x="' . esc_attr($x) . '" y="' . esc_attr($y) . '" width="' . esc_attr($bw - 4) . '" height="' . esc_attr($pb) . '" fill="' . $C_BAD . '"><title>' . esc_attr($d['d'] . ' · ' . esc_attr__('Bad bots', 'vigia-de-seonova') . ': ' . $vb) . '</title></rect>';
            if ($i % 5 === 0) {
                echo '<text x="' . esc_attr($x) . '" y="' . esc_attr($h + 14) . '" font-size="10">' . esc_html(substr($d['d'], 5)) . '</text>';
            }
        }
        echo '</svg>';
    }

    /**
     * Tema por variables. Regla de oro: NINGÚN color fuera de las variables
     * (el fallo del modo noche v0.1: la cabecera de la tabla se quedaba con el
     * blanco de WP y las etiquetas eran ilegibles).
     */
    private static function css() {
        $vars_dark = '--bcr-bg:#1b1e23;--bcr-card:#23272e;--bcr-border:#3a3f47;--bcr-text:#dfe3e8;--bcr-muted:#9aa2ac;--bcr-code:#2c313a;';
        return '
        .bcr-root{--bcr-bg:#f0f0f1;--bcr-card:#fff;--bcr-border:#dcdcde;--bcr-text:#1d2327;--bcr-muted:#777;--bcr-code:#f0f0f1;
            background:var(--bcr-bg);color:var(--bcr-text);margin:12px 0 0 0;padding:16px;border-radius:8px;min-height:calc(100vh - 120px)}
        @media (prefers-color-scheme: dark){ .bcr-root:not(.bcr-light){' . $vars_dark . '} }
        .bcr-root.bcr-dark{' . $vars_dark . '}
        /* Pintar TODA la columna de WordPress cuando el panel está oscuro, para
           que no quede la franja clara del admin alrededor (bug 2026-08-24). */
        @media (prefers-color-scheme: dark){
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpcontent,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpbody-content,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpbody,
            body.wp-admin:has(#bcr-root:not(.bcr-light)) #wpfooter{background:#1b1e23!important}
        }
        body.wp-admin:has(#bcr-root.bcr-dark) #wpcontent,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpbody-content,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpbody,
        body.wp-admin:has(#bcr-root.bcr-dark) #wpfooter{background:#1b1e23!important}
        body.wp-admin:has(#bcr-root.bcr-light) #wpcontent,
        body.wp-admin:has(#bcr-root.bcr-light) #wpbody-content,
        body.wp-admin:has(#bcr-root.bcr-light) #wpbody{background:#f0f0f1}
        .bcr-root h1,.bcr-root h2{color:var(--bcr-text)}
        .bcr-head{display:flex;justify-content:space-between;align-items:center}
        .bcr-sub{font-size:14px;color:var(--bcr-muted);font-weight:normal;margin-left:8px}
        .bcr-theme-toggle{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:50%;
            width:36px;height:36px;font-size:16px;cursor:pointer;line-height:1}
        .bcr-head-tools{display:flex;align-items:center;gap:10px}
        .bcr-lang{display:inline-flex;border:1px solid var(--bcr-border);border-radius:6px;overflow:hidden}
        .bcr-lang a{padding:4px 10px;font-size:12px;font-weight:700;text-decoration:none;color:var(--bcr-muted);background:var(--bcr-card)}
        .bcr-lang a.on{background:#4f94d4;color:#fff}
        .bcr-progress{display:flex;flex-direction:column;gap:8px;max-width:520px;margin:10px 0 2px}
        .bcr-progress-row{display:flex;align-items:center;gap:10px}
        .bcr-progress-label{flex:0 0 130px;font-size:12px;color:var(--bcr-muted)}
        .bcr-progress-track{flex:1;height:12px;border-radius:6px;background:var(--bcr-bg);border:1px solid var(--bcr-border);overflow:hidden}
        .bcr-progress-fill{display:block;height:100%;width:0;background:#4f94d4;transition:width .5s ease;
            background-image:linear-gradient(45deg,rgba(255,255,255,.25) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.25) 50%,rgba(255,255,255,.25) 75%,transparent 75%,transparent);
            background-size:16px 16px;animation:bcr-stripe 1s linear infinite}
        .bcr-progress-fill.done{background-color:#2fb344;animation:none}
        .bcr-progress-num{flex:0 0 auto;font-size:12px;font-variant-numeric:tabular-nums;color:var(--bcr-text)}
        @keyframes bcr-stripe{from{background-position:0 0}to{background-position:16px 0}}
        @media (prefers-reduced-motion:reduce){.bcr-progress-fill{animation:none}}
        .bcr-cards{display:flex;gap:16px;flex-wrap:wrap;margin:16px 0}
        .bcr-card{background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:16px 20px;min-width:200px;flex:1;color:var(--bcr-text)}
        .bcr-card .bcr-big{font-size:28px;font-weight:700;line-height:1.2}
        .bcr-card-money{border-color:#d63638}
        .bcr-card-money .bcr-big{color:#e65054}
        .bcr-rpm-form{margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:6px}
        .bcr-rpm-form label{font-weight:600}
        .bcr-rpm-form input{width:80px;background:var(--bcr-card);color:var(--bcr-text);border:1px solid var(--bcr-border)}
        .bcr-rpm-form .bcr-muted{flex-basis:100%}
        .bcr-card-cta{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;gap:8px}
        .bcr-muted{color:var(--bcr-muted);font-size:12px}
        .bcr-root .description{color:var(--bcr-muted)}
        .bcr-verdict{background:var(--bcr-card);border:1px solid var(--bcr-border);border-left:4px solid var(--bcr-muted);border-radius:6px;padding:12px 20px;margin:16px 0}
        .bcr-verdict h2{margin:4px 0}
        .bcr-verdict-title{margin-left:10px}
        .bcr-v1{border-left-color:#00a32a}.bcr-v1 .bcr-verdict-title{color:#2fb344}
        .bcr-v2{border-left-color:#e08b1a}.bcr-v2 .bcr-verdict-title{color:#e08b1a}
        .bcr-v3{border-left-color:#d63638}.bcr-v3 .bcr-verdict-title{color:#e65054}
        .bcr-verdict.bcr-preview{border-left-color:#e08b1a;border-left-style:dashed}
        .bcr-preview-tag{color:#e08b1a;font-weight:600;font-size:12px;margin:2px 0 8px}
        .bcr-verdict .button{margin-top:4px}
        .bcr-buckets{display:flex;flex-direction:column;gap:4px;margin-bottom:16px}
        .bcr-who{display:flex;gap:20px;flex-wrap:wrap;max-width:1100px}
        .bcr-who-col{flex:1;min-width:300px}
        .bcr-who-col h3{margin:6px 0}
        .bcr-who td.bcr-num{text-align:right;width:80px;font-variant-numeric:tabular-nums}
        .bcr-bucket strong{min-width:56px;display:inline-block;text-align:right;margin:0 8px}
        .bcr-bigbar{display:flex;max-width:900px;height:38px;border-radius:6px;overflow:hidden;margin:6px 0;border:1px solid var(--bcr-border)}
        .bcr-seg{display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:13px;min-width:0;transition:width .3s}
        .bcr-legend{display:flex;gap:20px;flex-wrap:wrap;max-width:900px;margin:2px 0 12px;color:var(--bcr-text)}
        .bcr-legend span{display:inline-flex;align-items:center;gap:6px}
        .bcr-legend i{width:12px;height:12px;border-radius:3px;display:inline-block}
        .bcr-legend b{font-variant-numeric:tabular-nums}
        .bcr-chart{width:100%;max-width:900px;height:auto;background:var(--bcr-card);border:1px solid var(--bcr-border);border-radius:6px;padding:6px}
        .bcr-chart text{fill:var(--bcr-muted)}
        .bcr-tablebar{display:flex;justify-content:space-between;max-width:1100px;margin:6px 0;color:var(--bcr-muted)}
        .bcr-tablebar a,.bcr-pag a{color:#4f94d4;text-decoration:none;margin:0 3px}
        .bcr-tablebar strong{margin:0 3px}
        .bcr-pag{max-width:1100px;margin:8px 0;display:flex;gap:16px;justify-content:center;color:var(--bcr-muted)}
        /* Tablas 100% propias (sin la clase widefat de WP, que forzaba blanco). */
        .bcr-root table.bcr-table{max-width:1100px;width:100%;border-collapse:collapse;background:var(--bcr-card)!important;border:1px solid var(--bcr-border);color:var(--bcr-text);margin:4px 0}
        .bcr-root table.bcr-table thead th,.bcr-root table.bcr-table thead td{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border-bottom:1px solid var(--bcr-border);text-align:left;padding:8px 10px;font-weight:700}
        .bcr-root table.bcr-table td{color:var(--bcr-text)!important;border-top:1px solid var(--bcr-border);padding:6px 10px}
        .bcr-root table.bcr-table tbody tr{background:var(--bcr-card)!important}
        .bcr-root table.bcr-table tbody tr:nth-child(odd){background:var(--bcr-bg)!important}
        .bcr-root code{background:var(--bcr-code)!important;color:var(--bcr-text)!important}
        .bcr-root .form-table th,.bcr-root .form-table td{color:var(--bcr-text)}
        .bcr-root input[type=number],.bcr-root input[type=email]{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border:1px solid var(--bcr-border)}
        /* Red de seguridad: cualquier caja de WP que se cuele en el panel toma el tema. */
        .bcr-root .widefat,.bcr-root .card,.bcr-root .postbox{background:var(--bcr-card)!important;color:var(--bcr-text)!important;border-color:var(--bcr-border)!important}
        .bcr-b-impostor{color:#e65054;font-weight:700}
        .bcr-b-datacenter{color:#e08b1a;font-weight:600}
        .bcr-b-bueno{color:#4f94d4}
        .bcr-b-humano{color:#2fb344}
        ';
    }

    /** Botón 🌙/☀️: fuerza noche o día y lo recuerda; sin elección, manda el sistema. */
    private static function theme_js() {
        return "(function(){\n"
            . "var root=document.getElementById('bcr-root'),btn=document.getElementById('bcr-theme-toggle');\n"
            . "if(!root||!btn)return;\n"
            . "function sysDark(){return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches;}\n"
            . "function effDark(){if(root.classList.contains('bcr-dark'))return true;if(root.classList.contains('bcr-light'))return false;return sysDark();}\n"
            . "function paint(){btn.textContent=effDark()?'\\u2600\\uFE0F':'\\uD83C\\uDF19';}\n"
            . "var saved=null;try{saved=localStorage.getItem('bcr-theme');}catch(e){}\n"
            . "if(saved==='dark')root.classList.add('bcr-dark');\n"
            . "if(saved==='light')root.classList.add('bcr-light');\n"
            . "paint();\n"
            . "btn.addEventListener('click',function(){\n"
            . "var toDark=!effDark();\n"
            . "root.classList.toggle('bcr-dark',toDark);\n"
            . "root.classList.toggle('bcr-light',!toDark);\n"
            . "try{localStorage.setItem('bcr-theme',toDark?'dark':'light');}catch(e){}\n"
            . "paint();\n"
            . "});\n"
            . "})();";
    }
}
