<?php
/**
 * Ficha de cada visitante, en cristiano — lo que se enseña al desplegar un bot
 * en el panel. Los DATOS vienen de includes/fichas.php (generado desde el
 * catálogo compartido con WPO Toolkit); aquí solo se busca y se elige idioma.
 */

defined('ABSPATH') || exit;

class BCR_Fichas {

    /** Texto en el idioma pedido; si no está, el español. */
    private static function t($arr, $lang) {
        if (!is_array($arr)) {
            return '';
        }
        if (isset($arr[$lang]) && $arr[$lang] !== '') {
            return $arr[$lang];
        }
        return isset($arr['es']) ? $arr['es'] : '';
    }

    private static function valor($clave, $lang) {
        $t = bcr_textos();
        $v = isset($t['valores'][$clave]) ? $t['valores'][$clave] : $t['valores']['nose'];
        return self::t($v, $lang);
    }

    /**
     * Entrada del catálogo que casa con el nombre ("GPTBot (OpenAI)") o con el
     * user-agent entero. Null si nada casa. Las fichas vienen con el patrón
     * más largo primero, así que "googlebot-image" gana a "googlebot".
     */
    public static function buscar($who, $ua = '') {
        $w = strtolower((string) $who);
        $u = strtolower((string) $ua);
        foreach (bcr_fichas() as $pat => $f) {
            $p = strtolower($pat);
            if (($w !== '' && strpos($w, $p) !== false) || ($u !== '' && strpos($u, $p) !== false)) {
                return $f;
            }
        }
        return null;
    }

    /**
     * Ficha lista para pintar. Un impostor NUNCA lleva la ficha del que imita:
     * "falso Googlebot" no es Googlebot, y contarle lo que hace Google sería
     * justo lo contrario de avisar.
     *
     * @return array{que:string, razon:string, trae:string, robots:string, familia:string, familiaNombre:string, consejo:string, conFicha:bool}
     */
    public static function de($who, $bucket, $lang, $ua = '') {
        $t     = bcr_textos();
        $razon = isset($t['cajones'][$bucket]) ? self::t($t['cajones'][$bucket]['razon'], $lang) : '';
        $sin   = function ($clave) use ($t, $lang, $razon) {
            return array(
                'que'    => self::t(isset($t['sinFicha'][$clave]) ? $t['sinFicha'][$clave] : null, $lang),
                'razon'  => $razon,
                'trae'   => self::valor('no', $lang),
                'robots' => self::valor($clave === 'impostor' || $clave === 'sinUa' ? 'no' : 'nose', $lang),
                'familia' => '', 'familiaNombre' => '', 'consejo' => '', 'conFicha' => false,
            );
        };
        if ($bucket === 'impostor') {
            return $sin('impostor');
        }
        if ($who === 'sin user-agent') {
            return $sin('sinUa');
        }
        $f = self::buscar($who, $ua);
        if (!$f) {
            if ($bucket === 'datacenter') {
                return $sin('datacenter');
            }
            return $sin($bucket === 'bueno' ? 'bueno' : 'declarado');
        }
        $fam = ($f['familia'] !== '' && isset($t['familias'][$f['familia']])) ? $t['familias'][$f['familia']] : null;
        return array(
            'que'           => self::t($f, $lang),
            'razon'         => $razon,
            'trae'          => self::valor($f['trae'], $lang),
            'robots'        => self::valor($f['robots'], $lang),
            'familia'       => $f['familia'],
            'familiaNombre' => $fam ? self::t($fam['nombre'], $lang) : '',
            'consejo'       => $fam ? self::t($fam['consejo'], $lang) : '',
            'conFicha'      => true,
        );
    }

    /** "centro de datos", "impostor"… en el idioma pedido. */
    public static function nombre_cajon($bucket, $lang) {
        $t = bcr_textos();
        return isset($t['cajones'][$bucket]) ? self::t($t['cajones'][$bucket]['nombre'], $lang) : (string) $bucket;
    }

    /** "Espía SEO", "Robot de IA"… en el idioma pedido. */
    public static function nombre_familia($familia, $lang) {
        $t = bcr_textos();
        return isset($t['familias'][$familia]) ? self::t($t['familias'][$familia]['nombre'], $lang) : '';
    }
}
